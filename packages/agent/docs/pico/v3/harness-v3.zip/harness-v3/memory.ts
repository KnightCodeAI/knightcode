import type { Context } from "@knightcode/chord";
import { applyImmutable, isBase, type Op } from "@knightcode/chord/delta";
import type { Conversation, DocRef, Entry, EntryScan, Id, Input, JsonValue, Seq, Storage, Task, TaskScan, Write } from "./types.ts";

interface DocLog {
	ops: { seq: Seq; ops: Op[] }[];
}

const key = (ref: DocRef) => (ref.doc === "session" ? "session" : `${ref.doc}:${ref.conversationId}`);

export class MemoryStorage implements Storage {
	private id = 0;
	private seq = 0;
	private readonly conversationsById = new Map<Id, Conversation>();
	private readonly entriesById = new Map<Id, Entry>();
	private readonly entriesByConversation = new Map<Id, Entry[]>(); // ascending
	private readonly tasksById = new Map<Id, Task>();
	private readonly inputsById = new Map<Id, Input>();
	private readonly inputsByRequest = new Map<string, Input>();
	private readonly docLogs = new Map<string, DocLog>();
	private readonly entrySeq = new Map<Id, Seq>();
	private closed = false;

	nextId(): Id {
		return ++this.id;
	}
	protected setNextId(next: Id) {
		this.id = next - 1;
	}
	protected currentMaxId(): Id {
		return this.id;
	}

	async commit(writes: Write[]): Promise<Seq> {
		this.assertOpen();
		const seq = ++this.seq;
		for (const w of writes) {
			switch (w.type) {
				case "conversation":
					this.conversationsById.set(w.conversation.id, w.conversation);
					this.entriesByConversation.set(w.conversation.id, []);
					break;
				case "entry":
					this.entriesById.set(w.entry.id, w.entry);
					this.entriesByConversation.get(w.entry.conversationId)!.push(w.entry);
					this.entrySeq.set(w.entry.id, seq);
					break;
				case "task":
					this.tasksById.set(w.task.id, w.task);
					break;
				case "task.patch": {
					const prev = this.tasksById.get(w.patch.id);
					if (prev === undefined) throw new Error(`patch for unknown task ${w.patch.id}`);
					const { id: _i, ...fields } = w.patch;
					const next = { ...prev, ...fields } as Task;
					if ("checkpoint" in w.patch && w.patch.checkpoint === undefined) delete (next as { checkpoint?: unknown }).checkpoint;
					this.tasksById.set(w.patch.id, next);
					break;
				}
				case "input":
					this.inputsById.set(w.input.id, w.input);
					if (w.input.requestId !== undefined) this.inputsByRequest.set(w.input.requestId, w.input);
					break;
				case "doc": {
					const k = key(w.ref);
					const log = this.docLogs.get(k) ?? { ops: [] };
					log.ops.push({ seq, ops: w.ops });
					this.docLogs.set(k, log);
					break;
				}
			}
		}
		return seq;
	}

	async conversation(id: Id) {
		return this.conversationsById.get(id);
	}
	async conversations() {
		return [...this.conversationsById.values()];
	}

	async entries(ids: Id[]) {
		const out = new Map<Id, Entry>();
		for (const id of ids) {
			const e = this.entriesById.get(id);
			if (e) out.set(id, e);
		}
		return out;
	}

	/** Fork-aware, newest first: own entries, then parent's up to `parent.at`, recursively. */
	async scanEntries(scan: EntryScan): Promise<Entry[]> {
		const out: Entry[] = [];
		let conversationId: Id | undefined = scan.conversationId;
		let cap: Id | undefined = scan.before;
		while (conversationId !== undefined && out.length < scan.limit) {
			const own = this.entriesByConversation.get(conversationId) ?? [];
			for (let i = own.length - 1; i >= 0 && out.length < scan.limit; i--) {
				const e = own[i]!;
				if (cap !== undefined && e.id >= cap) continue;
				if (scan.kind !== undefined && e.kind !== scan.kind) continue;
				if (scan.withHead && e.head === undefined) continue;
				out.push(e);
			}
			const c = this.conversationsById.get(conversationId);
			conversationId = c?.parent?.conversationId;
			cap = c?.parent === undefined ? undefined : Math.min(cap ?? Infinity, c.parent.at + 1);
		}
		return out;
	}

	async task(id: Id) {
		return this.tasksById.get(id);
	}
	async pruneTerminal(): Promise<number> {
		const keep = new Set<Id>();
		for (const t of this.tasksById.values()) if (t.status !== "terminal") for (const d of t.after) keep.add(d);
		let n = 0;
		for (const [id, t] of this.tasksById) if (t.status === "terminal" && !keep.has(id)) { this.tasksById.delete(id); n++; }
		return n;
	}
	async scanTasks(scan: TaskScan): Promise<Task[]> {
		return [...this.tasksById.values()].filter(
			(t) =>
				(scan.conversationId === undefined || t.conversationId === scan.conversationId) &&
				(scan.kind === undefined || t.kind === scan.kind) &&
				(scan.status === undefined || scan.status.includes(t.status)) &&
				(scan.abort === undefined || (t.abort === true) === scan.abort),
		);
	}

	async input(id: Id) {
		return this.inputsById.get(id);
	}
	async inputByRequest(requestId: string) {
		return this.inputsByRequest.get(requestId);
	}

	async doc(ref: DocRef): Promise<JsonValue | undefined> {
		const log = this.docLogs.get(key(ref));
		if (log === undefined) return undefined;
		return fold(log.ops.map((o) => o.ops));
	}
	async docAsOf(conversationId: Id, at: Id): Promise<JsonValue | undefined> {
		const entrySeq = this.entrySeq.get(at);
		if (entrySeq === undefined) return undefined;
		// Walk to the conversation that owns `at` through the fork chain.
		let c = this.conversationsById.get(conversationId);
		while (c && !this.entriesByConversation.get(c.id)?.some((e) => e.id === at)) c = c.parent ? this.conversationsById.get(c.parent.conversationId) : undefined;
		if (!c) return undefined;
		const log = this.docLogs.get(key({ doc: "rewindable", conversationId: c.id }));
		if (log === undefined) return undefined;
		return fold(log.ops.filter((o) => o.seq <= entrySeq).map((o) => o.ops));
	}
	async truncate(ref: DocRef) {
		const log = this.docLogs.get(key(ref));
		if (log === undefined) return;
		let lastBase = 0;
		for (let i = 0; i < log.ops.length; i++) if (isBase(log.ops[i]!.ops)) lastBase = i;
		log.ops = log.ops.slice(lastBase);
	}

	async close() {
		this.closed = true;
	}
	private assertOpen() {
		if (this.closed) throw new Error("storage closed");
	}
}

/** Fold from the last base forward. */
function fold(batches: Op[][]): JsonValue | undefined {
	let start = 0;
	for (let i = 0; i < batches.length; i++) if (isBase(batches[i]!)) start = i;
	let value: JsonValue | undefined;
	for (let i = start; i < batches.length; i++) value = applyImmutable(value, batches[i]!) as JsonValue;
	return value;
}

export type { Context };
