import { AsyncLocalStorage } from "node:async_hooks";
import type { Context } from "@knightcode/chord";
import { isBase, track, type Tracker, type Op } from "@knightcode/chord/delta";
import { deriveContext } from "./context.ts";
import {
	Closed,
	ConversationBusy,
	type ContextView,
	type Conversation,
	type ConversationSpec,
	type DocRef,
	defaultRewindable,
	defaultSticky,
	type AnyKind,
	type Entry,
	type EntryInput,
	type EntryKind,
	type EntryRef,
	type EntryScan,
	type InputOf,
	type TaskRef,
	Faulted,
	Forbidden,
	type Id,
	type Input,
	type Invoker,
	type JsonValue,
	type NewEntry,
	type QueuedInput,
	type RewindableState,
	type SendInput,
	type SessionState,
	type Seq,
	type StickyState,
	type Storage,
	type ToolSlot,
	type Task,
	type TaskScan,
	type TaskSpec,
	type Tx,
	type UserInput,
	type Write,
} from "./types.ts";

// ---------------------------------------------------------------------------
// Document cache: one tracker per document, lazily loaded, evicted on failure.
// ---------------------------------------------------------------------------

const docKey = (ref: DocRef) => (ref.doc === "session" ? "session" : `${ref.doc}:${ref.conversationId}`);

/**
 * Remove matching elements from a tracked array IN PLACE. Never `arr = arr.filter(...)`
 * on a tracked doc: elements read through the proxy are proxies, and assigning the
 * filtered array stores them inside the raw target.
 */
export function removeWhere<T>(arr: T[], pred: (item: T) => boolean): void {
	for (let i = arr.length - 1; i >= 0; i--) if (pred(arr[i]!)) arr.splice(i, 1);
}

class Docs {
	private readonly trackers = new Map<string, Tracker<object>>();
	/** Bytes of ops written since the last base, per document. Drives rebase+truncate. */
	readonly sinceBase = new Map<string, number>();
	constructor(private readonly storage: Storage) {}
	noteOps(ref: DocRef, ops: Op[]) {
		const key = docKey(ref);
		this.sinceBase.set(key, isBase(ops) ? 0 : (this.sinceBase.get(key) ?? 0) + JSON.stringify(ops).length);
	}
	requestBase(ref: DocRef) {
		this.trackers.get(docKey(ref))?.rebase();
	}

	async get<T extends object>(ref: DocRef, fallback: () => T, ctx: Context): Promise<Tracker<T>> {
		const key = docKey(ref);
		const cached = this.trackers.get(key);
		if (cached !== undefined) return cached as Tracker<T>;
		const stored = (await this.storage.doc(ref, ctx)) as T | undefined;
		const t = track<T>(stored ?? fallback());
		t.flush(); // consume the synthetic first flush; never persisted
		t.rebase(); // first real flush after a cold load is a base: cheap insurance
		this.trackers.set(key, t as Tracker<object>);
		return t;
	}
	evict(ref: DocRef) {
		this.trackers.delete(docKey(ref));
	}
	peek(ref: DocRef): Tracker<object> | undefined {
		return this.trackers.get(docKey(ref));
	}
	/** A document created in this process (fresh conversation): cache its tracker directly. */
	adopt(ref: DocRef, tracker: Tracker<object>) {
		this.trackers.set(docKey(ref), tracker);
	}
}

// ---------------------------------------------------------------------------
// Transaction state: buffers writes, tracks which docs were touched.
// ---------------------------------------------------------------------------

interface CommitEffects {
	entries: Entry[];
	tasks: Task[];
	inputs: Input[];
	conversations: Conversation[];
	docs: { ref: DocRef; ops: Op[] }[];
}

class TxImpl implements Tx {
	private readonly writes: Write[] = [];
	private readonly touched = new Map<string, { ref: DocRef; tracker: Tracker<object> }>();
	private readonly createdTasks = new Map<Id, Task>();
	private readonly createdEntries = new Map<Id, Entry>();
	readonly effects: CommitEffects = { entries: [], tasks: [], inputs: [], conversations: [], docs: [] };

	constructor(
		readonly invoker: Invoker,
		private readonly storage: Storage,
		private readonly docs: Docs,
		private readonly kinds: ReadonlyMap<string, AnyKind>,
		private readonly liveTasks: ReadonlyMap<Id, Task>,
		private readonly ctx: Context,
	) {}

	// --- reads --------------------------------------------------------------

	conversation(id: Id) {
		return this.storage.conversation(id, this.ctx);
	}
	entry(id: Id): Promise<Entry | undefined>;
	entry<E extends Entry>(kind: EntryKind<E>, id: Id): Promise<E | undefined>;
	async entry(a: Id | EntryKind, b?: Id): Promise<Entry | undefined> {
		const id = typeof a === "number" ? a : b!;
		const e = this.createdEntries.get(id) ?? (await this.storage.entries([id], this.ctx)).get(id);
		return typeof a === "number" || a.is(e) ? e : undefined;
	}
	entries(ids: Id[]) {
		return this.storage.entries(ids, this.ctx);
	}
	newestEntry(conversationId: Id, opts?: { kind?: string; withHead?: boolean }): Promise<Entry | undefined>;
	newestEntry<E extends Entry>(conversationId: Id, kind: EntryKind<E>): Promise<E | undefined>;
	async newestEntry(conversationId: Id, opts: { kind?: string; withHead?: boolean } | EntryKind = {}): Promise<Entry | undefined> {
		const scan = "is" in opts ? { kind: opts.kind } : opts;
		const [e] = await this.storage.scanEntries({ conversationId, ...scan, limit: 1 }, this.ctx);
		return e;
	}
	scanEntries(scan: EntryScan) {
		return this.storage.scanEntries(scan, this.ctx);
	}
	context(conversationId: Id, at?: Id): Promise<ContextView> {
		return deriveContext(this.storage, conversationId, at, this.ctx);
	}
	async task(id: Id) {
		return this.createdTasks.get(id) ?? this.liveTasks.get(id) ?? (await this.storage.task(id, this.ctx));
	}
	tasks(scan: TaskScan) {
		return this.storage.scanTasks(scan, this.ctx);
	}
	input(id: Id) {
		return this.storage.input(id, this.ctx);
	}

	// --- documents ----------------------------------------------------------

	private doc<T extends object>(ref: DocRef, fallback: () => T): T {
		const key = docKey(ref);
		const hit = this.touched.get(key);
		if (hit !== undefined) return hit.tracker.state as T;
		// Not preloaded for this commit, but maybe already cached in the session (e.g. a
		// conversation this process created). Cold documents need `preload` (async).
		const cached = this.docs.peek(ref);
		if (cached !== undefined) {
			this.touched.set(key, { ref, tracker: cached });
			return cached.state as T;
		}
		void fallback;
		throw new Error(`document ${key} not loaded; pass it in commit({ docs })`);
	}
	/** Called by Session before the callback runs, for every doc the invoker may touch. */
	async preload(refs: DocRef[]) {
		for (const ref of refs) {
			const fallback = ref.doc === "session" ? () => ({ plugins: {} }) : ref.doc === "rewindable" ? defaultRewindable : defaultSticky;
			const tracker = await this.docs.get<object>(ref, fallback, this.ctx);
			this.touched.set(docKey(ref), { ref, tracker });
		}
	}
	rewindable(conversationId: Id): RewindableState {
		this.assertConversationAccess(conversationId, "rewindable");
		return this.doc({ doc: "rewindable", conversationId }, defaultRewindable);
	}
	sticky(conversationId: Id): StickyState {
		this.assertConversationAccess(conversationId, "sticky");
		return this.doc({ doc: "sticky", conversationId }, defaultSticky);
	}
	session(): SessionState {
		return this.doc({ doc: "session" }, () => ({ plugins: {} }));
	}
	snapshot(ref: { doc: "rewindable"; conversationId: Id }): RewindableState;
	snapshot(ref: { doc: "sticky"; conversationId: Id }): StickyState;
	snapshot(ref: { doc: "session" }): SessionState;
	snapshot(ref: DocRef): RewindableState | StickyState | SessionState {
		const hit = this.touched.get(docKey(ref));
		if (hit === undefined) throw new Error(`document ${docKey(ref)} not preloaded`);
		return structuredClone(hit.tracker.target) as RewindableState | StickyState | SessionState;
	}
	slot<T extends object>(task: { id: Id; conversationId: Id }): T {
		const s = this.sticky(task.conversationId);
		return (s.tasks[task.id] ??= {}) as T;
	}
	toolSlot(task: { conversationId: Id; input: { index: number } }): ToolSlot {
		const slot = this.sticky(task.conversationId).turn.tools[task.input.index];
		if (slot === undefined) throw new Error(`no tool slot at index ${task.input.index}`);
		return slot;
	}

	// --- writes -------------------------------------------------------------

	appendEntry(conversationId: Id, entry: NewEntry): Id;
	appendEntry<E extends Entry>(conversationId: Id, kind: EntryKind<E>, entry: EntryInput<E>): EntryRef<E>;
	appendEntry(conversationId: Id, a: NewEntry | EntryKind, b?: object): Id | EntryRef {
		this.assertCore("appendEntry");
		if ("is" in a) return { id: this.appendEntryInternal(conversationId, { ...(b as object), kind: a.kind } as NewEntry), kind: a };
		return this.appendEntryInternal(conversationId, a);
	}
	private appendEntryInternal(conversationId: Id, entry: NewEntry): Id {
		const id = this.storage.nextId();
		const byTaskId = this.invoker.type === "task" ? this.invoker.id : undefined;
		const head = entry.head === "self" ? id : entry.head;
		const full: Entry = {
			id,
			conversationId,
			kind: entry.kind,
			...(byTaskId === undefined ? {} : { byTaskId }),
			...(entry.data === undefined ? {} : { data: entry.data }),
			...(entry.model === undefined ? {} : { model: entry.model }),
			...(head === undefined ? {} : { head }),
			...(entry.edits === undefined ? {} : { edits: entry.edits }),
		};
		this.writes.push({ type: "entry", entry: full });
		this.createdEntries.set(id, full);
		this.effects.entries.push(full);
		return id;
	}

	write(conversationId: Id, entry: NewEntry): Promise<Id>;
	write<E extends Entry>(conversationId: Id, kind: EntryKind<E>, entry: EntryInput<E>): Promise<Id>;
	async write(conversationId: Id, a: NewEntry | EntryKind, b?: object): Promise<Id> {
		const entry: NewEntry = "is" in a ? ({ ...(b as object), kind: a.kind } as NewEntry) : a;
		if (await this.busy(conversationId)) {
			const s = this.sticky(conversationId);
			const id = this.storage.nextId();
			s.inbox.push({ id, mode: "write", entry });
			this.putInput({ id, conversationId, status: "queued" });
			return id;
		}
		const entryId = this.appendEntryInternal(conversationId, entry);
		const id = this.storage.nextId();
		this.putInput({ id, conversationId, status: "done", entry: entryId });
		return id;
	}

	createTask(spec: TaskSpec): Id;
	createTask<K extends AnyKind>(kind: K, input: InputOf<K>, opts?: { conversationId?: Id; background?: true; after?: Id[] }): TaskRef<K>;
	createTask(a: TaskSpec | AnyKind, input?: unknown, opts: { conversationId?: Id; background?: true; after?: Id[] } = {}): Id | TaskRef {
		if ("initial" in a) return { id: this.createTaskInternal({ kind: a.name, input, ...opts }), kind: a };
		return this.createTaskInternal(a);
	}
	private createTaskInternal(spec: TaskSpec): Id {
		const kind = this.kinds.get(spec.kind);
		if (kind === undefined) throw new Error(`unknown kind ${spec.kind}`);
		if (kind.core === true && this.invoker.type === "task" && !this.invoker.core) throw new Forbidden(`create core task ${spec.kind}`);
		if (this.invoker.type === "task" && this.invoker.mode === "abort") throw new Forbidden("create task during abort");
		const conversationId = spec.conversationId ?? (this.invoker.type === "task" ? this.invoker.conversationId : undefined);
		if (conversationId === undefined) throw new Error("host must name the conversation");
		const id = this.storage.nextId();
		const task: Task = {
			id,
			conversationId,
			kind: spec.kind,
			input: spec.input,
			status: "pending",
			after: spec.after ?? [],
			owns: [],
			...(spec.background ? { background: true } : {}),
		};
		this.writes.push({ type: "task", task });
		this.createdTasks.set(id, task);
		this.effects.tasks.push(task);
		return id;
	}

	checkpoint<C extends import("./types.ts").Checkpoint>(value: C): void {
		if (this.invoker.type !== "task") throw new Forbidden("checkpoint outside a task");
		const current = this.liveTasks.get(this.invoker.id);
		if (current === undefined) throw new Error("task not live");
		this.setTask({ ...current, checkpoint: value });
	}
	/** Kernel-internal: replace a task's mutable fields. Persists only what changed against the live record. */
	setTask(task: Task) {
		const prev = this.liveTasks.get(task.id) ?? this.createdTasks.get(task.id);
		const patch: Record<string, unknown> = { id: task.id };
		for (const k of ["status", "checkpoint", "abort", "outcome", "owns"] as const) {
			if (JSON.stringify(prev?.[k]) !== JSON.stringify(task[k])) patch[k] = task[k];
		}
		// A terminal record keeps no checkpoint: nothing reads it, and it is the largest field.
		if (task.status === "terminal" && task.checkpoint !== undefined) { patch.checkpoint = undefined; task = { ...task, checkpoint: undefined }; }
		if (Object.keys(patch).length === 1) return; // nothing changed
		this.writes.push({ type: "task.patch", patch: patch as import("./types.ts").TaskPatch });
		this.effects.tasks.push(task);
	}

	createConversation(spec: ConversationSpec): Id {
		const id = this.storage.nextId();
		const owner = this.invoker.type === "task" ? this.invoker.id : undefined;
		const parent = spec.parent === undefined || spec.parent.at === "start" ? undefined : { conversationId: spec.parent.conversationId, at: spec.parent.at };
		const conversation: Conversation = { id, ...(parent ? { parent } : {}), ...(owner === undefined ? {} : { owner }), ...(spec.sections?.length ? { sections: spec.sections } : {}) };
		this.writes.push({ type: "conversation", conversation });
		this.effects.conversations.push(conversation);
		// Seed documents as bases, and make them usable in this same transaction
		// (a tool that creates a subagent sends to it immediately).
		const rewindable = { ...defaultRewindable(), ...spec.rewindable };
		const sticky = { ...defaultSticky(), ...spec.sticky, inbox: [], turn: { tools: [] }, tasks: {} };
		this.seedDoc({ doc: "rewindable", conversationId: id }, rewindable);
		this.seedDoc({ doc: "sticky", conversationId: id }, sticky);
		if (owner !== undefined) {
			const ownerTask = this.liveTasks.get(owner);
			if (ownerTask) this.setTask({ ...ownerTask, owns: [...ownerTask.owns, id] });
		}
		return id;
	}

	private seedDoc(ref: DocRef, value: object) {
		const tracker = track(value);
		tracker.rebase();
		const base = tracker.flush(); // the base write; the tracker is now clean
		this.writes.push({ type: "doc", ref, ops: base });
		this.effects.docs.push({ ref, ops: base });
		this.docs.adopt(ref, tracker);
		this.touched.set(docKey(ref), { ref, tracker });
	}

	async markTask(id: Id): Promise<"marked" | "terminal"> {
		const task = await this.task(id);
		if (task === undefined) throw new Error(`task ${id} not found`);
		if (task.status === "terminal") return "terminal";
		if (task.abort !== true) this.setTask({ ...task, abort: true });
		return "marked";
	}

	// --- admission ----------------------------------------------------------

	async busy(conversationId: Id): Promise<boolean> {
		for (const t of this.liveTasks.values()) if (t.conversationId === conversationId && this.kinds.get(t.kind)?.turn) return true;
		for (const t of this.createdTasks.values()) if (t.conversationId === conversationId && this.kinds.get(t.kind)?.turn) return true;
		return false;
	}

	private putInput(input: Input) {
		this.writes.push({ type: "input", input });
		this.effects.inputs.push(input);
	}

	async send(conversationId: Id, input: SendInput): Promise<Id> {
		if (input.requestId !== undefined) {
			const existing = await this.storage.inputByRequest(input.requestId, this.ctx);
			if (existing !== undefined) return existing.id;
		}
		const s = this.sticky(conversationId);
		if (await this.busy(conversationId)) {
			const mode = input.whenBusy ?? "followUp";
			if (mode === "reject") throw new ConversationBusy();
			const id = this.storage.nextId();
			s.inbox.push({ id, mode, input: input.content, ...(input.requestId ? { requestId: input.requestId } : {}) });
			this.putInput({ id, conversationId, status: "queued", ...(input.requestId ? { requestId: input.requestId } : {}) });
			return id;
		}
		// Idle: place older queued items, then this one, then create the generation.
		const { triggers } = await this.boundary(conversationId, "final");
		const id = this.storage.nextId();
		const entry = this.appendEntryInternal(conversationId, { kind: "knightcode.user", model: [{ role: "user", content: input.content, timestamp: Date.now() }] });
		this.putInput({ id, conversationId, status: "placed", entry, ...(input.requestId ? { requestId: input.requestId } : {}) });
		this.createTaskInternal({ kind: "knightcode.generation", conversationId, input: { inputs: [...triggers, id] } });
		return id;
	}

	async setInput(id: Id, patch: Partial<Omit<Input, "id" | "conversationId">>) {
		const current = await this.storage.input(id, this.ctx);
		if (current === undefined) throw new Error(`input ${id} not found`);
		this.putInput({ ...current, ...patch });
	}
	async resolveInputs(ids: Id[], resolution: Pick<Input, "status" | "answer" | "reason" | "detail">) {
		for (const id of ids) await this.setInput(id, resolution);
	}

	/**
	 * Boundary placement (pico §9.5), in this order:
	 *   1. every queued write is selected; the last self-head write (reset/handoff) is the cut
	 *   2. every steer/followUp admitted BEFORE the cut is stale: removed, unanswered/stale
	 *   3. from the survivors, select steer per steeringMode and (at final) followUp per followUpMode
	 *   4. place everything selected strictly by ascending id
	 * At postTools a self-head also ends the old group (`terminated`).
	 */
	async boundary(conversationId: Id, at: "postTools" | "final"): Promise<{ triggers: Id[]; terminated: boolean }> {
		const s = this.sticky(conversationId);
		const inbox = [...s.inbox].sort((a, b) => a.id - b.id);

		// 1–2
		let cut: Id | undefined;
		for (const q of inbox) if (q.mode === "write" && q.entry.head === "self") cut = q.id;
		const stale = cut === undefined ? [] : inbox.filter((q) => q.mode !== "write" && q.id < cut!).map((q) => q.id);
		for (const id of stale) await this.setInput(id, { status: "unanswered", reason: "stale" });
		const survivors = inbox.filter((q) => !stale.includes(q.id));

		// 3
		const pick = (mode: "steer" | "followUp", policy: "all" | "one-at-a-time") => {
			const items = survivors.filter((q) => q.mode === mode);
			return policy === "all" ? items : items.slice(0, 1);
		};
		const selected = new Set<Id>(stale);
		for (const q of survivors) if (q.mode === "write") selected.add(q.id);
		for (const q of pick("steer", s.steeringMode)) selected.add(q.id);
		if (at === "final") for (const q of pick("followUp", s.followUpMode)) selected.add(q.id);

		// 4
		const triggers: Id[] = [];
		for (const q of survivors) {
			if (!selected.has(q.id)) continue;
			if (q.mode === "write") {
				if (q.entry.head !== undefined && q.entry.head !== "self") {
					// a queued head pointing at a specific entry: valid only if not before the current head
					const head = await this.newestEntry(conversationId, { withHead: true });
					if (head?.head !== undefined && q.entry.head < head.head) {
						await this.setInput(q.id, { status: "unanswered", reason: "stale" });
						continue;
					}
				}
				const entry = this.appendEntryInternal(conversationId, q.entry);
				await this.setInput(q.id, { status: "done", entry });
			} else {
				const entry = this.appendEntryInternal(conversationId, { kind: "knightcode.user", model: [{ role: "user", content: q.input, timestamp: Date.now() }] });
				await this.setInput(q.id, { status: "placed", entry });
				triggers.push(q.id);
			}
		}
		removeWhere(s.inbox, (q) => selected.has(q.id));
		return { triggers, terminated: at === "postTools" && cut !== undefined };
	}

	// --- finish -------------------------------------------------------------

	/** Flush every touched document; return the writes. */
	finish(): Write[] {
		for (const { ref, tracker } of this.touched.values()) {
			const ops = tracker.flush();
			if (ops.length === 0) continue;
			this.writes.push({ type: "doc", ref, ops });
			this.effects.docs.push({ ref, ops });
			this.docs.noteOps(ref, ops);
		}
		return this.writes;
	}
	/** On failure: forget everything this tx did to trackers. */
	evictTouched() {
		for (const { ref } of this.touched.values()) this.docs.evict(ref);
	}

	// --- capability ---------------------------------------------------------

	private assertCore(what: string) {
		if (this.invoker.type === "task" && !this.invoker.core) throw new Forbidden(what);
		if (this.invoker.type === "host") throw new Forbidden(`${what} from host; use write()`);
	}
	private assertConversationAccess(conversationId: Id, doc: string) {
		if (this.invoker.type === "task" && this.invoker.mode === "abort" && doc === "sticky") return; // read allowed; writes rejected at flush? no — abort may write sticky (its own task slot). keep simple.
		// Subtree checks omitted in v3: a task may touch any conversation's docs. Tighten if needed.
	}
}

// ---------------------------------------------------------------------------
// Session: the line.
// ---------------------------------------------------------------------------

interface LineSlot {
	active: boolean;
}
const onLine = new AsyncLocalStorage<LineSlot>();

export interface CommitResult<T> {
	value: T;
	seq: Seq | undefined;
	effects: CommitEffects;
}

export class Session {
	private tail: Promise<unknown> = Promise.resolve();
	private closed = false;
	private fault: Faulted | undefined;
	readonly docs: Docs;
	/** Live tasks, maintained by the scheduler after every commit. */
	readonly liveTasks = new Map<Id, Task>();
	readonly listeners = new Set<(r: CommitResult<unknown>) => void>();

	constructor(
		readonly storage: Storage,
		readonly kinds: ReadonlyMap<string, AnyKind>,
	) {
		this.docs = new Docs(storage);
	}

	/** Run `fn` on the line with a transaction bound to `invoker`. */
	async commit<T>(invoker: Invoker, fn: (tx: TxImpl) => T | Promise<T>, ctx: Context, opts: { docs?: DocRef[] } = {}): Promise<CommitResult<T>> {
		ctx.abortSignal?.throwIfAborted();
		const result = await this.enter(async () => {
			this.assertUsable();
			const tx = new TxImpl(invoker, this.storage, this.docs, this.kinds, this.liveTasks, ctx);
			// Preload every document this transaction may touch. Default: session + the invoker's conversation docs.
			const refs: DocRef[] = [{ doc: "session" }, ...(opts.docs ?? [])];
			if (invoker.type === "task") refs.push({ doc: "rewindable", conversationId: invoker.conversationId }, { doc: "sticky", conversationId: invoker.conversationId });
			await tx.preload(refs);
			try {
				const value = await fn(tx);
				const writes = tx.finish();
				let seq: Seq | undefined;
				if (writes.length > 0) {
					try {
						seq = await this.storage.commit(writes, ctx);
					} catch (error) {
						tx.evictTouched();
						this.fault = new Faulted(error);
						await this.storage.close(ctx).catch(() => {});
						throw this.fault;
					}
					this.applyLiveTasks(tx.effects.tasks);
				}
				const result: CommitResult<T> = { value, seq, effects: tx.effects };
				return result;
			} catch (error) {
				tx.evictTouched();
				throw error;
			}
		});
		// Listeners run after the line is released so they may enter it themselves (scheduler kick).
		// Ordering is preserved: this continuation was queued before any later commit's.
		if (result.seq !== undefined) for (const l of this.listeners) l(result);
		return result;
	}

	/** Read-only line operation without a transaction (public reads). */
	read<T>(fn: (storage: Storage) => Promise<T>): Promise<T> {
		return this.enter(() => {
			this.assertUsable();
			return fn(this.storage);
		});
	}

	/** Ops bytes a sticky doc may accumulate before it is rebased and truncated even while busy. */
	static readonly STICKY_BASE_BUDGET = 256 * 1024;
	/** Terminal tasks nobody depends on are dropped from the in-memory index every this many retirements. */
	static readonly PRUNE_EVERY = 64;
	private retirements = 0;

	/**
	 * Called by the scheduler after a task terminalizes: retire its sticky slot; then,
	 * if the conversation is idle or the doc's op log is over budget, write a base and
	 * truncate. A base carries every live task's state, so a busy-time base costs the
	 * size of what is in flight — hence the budget rather than a base per task.
	 */
	async retire(task: Task, ctx: Context) {
		const ref: DocRef = { doc: "sticky", conversationId: task.conversationId };
		const idle = ![...this.liveTasks.values()].some((t) => t.conversationId === task.conversationId);
		const over = (this.docs.sinceBase.get(docKey(ref)) ?? 0) > Session.STICKY_BASE_BUDGET;
		await this.commit({ type: "host" }, (tx) => {
			delete tx.sticky(task.conversationId).tasks[task.id];
			if (idle || over) this.docs.requestBase(ref);
		}, ctx, { docs: [ref] });
		if (idle || over) await this.storage.truncate(ref, ctx);
		if (++this.retirements % Session.PRUNE_EVERY === 0) await this.enter(() => this.storage.pruneTerminal(ctx));
	}

	/** Fork: resolve the parent's rewindable doc at `at`, then create. */
	async fork(parentId: Id, at: Id | "start", spec: Omit<ConversationSpec, "parent">, ctx: Context): Promise<Id> {
		const inherited = at === "start" ? undefined : ((await this.storage.docAsOf(parentId, at, ctx)) as RewindableState | undefined);
		const r = await this.commit({ type: "host" }, (tx) =>
			tx.createConversation({ parent: { conversationId: parentId, at }, rewindable: { ...inherited, ...spec.rewindable }, sticky: spec.sticky }),
		ctx);
		return r.value;
	}

	async close(ctx: Context) {
		await this.enter(async () => {
			this.closed = true;
			await this.storage.close(ctx);
		});
	}

	private applyLiveTasks(tasks: Task[]) {
		for (const t of tasks) {
			if (t.status === "terminal") this.liveTasks.delete(t.id);
			else this.liveTasks.set(t.id, t);
		}
	}

	private enter<T>(op: () => T | Promise<T>): Promise<T> {
		if (onLine.getStore()?.active) return Promise.reject(new Error("nested line operation"));
		const previous = this.tail;
		let release!: () => void;
		this.tail = new Promise<void>((resolve) => {
			release = resolve;
		});
		return (async () => {
			await previous;
			const slot: LineSlot = { active: true };
			try {
				return await onLine.run(slot, op);
			} finally {
				slot.active = false;
				release();
			}
		})();
	}

	private assertUsable() {
		if (this.fault !== undefined) throw this.fault;
		if (this.closed) throw new Closed();
	}
}

export type { TxImpl };
