# harness-v3

A durable agent harness: the boiled-down successor to pico. ~3.4k lines kernel + kinds.

## Layout

    types.ts        records (4 tables + 3 documents), Storage, Kind/phases, Tx, Runtime, ToolApi, hooks, config facade types
    session.ts      the commit line, document trackers, the one Tx implementation, admission + boundaries
    scheduler.ts    eligibility, the phase loop, mark-then-fresh-abort, waiters
    context.ts      §1.3 context derivation (head / range / edits / tool-result reorder / fork synthesis)
    system.ts       §12 system sections: draft, canonical fold, baseline/delta, preparation snapshot, seeds
    hooks.ts        per-kind hook runner (scoping + one fold helper; kinds own their fold semantics)
    harness.ts      public surface: open/close, conversations, c.config, hooks, registries, watch, applyDelta
    bounded.ts      bounded byte buffer used by kernel-owned tool streaming
    kinds/          generation, tool, others (post_tools, collapse, job, plugin, taskApi), entries, frames
    memory.ts       in-memory Storage (reference backend; also JSONL's read path)
    jsonl.ts        JSONL Storage: main + per-conversation sticky sidecar + per-task sidecar; no compaction
    bash.ts         a real bash tool (26 lines: spawn, pipe to api.stream, exit code)
    fake-models.ts  scripted @knightcode/ai provider for examples
    USAGE.md        usage guide
    examples/       01-chat, 02-tools, 03-subagent-and-jobs, 04-crash (run with tsx)
    test/           67 tests (node:test) + types.compile.ts + disk.ts breakdown + run-all.sh
    design-history/ pico-design-delta.md (the delta doc against pico v2), redesign.md (rejected journal+fold),
                    collapse.ts/collapse2.ts (the first hand-written kinds), core-sketch/ (the abandoned "assumed surfaces" attempt)
    COMMITS.txt     git history of this directory

## Running

    npm install partial-json@0.1.7 @sinclair/typebox@0.34.33
    # tsconfig.json maps @knightcode/chord and @knightcode/ai to the monorepo sources; adjust the paths.
    tsx --tsconfig tsconfig.json --test test/*.test.ts      # or ./test/run-all.sh
    tsx --tsconfig tsconfig.json examples/01-chat.ts
    tsx --tsconfig tsconfig.json test/disk.ts               # 100-turn on-disk breakdown

@knightcode/ai's SystemMessage / deferred events (PR #9116) are not landed; `shim/pi-ai.ts` and `types.ts` carry the shim.
