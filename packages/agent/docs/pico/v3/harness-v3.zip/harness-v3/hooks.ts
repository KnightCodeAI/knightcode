import type { Context } from "@knightcode/chord";
import type { AnyKind, HookInfo, HookRunner, Id } from "./types.ts";

export interface HookRegistration {
	kind: AnyKind;
	handlers: object;
	conversationId?: Id;
	subtree?: boolean;
}

export function createHookRunners(
	registrations: () => readonly HookRegistration[],
	ancestors: (conversationId: Id) => readonly Id[],
	onReport: (error: unknown) => void,
) {
	return <H extends object>(kind: AnyKind, info: HookInfo): HookRunner<H> => {
		const handlers = (): readonly Partial<H>[] =>
			registrations()
				.filter((r) => r.kind.name === kind.name)
				.filter((r) => r.conversationId === undefined || r.conversationId === info.conversationId || (r.subtree === true && ancestors(info.conversationId).includes(r.conversationId)))
				.map((r) => r.handlers as Partial<H>);
		return {
			handlers,
			async each(ctx, fn, onValue) {
				for (const h of handlers()) {
					try {
						const v = await fn(h);
						if (v !== undefined && onValue?.(v as never) === true) return;
					} catch (error) {
						if (ctx.abortSignal?.aborted) throw error;
						onReport(error);
					}
				}
			},
		};
	};
}
