import { Harness, kinds, type ConfigFor } from "../harness.ts";
import { type Assert, defineTask, type DisjointConfig, type HooksOf, type InputOf, type TaskOf } from "../types.ts";

type Builtin = readonly [typeof kinds.generation, typeof kinds.tool, typeof kinds.postTools, typeof kinds.collapse, typeof kinds.job, typeof kinds.plugin];
type _builtinsDisjoint = Assert<DisjointConfig<Builtin>>;

const plan = defineTask<null, { phase: "x" }, null, null, null, object, { rewindable: { planMode: boolean } }>({ name: "plan", config: { rewindable: { planMode: false } }, phases: { async x() { return { done: () => ({ status: "completed", result: null }) }; } }, async initial() { return { next: { phase: "x" } }; }, async abort() { return () => null; } });
const clash = defineTask<null, { phase: "x" }, null, null, null, object, { sticky: { model: string } }>({ name: "clash", config: { sticky: { model: "" } }, phases: { async x() { return { done: () => ({ status: "completed", result: null }) }; } }, async initial() { return { next: { phase: "x" } }; }, async abort() { return () => null; } });

type _planOk = Assert<DisjointConfig<[...Builtin, typeof plan]>>;
// @ts-expect-error `model` is declared by generation and by clash
type _clashBad = Assert<DisjointConfig<[...Builtin, typeof clash]>>;

type Cfg = ConfigFor<[typeof plan]>;
const cfg: Cfg = { model: undefined, thinkingLevel: "off", selectedTools: [], profile: "default", retry: { enabled: true, maxRetries: 3, baseDelayMs: 1 }, steeringMode: "all", followUpMode: "all", threshold: 0, keepRecent: 1, planMode: true };
void cfg;

type _hooks = Assert<HooksOf<typeof kinds.generation> extends { afterResponse: unknown } ? true : false>;
type _input = Assert<InputOf<typeof kinds.job> extends { command: string } ? true : false>;
type _task = Assert<TaskOf<typeof kinds.job> extends { outcome?: { status: "completed"; result: { stdout: string } } | { status: "failed" } | { status: "aborted" } | { status: "orphaned" } } ? true : false>;

export const _open = (storage: never, models: never) => Harness.open(storage, { models, taskKinds: [plan] as const }, null as never).then(async (h) => {
	const c = await h.root(null as never);
	const all = await c.config.get(null as never);
	const pm: boolean = all.planMode;
	await c.config.set({ planMode: !pm, followUpMode: "all" }, null as never);
	// @ts-expect-error unknown key
	await c.config.set({ nope: 1 }, null as never);
});
