#!/bin/bash
cd "$(dirname "$0")/.." && timeout 400 tsx --tsconfig tsconfig.json --test test/*.test.ts 2>&1 | grep -E "^(not ok|# (tests|pass|fail))|error:|expected:|actual:" 
