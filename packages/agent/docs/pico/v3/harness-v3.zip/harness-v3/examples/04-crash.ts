// Crash mid-generation, reopen the same directory, watch it recover. Run: tsx examples/04-crash.ts
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { BACKGROUND_CONTEXT as ctx } from "@knightcode/chord/context";
import { Harness } from "../harness.ts";
import { JsonlStorage } from "../jsonl.ts";
import { fake } from "../test/helpers.ts";

const dir = mkdtempSync(join(tmpdir(), "crash-"));
const root = { rewindable: { model: { provider: "anthropic", modelId: "fake-1" }, retry: undefined }, sticky: { retry: { enabled: true, maxRetries: 3, baseDelayMs: 50 } } };
const show = async (h: Harness, label: string) => {
	const entries = (await h.entries({ conversationId: 1, limit: 50 }, ctx)).reverse();
	const tasks = await (await h.root(ctx)).commit((tx) => tx.tasks({}), ctx);
	console.log(`${label}\n  entries: ${entries.map((e) => e.kind.replace("knightcode.", "")).join(" ")}\n  tasks:   ${tasks.map((t) => `${t.kind.replace("knightcode.", "")}:${t.status}${t.checkpoint ? "@" + t.checkpoint.phase : ""}`).join(" ")}`);
};

{
	// Process 1: a provider that hangs after the first token.
	const hanging = fake({ tokenDelayMs: 5, respond: () => ({ text: Array.from({ length: 60 }, (_, i) => `word${i}`).join(" ") }) });
	const origStream = hanging.stream.bind(hanging);
	hanging.stream = async function* (m, req, c) {
		let n = 0;
		for await (const e of origStream(m, req, c)) {
			yield e;
			if (++n === 40) await new Promise((_, reject) => c.abortSignal?.addEventListener("abort", () => reject(new Error("aborted")))); // hang until cancelled
		}
	};
	const h = await Harness.open(await JsonlStorage.open(dir), { models: hanging, root }, ctx);
	h.resume();
	const c = await h.root(ctx);
	await c.send({ content: "hello" }, ctx);
	await new Promise((r) => setTimeout(r, 400));
	await show(h, "process 1, mid-stream:");
	console.log("  streaming so far:", JSON.stringify((await c.sticky(ctx)).turn.message?.content));
	await h.close(ctx); // signals + joins; writes nothing. Same durable state as kill -9.
	console.log("  --- crash ---");
}
{
	// Process 2: same directory, a working provider.
	const h = await Harness.open(await JsonlStorage.open(dir), { models: fake({ respond: () => ({ text: "The answer, this time in full." }) }) }, ctx);
	await show(h, "process 2, reopened:");
	h.resume();
	const c = await h.root(ctx);
	await c.waitForIdle(ctx);
	await show(h, "process 2, recovered:");
	const usage = (await h.entries({ conversationId: 1, kind: "knightcode.usage", limit: 5 }, ctx))[0];
	console.log("  the interrupted attempt is on record:", JSON.stringify(usage?.data));
	await h.close(ctx);
}
