// A delegating tool (subagent), a job that outgrows its budget, and abort reaching a child.
import { BACKGROUND_CONTEXT as ctx, withAbortSignal } from "@knightcode/chord/context";
import { Type } from "@sinclair/typebox";
import { Harness, applyDelta, kinds } from "../harness.ts";
import type { JobOutput } from "../kinds/others.ts";
import { MemoryStorage } from "../memory.ts";
import type { ProcessHost, ProcessStatus, ToolDeclaration } from "../types.ts";
import { scriptedModels } from "./fake.ts";

const delegate: ToolDeclaration = {
	name: "delegate", description: "Hand a task to a subagent", parameters: Type.Object({ v: Type.String() }),
	async execute(args, api, ctx) {
		const child = await api.conversation({ rewindable: { model: { provider: "anthropic", modelId: "fake-1" }, selectedTools: [] } }, ctx);
		const r = await (await child.send({ content: `child task: ${(args as { v: string }).v}` }, ctx)).wait(ctx);
		return { content: [{ type: "text", text: `subagent (conversation ${child.id}) ${r.status}` }], details: { child: child.id } };
	},
};

// A fake process host: "sleep" runs until we exit it.
const procs = new Map<string, ProcessStatus>();
const host: ProcessHost = {
	async start(key) { procs.set(key, { status: "running", stdout: "", stderr: "", droppedStdout: 0, droppedStderr: 0 }); },
	async status(key) { return procs.get(key) ?? { status: "unknown" }; },
	async kill() {},
};
const build: ToolDeclaration = {
	name: "build", description: "Run the build (backgrounds after 300ms)", parameters: Type.Object({ v: Type.String() }),
	async execute(_a, api, ctx) {
		const job = await api.task(kinds.job, { command: "make", args: [], cwd: "/", notify: true, rerun: false }, { background: true }, ctx);
		await api.progress((s) => { s.continuedBy = job.id; }, ctx);
		try {
			const done = await api.waitForTask(job, withAbortSignal(AbortSignal.timeout(300), ctx));
			return done.outcome?.status === "completed" ? { content: [{ type: "text", text: done.outcome.result.stdout }] } : { content: [{ type: "text", text: "build failed" }], isError: true };
		} catch (e) {
			if (ctx.abortSignal?.aborted) throw e;
			const soFar = (await api.slot<JobOutput>(job, ctx))?.stdout ?? "";
			return { content: [{ type: "text", text: `${soFar}\n[build continues in the background as task ${job.id}]` }] };
		}
	},
};

const h = await Harness.open(new MemoryStorage(), {
	models: scriptedModels(3),
	tools: [delegate, build],
	processHost: host,
	root: { rewindable: { model: { provider: "anthropic", modelId: "fake-1" }, selectedTools: ["delegate", "build"] } },
}, ctx);
h.resume();
const c = await h.root(ctx);
c.hooks(kinds.generation, { afterResponse: (_m, info) => console.log(`  [hook] response in conversation ${info.conversationId}`) }, { subtree: true });

console.log("--- delegate ---");
await (await c.send({ content: "delegate:check the auth module" }, ctx)).wait(ctx);
await c.waitForIdle(ctx);
console.log(" ", (await h.entries({ conversationId: 1, limit: 3 }, ctx)).map((e) => e.kind).reverse().join(" → "));

console.log("--- build with a 300ms budget ---");
const w = await c.watch(ctx);
let view = w.view;
w.start((d) => { view = applyDelta(view, d); });
const build1 = await c.send({ content: "build it" }, ctx);
let key = "";
while (!key) { await new Promise((r) => setTimeout(r, 5)); key = [...procs.keys()][0] ?? ""; }
procs.set(key, { status: "running", stdout: "compiling 12/40 files…", stderr: "", droppedStdout: 0, droppedStderr: 0 });
await new Promise((r) => setTimeout(r, 200)); // the job polls its host at 100ms, 300ms, 700ms, …
const t0 = view.sticky.turn.tools[0];
console.log(`  running tool ${t0?.name}, continuedBy task ${t0?.continuedBy}; that task's live stdout: ${JSON.stringify((view.sticky.tasks[t0!.continuedBy!] as JobOutput | undefined)?.stdout)}`);
await build1.wait(ctx);
await c.waitForIdle(ctx);
const result = view.entries.filter((e) => e.kind === "knightcode.tool_result").pop()!;
console.log("  tool result after the budget:", JSON.stringify((result.model![0] as { content: { text: string }[] }).content[0]!.text));
console.log("  turn over; background tasks:", view.tasks.filter((t) => t.background).map((t) => `${t.kind.replace("knightcode.", "")}#${t.id}`).join(" "), "| working:", view.tasks.some((t) => !t.background));
procs.set(key, { status: "exited", exitCode: 0, stdout: "compiling 40/40 files… done", stderr: "", droppedStdout: 0, droppedStderr: 0 });
await new Promise((r) => setTimeout(r, 1200)); // next poll
console.log("  job finished; background tasks:", view.tasks.filter((t) => t.background).length, "| notice placed:", view.entries.filter((e) => e.kind === "knightcode.notice").map((e) => (e.model![0] as { content: string }).content).join(""));

console.log("--- abort while a subagent is streaming ---");
const slow = await c.send({ content: "delegate:something slow" }, ctx);
await new Promise((r) => setTimeout(r, 40));
console.log("  live:", view.tasks.map((t) => `${t.kind.replace("knightcode.", "")}@${t.conversationId}`).join(" "));
await c.abort(ctx);
console.log("  after abort:", (await slow.result(ctx))?.status, (await slow.result(ctx))?.reason, "| live:", view.tasks.length);
w.stop();
await h.close(ctx);
