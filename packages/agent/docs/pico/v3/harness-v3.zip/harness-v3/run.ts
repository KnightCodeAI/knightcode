import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { BACKGROUND_CONTEXT, withCancel } from "@knightcode/chord/context";
import { Type } from "@sinclair/typebox";
import { fakeModels, type Script } from "./fake-models.ts";
import { type ConversationDelta, Harness, kinds as builtin } from "./harness.ts";
import { JsonlStorage } from "./jsonl.ts";
import { systemSections } from "./system.ts";
import { MemoryStorage } from "./memory.ts";
import type { Entry, RequestMessage, ToolDeclaration } from "./types.ts";

const ctx = BACKGROUND_CONTEXT;
const log = (...a: unknown[]) => console.log(...a);
const kinds = (entries: Entry[]) => entries.map((e) => e.kind.replace("knightcode.", "")).join(" ");

const echo: ToolDeclaration = {
	name: "echo",
	description: "echo",
	parameters: Type.Object({ text: Type.String() }),
	replay: "safe",
	async execute(args, api, ctx) {
		await api.progress((o) => { o.progress = "working"; }, ctx);
		return { content: [{ type: "text", text: `echo: ${(args as { text: string }).text}` }] };
	},
};

/** First call: two tool calls. Second: final answer. Then alternate. */
const script: Script = {
	respond(messages, call) {
		const last = [...messages].reverse().find((m) => m.role !== "system")!;
		if (last.role === "toolResult") return { text: "Done with the tools. Final answer here." };
		if (call === 0) return { text: "Let me use tools.", toolCalls: [{ name: "echo", arguments: { text: "a" } }, { name: "echo", arguments: { text: "b" } }] };
		return { text: "A short direct answer with several words in it." };
	},
};

async function scenario(label: string, storage: JsonlStorage | MemoryStorage) {
	log(`\n=== ${label} ===`);
	let responses = 0;
	const h = await Harness.open(storage, {
		models: fakeModels(script),
		tools: [echo],

		root: { rewindable: { model: { provider: "anthropic", modelId: "fake-1" }, selectedTools: ["echo"], keepRecent: 20 } },
	}, ctx);
	h.hooks(builtin.generation, { systemInstructions: ({ sections }) => { sections.set(systemSections.identity, "You are a test agent."); }, afterResponse: () => { responses++; } });
	h.resume();
	const root = await h.root(ctx);

	// Watch
	const deltas: ConversationDelta[] = [];
	const w = await root.watch(ctx);
	w.start((d) => deltas.push(d));
	log("watch capture:", kinds(w.view.entries), "| tasks:", w.view.tasks.length);

	// Turn 1: tools
	const t0 = performance.now();
	const in1 = await root.send({ content: "hello", requestId: "r1" }, ctx);
	// Steer while busy
	const in2 = await root.send({ content: "also this", whenBusy: "steer" }, ctx);
	log("steer queued:", (await in2.result(ctx))?.status, "| inbox:", (await root.sticky(ctx)).inbox.length);
	const r1 = await in1.wait(ctx);
	log(`turn 1: ${r1.status} answer=${r1.answer} in ${(performance.now() - t0).toFixed(0)}ms`);
	const r2 = await in2.wait(ctx);
	log(`steer: ${r2.status} entry=${r2.entry} answer=${r2.answer}`);
	await root.waitForIdle(ctx);

	const entries = await h.entries({ conversationId: 1, limit: 100 }, ctx);
	log("transcript:", kinds(entries.reverse()));
	log("watch deltas:", deltas.length, "| entries via watch:", deltas.reduce((n, d) => n + d.entries.length, 0), "| sticky ops:", deltas.filter((d) => d.sticky).length);
	log("afterResponse calls:", responses, "| dedup r1:", (await root.send({ content: "x", requestId: "r1" }, ctx)).id === in1.id);
	log("sticky after idle:", JSON.stringify((await root.sticky(ctx)).tasks), "| inbox:", (await root.sticky(ctx)).inbox.length);

	// Fork at the first user entry: should see pre-turn state.
	await root.commit((tx) => { tx.rewindable(1).plugins.plan = { enabled: true }; }, ctx);
	const firstUser = entries.find((e) => e.kind === "knightcode.user")!;
	const fork = await root.fork(firstUser.id, {}, ctx);
	log("fork rewindable.plugins:", JSON.stringify((await fork.rewindable(ctx)).plugins), "(root now:", JSON.stringify((await root.rewindable(ctx)).plugins), ")");
	log("fork context:", kinds((await fork.commit((tx) => tx.context(fork.id), ctx)).entries));

	// Collapse
	const cid = await root.collapse(undefined, ctx).catch((e) => String(e));
	if (typeof cid === "number") {
		await root.waitForIdle(ctx);
		await new Promise((r) => setTimeout(r, 50));
		const after = await h.entries({ conversationId: 1, limit: 100 }, ctx);
		const ctxNow = await root.commit((tx) => tx.context(1), ctx);
		log("collapse -> transcript tail:", kinds(after.slice(0, 3).reverse()), "| context now:", kinds(ctxNow.entries));
	} else log("collapse:", cid);

	w.stop();
	await h.close(ctx);
	if (storage instanceof JsonlStorage) log("files:", storage.sizes());
}

async function watchGapless() {
	log("\n=== watch: commit queued right behind the capture, start() late ===");
	const h = await Harness.open(new MemoryStorage(), { models: fakeModels(script), root: { rewindable: { model: { provider: "anthropic", modelId: "fake-1" } } } }, ctx);
	const root = await h.root(ctx);
	const text = (e: Entry) => String(e.model?.[0]?.content);
	await root.write({ kind: "knightcode.notice", model: [{ role: "user", content: "before", timestamp: 0 }] }, ctx);
	// Capture enters the line first; the write is queued immediately behind it, before watch() resolves.
	const capture = root.watch(ctx);
	const behind = root.write({ kind: "knightcode.notice", model: [{ role: "user", content: "behind", timestamp: 0 }] }, ctx);
	const w = await capture;
	await behind;
	await root.write({ kind: "knightcode.notice", model: [{ role: "user", content: "later", timestamp: 0 }] }, ctx);
	const seen: string[] = [];
	w.start((d) => seen.push(...d.entries.map(text))); // late: both "behind" and "later" were buffered
	const got = [...w.view.entries.map(text), ...seen].join(",");
	log("view:", w.view.entries.map(text).join(","), "| stream:", seen.join(","));
	log(got === "before,behind,later" ? "GAPLESS OK" : `GAPLESS FAILED: ${got}`);
	w.stop();
	await h.close(ctx);
}

async function crashAndRecover(dir: string) {
	log("\n=== crash mid-stream, reopen, recover ===");
	let hung = false;
	const hangScript: Script = { ...script, tokenDelayMs: 5, hang: (t) => { if (t === 3 && !hung) { hung = true; return true; } return false; } };
	{
		const storage = await JsonlStorage.open(dir);
		const h = await Harness.open(storage, { models: fakeModels(hangScript), tools: [echo], root: { rewindable: { model: { provider: "anthropic", modelId: "fake-1" }, selectedTools: ["echo"] } } }, ctx);
		h.resume();
		const root = await h.root(ctx);
		await root.send({ content: "hello" }, ctx);
		await new Promise((r) => setTimeout(r, 150)); // let it stream a few tokens then hang
		log("before crash:", kinds((await h.entries({ conversationId: 1, limit: 100 }, ctx)).reverse()), "| streaming:", JSON.stringify((await root.sticky(ctx)).tasks).slice(0, 120));
		// "crash": abandon the process state without closing.
		const { cancel } = withCancel(ctx);
		cancel(new Error("simulated crash"));
		await storage.close(); // release fds only; nothing written
	}
	{
		const storage = await JsonlStorage.open(dir);
		const h = await Harness.open(storage, { models: fakeModels(script), tools: [echo] }, ctx);
		const live = await storage.scanTasks({ status: ["pending", "running"] });
		log("reopened: live tasks:", live.map((t) => `${t.kind.replace("knightcode.", "")}:${t.status}:${t.checkpoint?.phase ?? "-"}`).join(" "));
		h.resume();
		const root = await h.root(ctx);
		await root.waitForIdle(ctx);
		await new Promise((r) => setTimeout(r, 100));
		await root.waitForIdle(ctx);
		log("after recovery:", kinds((await h.entries({ conversationId: 1, limit: 100 }, ctx)).reverse()));
		await h.close(ctx);
	}
}

async function bench(dir: string, fsync: boolean, turns: number, tokenDelayMs: number) {
	const storage = await JsonlStorage.open(dir, { fsync });
	let n = 0;
	const s: Script = { respond: () => ({ text: "word ".repeat(300).trim() }), tokenDelayMs };
	const h = await Harness.open(storage, { models: fakeModels(s), root: { rewindable: { model: { provider: "anthropic", modelId: "fake-1" } } } }, ctx);
	h.resume();
	const root = await h.root(ctx);
	let commits = 0;
	const w = await root.watch(ctx);
	w.start(() => commits++);
	const t0 = performance.now();
	for (let i = 0; i < turns; i++) {
		const inp = await root.send({ content: `turn ${i}` }, ctx);
		await inp.wait(ctx);
		n++;
	}
	await root.waitForIdle(ctx);
	const ms = performance.now() - t0;
	const sizes = storage.sizes();
	log(`bench fsync=${fsync} tokenDelay=${tokenDelayMs}ms: ${turns} turns × 300 tokens in ${ms.toFixed(0)}ms (${(ms / turns).toFixed(1)}ms/turn), ${commits} watch deliveries, files: ${JSON.stringify(sizes)}`);
	await h.close(ctx);
}

const base = mkdtempSync(join(tmpdir(), "v3-"));
try {
	await scenario("memory", new MemoryStorage());
	await scenario("jsonl", await JsonlStorage.open(join(base, "a")));
	await watchGapless();
	await crashAndRecover(join(base, "crash"));
	await bench(join(base, "b1"), false, 20, 0);
	await bench(join(base, "b2"), true, 20, 0);
	await bench(join(base, "b3"), true, 5, 2);
} finally {
	rmSync(base, { recursive: true, force: true });
}
