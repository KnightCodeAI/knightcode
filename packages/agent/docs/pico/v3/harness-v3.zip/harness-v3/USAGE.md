# Harness usage guide

Everything below runs against the code in this directory. The examples in
`examples/` are executable (`tsx --tsconfig tsconfig.json examples/01-chat.ts`)
and use the fake provider so they run without keys; swap in @knightcode/ai's
`builtinModels()` for a real one.

## Mental model

A **session** holds **conversations**. A conversation has:

- a **transcript** — append-only immutable **entries** (user, assistant, tool result, summary, …);
- **tasks** — units of work that survive a crash (generate, run a tool, compact, run a process);
- two **documents** — `rewindable` (model, tools, anything a fork should see as it was) and
  `sticky` (queue modes, the inbox, the current turn's streaming state, background task state).

The model **context** is derived from entries: the newest head entry says where it starts,
edits omit or replace earlier messages. Compaction appends a summary with a head; nothing is rewritten.

All writes go through **commits**: one callback, one atomic batch, one line. Tasks run concurrently;
commits serialize. Documents are mutated in place inside a commit and diffed at the end.

There is no `recover()`. A task's `run()` looks at its checkpoint and starts from there, whether it's
the first time or after a restart.

Every async call takes a Chord `Context` last. Cancelling a wait removes the waiter; it never cancels
durable work.

## Quick start

```ts
import { BACKGROUND_CONTEXT as ctx } from "@knightcode/chord/context";
import { Harness, applyDelta, kinds, entries } from "./harness.ts";
import { JsonlStorage } from "./jsonl.ts";
import { bashTool } from "./bash.ts";

const storage = await JsonlStorage.open("./session");
const h = await Harness.open(storage, {
  models,                                          // @knightcode/ai Models
  tools: [bashTool({ maxBytes: 64 * 1024, retain: "head" })],
  root: { rewindable: { model: { provider: "anthropic", modelId: "claude-opus-5" }, selectedTools: ["bash"] } },
}, ctx);
h.hooks(kinds.generation, { systemPrompt: () => ({ text: "You are a careful engineer." }) });
h.resume();                                        // nothing runs until this

const c = await h.root(ctx);

// Watch: `w.view` is a snapshot; every delivery is one commit's changes.
const w = await c.watch(ctx);
let view = w.view;
w.start((d) => { view = applyDelta(view, d); render(view); });

// Send: durable, returns at once. Wait for this input's answer.
const input = await c.send({ content: "List the public API of the parser", requestId: "cli-1" }, ctx);
const result = await input.wait(ctx);
if (result.status === "done") console.log("answered by entry", result.answer);

// Change settings any time: the next request uses them.
await c.commit((tx) => { tx.rewindable(c.id).model = { provider: "openai", modelId: "gpt-5.6" }; }, ctx);

w.stop();
await h.close(ctx);
```

Kill it mid-run and run it again: the second run finds the in-flight task, and its `run()` picks up
from the checkpoint.

## Opening, closing, recovery

`Harness.open(storage, options, ctx)` loads live tasks and installs the five built-in kinds. Nothing
runs until `h.resume()`. A fresh store gets a root conversation (id 1) seeded from `options.root`;
on reopen `root` is ignored.

`h.close(ctx)` stops the scheduler, signals every running invocation, waits for them, closes storage.
It writes nothing: running tasks stay `running` and are resumed next open. A crash is the same thing
without the courtesy.

What each kind does on resume, by checkpoint phase:

| kind | phase | on resume |
|---|---|---|
| generation | `prepared` | derive the request again (hooks rerun), send |
| generation | `requesting` | count as a failed attempt (`knightcode.usage{interrupted}`), retry per policy |
| generation | `retrying` | sleep out the durable deadline, retry |
| tool | none | rerun lookup + `beforeTool`, then start |
| tool | `started` | replay only if declared **and** currently `replay: "safe"`; else a synthetic "interrupted" result |
| collapse | `summarizing` | failed attempt, retry |
| collapse | `prepared` | finalize only (summary text is durable) |
| job | `spawning`/`running` | ask the host; `unknown` + `rerun` → start again with the same key |

A task that was **marked** before the crash gets `abort()` on resume, not `run()`.

## Sending input

```ts
const a = await c.send({ content: "…" }, ctx);                       // idle: placed now, generation created
const b = await c.send({ content: "…", whenBusy: "followUp" }, ctx); // busy: queued until the final answer
const s = await c.send({ content: "…", whenBusy: "steer" }, ctx);    // busy: queued until the next tool boundary
await c.send({ content: "…", whenBusy: "reject" }, ctx);            // busy: throws ConversationBusy
```

- **steer** is placed at the next post-tools boundary and joins the current input group: the
  continuation generation answers it.
- **followUp** is placed after the final answer and starts a new generation.
- `sticky.steeringMode` / `followUpMode` are `"one-at-a-time"` (default) or `"all"`.
- `requestId` is idempotent for the session: a repeated send returns the original handle and writes nothing.

`InputHandle`:

```ts
await a.result(ctx);   // { status: "queued" | "placed" | "done" | "unanswered", entry?, answer?, reason? }
await a.wait(ctx);     // resolves at done/unanswered
await a.abort(ctx);    // "aborted" if still queued; "already_placed" otherwise
```

Passive entries (`write`) are placed at the next boundary when busy, immediately when idle:

```ts
await c.write({ kind: "knightcode.notice", model: [{ role: "user", content: "CI is red", timestamp: Date.now() }] }, ctx);
await c.write({ kind: "my.event", data: { ... } }, ctx);   // your own kind, no `model`: invisible to the model
```

A `reset()` or `handoff` is a write with `head: "self"`. Every steer/followUp queued *before* it is
stale (`unanswered/stale`); ones admitted after run in the fresh context.

## Configuration

Every kind declares the configuration it reads, with defaults, split by document:

```ts
config: {
  rewindable: { model: undefined, thinkingLevel: "off", selectedTools: [], profile: "default" },  // forks see this as it was
  sticky: { retry: { enabled: true, maxRetries: 3, baseDelayMs: 2000 } },                        // the present
}
```

All registered kinds' keys merge flat onto `c.config`, typed. Which document a key lives in is not
the caller's concern:

```ts
const cfg = await c.config.get(ctx);                                          // every key, defaults resolved
await c.config.set({ model: { provider: "openai", modelId: "gpt-5.6" }, followUpMode: "all", keepRecent: 8000 }, ctx);  // one commit
```

Keys must be disjoint across kinds. That is checked at `Harness.open` at compile time (the call
does not typecheck) and at runtime (it throws).

The documents themselves are still reachable for plugin state that isn't a kind's config:
`tx.rewindable(c.id).plugins.x`, `tx.sticky(c.id).plugins.y`.

## System prompt: sections

The system prompt is a set of **sections** — a stable key and a pure renderer — edited through a
draft before each request. The harness stores only keys, payloads and rendered text as `knightcode.system`
entries: a full **baseline** on first use and after any head (reset, compaction), a **delta** when
something changed, nothing otherwise. @knightcode/ai sends them inside `messages` at their historical
positions, so prompt caching survives.

```ts
import { defineSystemSection, systemSections, sectionSeed } from "./system.ts";

const repo = defineSystemSection<{ name: string; branch: string }>({ key: "repo", render: (v) => `Repository ${v.name} on ${v.branch}` });

const h = await Harness.open(storage, { models, sections: [repo], ... }, ctx);
h.hooks(kinds.generation, {
  systemInstructions: ({ sections, config, tools }) => {
    sections.set(systemSections.identity, "You are a careful engineer.");
    sections.set(systemSections.environment, { cwd });
    sections.set(repo, { name, branch });
    sections.wrap(systemSections.identity, (r) => `${r}\nBe terse.`);   // preparation-local
    return { tools: tools.filter((t) => t.name !== "rm") };               // optional loadout override
  },
});
```

Handlers run in registration order (harness-wide, then outermost conversation to innermost) on one
draft; a throwing handler's edits roll back. `config` is the conversation's current settings. The
preparation snapshots config, section and tool registry revisions before running handlers and
repeats if any of them changed meanwhile, so a request never pairs a managed entry with stale
inputs.

New conversations can be seeded: `h.createConversation({ sections: [sectionSeed(systemSections.identity, "…")] })`
applies while the conversation has no managed entry of its own.

## Watching

```ts
const w = await c.watch(ctx);
let view = w.view;                       // { conversation, entries, tasks, rewindable, sticky }
w.start((delta) => { view = applyDelta(view, delta); });
```

`view.entries` is the active transcript (everything from the newest head onward). `delta` is
`{ entries, tasks, rewindable?: Op[], sticky?: Op[] }` for one commit; `applyDelta` folds it. Capture and
subscription happen in one line operation, so nothing is missed or duplicated, and deltas are buffered
until `start`.

What a UI reads:

```ts
view.sticky.turn.message                  // streaming assistant message, or undefined
view.sticky.turn.tools                    // [{ callId, name, args, output?, progress?, continuedBy? }] by call index
view.sticky.inbox                         // queued steer/followUp/write
view.tasks.some((t) => !t.background)     // "working"
view.tasks.filter((t) => t.background)    // background jobs; live state in view.sticky.tasks[t.id]
```

The turn's `message` and `tools` are set in the same commit that appends the assistant entry and
creates the tool tasks, and cleared in the commit that ends the turn. A renderer never sees a tool
without its assistant, or a streaming message next to its settled entry.

## Forks, compaction, reset

```ts
const fork = await c.fork(entryId, {}, ctx);          // rewindable as of entryId; sticky from defaults; context up to entryId
const fresh = await c.fork("start", { rewindable: { model } }, ctx);   // no inherited transcript

const collapseTaskId = await c.collapse("Keep every decision.", ctx);  // background; wait with h.entries/tasks
await c.reset(undefined, ctx);                          // head: "self"; context starts empty
await c.reset("Continue from: …", ctx);                 // handoff with a message
```

Automatic compaction: when a response leaves the context above `threshold`, a foreground `knightcode.collapse`
runs alongside the turn. If a request would not fit at all, generation fails `overflow`, creates a
collapse, and a replacement generation with the same inputs waits on it.

## Plugin state

Pick the document by the semantics you want:

```ts
tx.rewindable(c.id).plugins.planMode = { enabled: true };   // a fork at yesterday sees yesterday's value
tx.sticky(c.id).plugins.uiPrefs = { theme: "dark" };        // the present only
tx.session().plugins.counters = { … };                       // session-wide
```

Watchers get every field in both documents; there is no subscription by key.

## Writing tools

```ts
const grep: ToolDeclaration = {
  name: "grep",
  description: "Search files",
  parameters: Type.Object({ pattern: Type.String() }),
  replay: "unsafe",                                  // default; "safe" lets a restart re-run it
  output: { maxBytes: 64 * 1024, maxLines: 200, retain: "head" },
  async execute(args, api, ctx) {
    const child = spawn("rg", [args.pattern]);
    child.stdout.on("data", (chunk) => api.stream(chunk));   // kernel bounds, throttles, flushes to the view
    await once(child, "close");
    return { isError: child.exitCode !== 0 };                // no `content`: the bounded stream is the content
  },
};
```

`api.stream(chunk)` is a synchronous byte pipe. The kernel keeps at most `maxBytes` (head or tail),
flushes to `view.sticky.turn.tools[i].output` every 100ms, and uses the buffer as the result's content
when the tool returns none. A tool cannot exceed its declared bounds by returning a bigger `content`.

`api.progress(fn)` mutates the tool's slot for small structured state: `progress` text, `details`,
`continuedBy`.

`ToolResult.control` ends or reshapes the turn: `{ terminate: true }`, `{ handoff: "…" }`,
`{ addTools: ["…"] }`.

### Subagents

A tool can create a conversation it owns — empty, or a fork of its own conversation at the current tip:

```ts
async execute(args, api, ctx) {
  const child = await api.conversation({ rewindable: { model: cheapModel, selectedTools: ["read"] } }, ctx);   // empty
  // or: await api.conversation({ inherit: true, rewindable: { selectedTools: [] } }, ctx)                     // same transcript + config as of now
  const sent = await child.send({ content: args.task }, ctx);
  const r = await sent.wait(ctx);
  return { content: [{ type: "text", text: `child ${child.id}: ${r.status}` }] };
}
```

Either way it is a different agent with its own turns. Aborting the parent conversation reaches it.
Hooks registered with `{ subtree: true }` on the parent fire for it. `child.abort(ctx)` aborts it alone.

### Jobs: foreground until a budget, then background

```ts
async execute(args, api, ctx) {
  const job = await api.task(kinds.job, { command: "npm", args: ["test"], cwd, notify: true, rerun: false }, { background: true }, ctx);
  await api.progress((s) => { s.continuedBy = job.id; }, ctx);     // the UI renders the job's output under this tool
  try {
    const done = await api.waitForTask(job, withAbortSignal(AbortSignal.timeout(30_000), ctx));
    return done.outcome?.status === "completed"
      ? { content: [{ type: "text", text: done.outcome.result.stdout }], isError: done.outcome.result.exitCode !== 0 }
      : { content: [{ type: "text", text: `job ${done.outcome?.status}` }], isError: true };
  } catch (error) {
    if (ctx.abortSignal?.aborted) throw error;
    const soFar = (await api.slot<JobOutput>(job, ctx))?.stdout ?? "";
    return { content: [{ type: "text", text: `${soFar}\n\n[continues in the background as task ${job.id}]` }] };
  }
}
```

`api.task` returns a `TaskRef` — `{ id, kind }` — so `waitForTask(ref)`, `getTask(ref)` and `slot(ref)`
are typed with nothing else passed. Store `ref.id` if you need it durably. The budget cancels only the
wait; the job keeps running, visible under `view.tasks` with its live output in `view.sticky.tasks[id]`,
and its `notify` notice lands at the next boundary.

## Hooks

Each kind declares its own hook points as an interface of optional methods (`GenerationHooks`,
`ToolHooks`, `PostToolsHooks`, `CollapseHooks`). Register handlers per kind, harness-wide or on a
conversation:

```ts
h.hooks(kinds.generation, { afterResponse: (message, info) => log(info.conversationId, message.usage) });
const off = c.hooks(kinds.tool, {
  beforeTool: (call) => (call.name === "rm" ? { block: "not allowed" } : undefined),
  afterTool: (call, result) => ({ ...result, content: redact(result.content) }),
}, { subtree: true });
c.hooks(kinds.generation, {
  beforeRequest: ({ messages }) => ({ messages: messages.slice(-50) }),
  onYield: (answer) => (needsMore(answer) ? { continue: "Keep going." } : undefined),
});
c.hooks(kinds.collapse, { beforeCollapse: () => ({ instructions: "Preserve file paths." }) });
```

The kind decides how results fold — `beforeRequest`/`afterTool` chain, `onYield`/`beforeCollapse` take
the first answer, observers all run — and how a throw is handled: skipped and reported everywhere
except `beforeTool`, where a throw blocks the call. Handlers run outside the line and may be rerun after
a crash.

| kind | points |
|---|---|
| `kinds.generation` | `systemPrompt`, `beforeRequest`, `afterResponse`, `onYield` |
| `kinds.tool` | `beforeTool`, `afterTool` |
| `kinds.postTools` | `afterTools` |
| `kinds.collapse` | `beforeCollapse` |

## Custom entries

Define a kind once; use it for typed writes and typed reads.

```ts
interface CiEntry extends Entry { kind: "ci.result"; data: { run: number; ok: boolean }; model: [UserMessage] }
const ci = defineEntry<CiEntry>("ci.result");

await c.write(ci, { data: { run: 812, ok: false }, model: [{ role: "user", content: "CI run 812 failed.", timestamp: Date.now() }] }, ctx);
const last = await c.commit((tx) => tx.newestEntry(c.id, ci), ctx);      // CiEntry | undefined
for (const e of view.entries) if (ci.is(e)) render(e.data.run);          // narrows
```

Omit `model` for bookkeeping entries the model should not see. The built-ins are on `entries`
(`entries.user`, `entries.assistant`, `entries.toolResult`, `entries.summary`, …). `head` and `edits` are
core-only; from the host, `reset()` covers the head case.

## Task kinds

A kind is a map of phase handlers. `initial` runs when there is no checkpoint; `phases` is exhaustive
over the checkpoint union, so a phase nobody handles is a compile error. A handler returns
`{ next }` (the next checkpoint — or a builder that runs on the line and may append entries with it,
terminalize instead, or say `"retry"`) or `{ done }` (the terminal closure).

```ts
const counter = defineTask<{ start: number }, { phase: "counting"; n: number }, { total: number }, never, null>({
  name: "counter",
  config: { rewindable: { countTo: 3 } },
  async initial(task) { return { next: { phase: "counting", n: task.input.start } }; },
  phases: {
    async counting(task, rt, ctx) {
      const { n } = task.checkpoint;
      if (n < (await rt.rewindable(task.conversationId, ctx)).countTo) return { next: { phase: "counting", n: n + 1 } };
      return { done: () => ({ status: "completed", result: { total: n } }) };
    },
  },
  async abort() { return () => null; },
});
```

**Recovery is the phase map.** A phase that starts an external effect writes the in-flight
checkpoint itself (`await rt.commit((tx) => tx.checkpoint({ phase: "started", … }), ctx)`) and then
performs the effect. That phase's handler is therefore only ever *entered* by the scheduler after a
crash — it is the recovery path by construction, with no flag and no second method. `knightcode.generation`'s
`requesting`, `knightcode.tool`'s `started`, `knightcode.job`'s `spawning` are all written this way.

Register with `Harness.open({ taskKinds: [counter] })`; schedule with `tx.createTask(counter, input)`
or `api.task(counter, input, opts)`, which return a typed `TaskRef`.

`knightcode.plugin` remains for a one-off handler that needs no phases:

```ts
Harness.open(storage, { plugins: { nightlyReport: async (input, api, ctx) => { … } } });
await c.commit((tx) => tx.createTask({ kind: "knightcode.plugin", background: true, input: { handler: "nightlyReport", input } }), ctx);
```

## Storage backends

Registries: `h.registerTool(t)`, `h.registerSection(s)` return an unregister function and bump the
revision that in-flight preparations compare against.

- `new MemoryStorage()` — tests.
- `JsonlStorage.open(dir, { fsync })` — one `main.jsonl`, plus one `sticky-<id>.jsonl` per conversation
  that is rewritten to its last base whenever a task retires. Steady-state sticky size is one base;
  main grows ~4KB per turn.

Both implement `Storage` (five write types, a handful of reads). Any backend that keeps the same
invariants — atomic batches, fork-aware entry scans, `docAsOf` for forks — works.
