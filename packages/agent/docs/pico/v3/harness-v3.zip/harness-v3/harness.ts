import type { Context } from "@knightcode/chord";
import { withAbortSignal } from "@knightcode/chord/context";
import { applyImmutable, type Op } from "@knightcode/chord/delta";
import { createHookRunners, type HookRegistration } from "./hooks.ts";
import { type SystemSection, systemSections } from "./system.ts";
import { generation } from "./kinds/generation.ts";
import { entries as builtinEntries } from "./kinds/entries.ts";
import { collapse, job, plugin, postTools } from "./kinds/others.ts";
import { tool } from "./kinds/tool.ts";
import { Scheduler } from "./scheduler.ts";
import { type CommitResult, removeWhere, Session } from "./session.ts";
import {
	type Checkpoint,
	type Conversation,
	type ConversationSpec,
	type DocRef,
	type Entry,
	type EntryScan,
	type HooksOf,
	type Id,
	type Input,
	type AnyKind,
	type ConfigFacade,
	type ConfigOfKinds,
	type DisjointConfig,
	type Models,
	type NewEntry,
	type PluginHandler,
	type ProcessHost,
	type RewindableState,
	type Runtime,
	type SendInput,
	type StickyState,
	type Storage,
	type Task,
	type ToolDeclaration,
	type Tx,
	type UserInput,
	defaultRewindable,
	defaultSticky,
} from "./types.ts";

// ---------------------------------------------------------------------------
// Watch: one envelope per commit. The view is the active transcript, live
// tasks, and the two documents; deltas are entries/tasks/doc ops.
// ---------------------------------------------------------------------------

export interface ConversationView {
	conversation: Conversation;
	entries: Entry[]; // active transcript: ids >= newest head boundary
	tasks: Task[];
	rewindable: RewindableState;
	sticky: StickyState;
}
export interface ConversationDelta {
	entries: Entry[];
	tasks: Task[];
	rewindable?: Op[];
	sticky?: Op[];
}
export interface Watch {
	readonly view: ConversationView;
	start(listener: (delta: ConversationDelta) => void): void;
	stop(): void;
}

export function applyDelta(view: ConversationView, d: ConversationDelta): ConversationView {
	let entries = view.entries;
	for (const e of d.entries) {
		if (e.head !== undefined) entries = entries.filter((x) => x.id >= e.head!);
		entries = [...entries, e];
	}
	const tasks = new Map(view.tasks.map((t) => [t.id, t]));
	for (const t of d.tasks) t.status === "terminal" ? tasks.delete(t.id) : tasks.set(t.id, t);
	return {
		conversation: view.conversation,
		entries,
		tasks: [...tasks.values()],
		rewindable: d.rewindable ? (applyImmutable(view.rewindable, d.rewindable) as RewindableState) : view.rewindable,
		sticky: d.sticky ? (applyImmutable(view.sticky, d.sticky) as StickyState) : view.sticky,
	};
}

// ---------------------------------------------------------------------------
// Harness
// ---------------------------------------------------------------------------

export interface HarnessOptions<Ks extends readonly AnyKind[] = []> {
	models: Models;
	tools?: ToolDeclaration[];
	/** Ordinary kinds authored with `defineTask`. Their `config` merges onto `c.config`; keys must be disjoint. */
	taskKinds?: Ks;
	sections?: SystemSection[];
	plugins?: Record<string, PluginHandler>;
	processHost?: ProcessHost;
	root?: { rewindable?: Partial<RewindableState>; sticky?: Partial<StickyState> };
	onReport?: (error: unknown) => void;
}

/** Every built-in kind's config plus the registered ordinary kinds', merged flat. */
export type BuiltinKinds = readonly [typeof generation, typeof tool, typeof postTools, typeof collapse, typeof job, typeof plugin];
export type ConfigFor<Ks extends readonly AnyKind[]> = ConfigOfKinds<[...BuiltinKinds, ...Ks]>;

export interface ConversationHandle<Cfg extends object = ConfigFor<[]>> {
	readonly id: Id;
	/** Configuration, flat. Which document a key lives in is not the caller's concern. */
	readonly config: ConfigFacade<Cfg>;
	send(input: SendInput, ctx: Context): Promise<InputHandle>;
	write(entry: NewEntry, ctx: Context): Promise<Id>;
	commit<T>(fn: (tx: Tx) => T | Promise<T>, ctx: Context): Promise<T>;
	rewindable(ctx: Context): Promise<RewindableState>;
	sticky(ctx: Context): Promise<StickyState>;
	fork(at: Id | "start", spec: Omit<ConversationSpec, "parent">, ctx: Context): Promise<ConversationHandle<Cfg>>;
	collapse(instructions: string | undefined, ctx: Context): Promise<Id>;
	reset(handoff: string | undefined, ctx: Context): Promise<void>;
	abort(ctx: Context): Promise<void>;
	waitForIdle(ctx: Context): Promise<void>;
	/** Register handlers for one kind's hook points on this conversation (and its owned subtree). */
	hooks<K extends AnyKind>(kind: K, handlers: Partial<HooksOf<K>>, opts?: { subtree?: boolean }): () => void;
	watch(ctx: Context): Promise<Watch>;
}
export interface InputHandle {
	readonly id: Id;
	result(ctx: Context): Promise<Input | undefined>;
	wait(ctx: Context): Promise<Input>;
	abort(ctx: Context): Promise<"aborted" | "already_placed" | "not_found">;
}

export class Harness<Ks extends readonly AnyKind[] = []> {
	private readonly session: Session;
	/** key → document, built from every registered kind's config. */
	private readonly configRoutes = new Map<string, "rewindable" | "sticky">();
	private readonly scheduler: Scheduler;
	private readonly kinds: Map<string, AnyKind>;
	private readonly tools: Map<string, ToolDeclaration>;
	private readonly sectionMap: Map<string, SystemSection>;
	private readonly revisions = { sections: 0, tools: 0 };
	private readonly plugins: Map<string, PluginHandler>;
	private readonly hookRegistrations: HookRegistration[] = [];
	private readonly ancestry = new Map<Id, Id[]>(); // conversation → owner conversations, outermost first
	private readonly ctx: Context;

	static async open<Ks extends readonly AnyKind[] = []>(storage: Storage, options: HarnessOptions<Ks> & (DisjointConfig<[...BuiltinKinds, ...Ks]> extends true ? unknown : { readonly __error: "config keys collide across kinds" }), ctx: Context): Promise<Harness<Ks>> {
		const h = new Harness<Ks>(storage, options, ctx);
		await h.init(options);
		return h;
	}

	private constructor(storage: Storage, options: HarnessOptions<Ks>, ctx: Context) {
		this.ctx = ctx;
		const all: AnyKind[] = [generation, tool, postTools, collapse, job, plugin, ...(options.taskKinds ?? [])];
		this.kinds = new Map(all.map((k) => [k.name, k]));
		for (const k of all) {
			for (const doc of ["rewindable", "sticky"] as const) for (const key of Object.keys(k.config?.[doc] ?? {})) {
				if (this.configRoutes.has(key)) throw new Error(`config key "${key}" declared by more than one kind`);
				this.configRoutes.set(key, doc);
			}
		}
		this.tools = new Map((options.tools ?? []).map((t) => [t.name, t]));
		this.sectionMap = new Map([...Object.values(systemSections), ...(options.sections ?? [])].map((s) => [s.key, s as SystemSection]));
		this.plugins = new Map(Object.entries(options.plugins ?? {}));
		this.session = new Session(storage, this.kinds);

		const hooksFor = createHookRunners(() => this.hookRegistrations, (c) => this.ancestry.get(c) ?? [], options.onReport ?? (() => {}));
		const self = this;
		this.scheduler = new Scheduler({
			session: this.session,
			kinds: this.kinds,
			ctx,
			runtime(task, mode, ctx): Runtime {
				const kind = self.kinds.get(task.kind)!;
				const invoker = { type: "task" as const, id: task.id, conversationId: task.conversationId, core: kind.core === true, mode };
				return {
					taskId: task.id,
					conversationId: task.conversationId,
					commit: (fn, c) => {
						// A task's commits may touch the documents of every conversation it owns (subagents).
						const owns = self.session.liveTasks.get(task.id)?.owns ?? [];
						const docs = owns.flatMap((id): DocRef[] => [{ doc: "rewindable", conversationId: id }, { doc: "sticky", conversationId: id }]);
						return self.session.commit(invoker, (tx) => fn(tx, self.session.liveTasks.get(task.id)!), c, { docs }).then((r) => r.value);
					},
					hooks: hooksFor(kind, { taskId: task.id, conversationId: task.conversationId }),
					models: options.models,
					tools: self.tools,
					registries: {
						sections: { map: self.sectionMap, get revision() { return self.revisions.sections; } },
						tools: { map: self.tools, get revision() { return self.revisions.tools; } },
					},
					kinds: self.kinds,
					rewindableAsOf: (c, at, cx) => self.session.read((s) => s.docAsOf(c, at, cx)) as Promise<RewindableState | undefined>,
					abortConversation: async (id, cx) => { const h = await self.conversation(id, cx); if (h) await h.abort(cx); },
					processHost: options.processHost,
					plugins: self.plugins,
					waitForTask: (id, c) => self.scheduler.waitForTask(id, c),
					waitForInput: (id, c) => self.scheduler.waitForInput(id, c),
					abortTask: (id, c) => self.scheduler.abortTask(id, c),
					now: () => Date.now(),
					sleep: (untilMs, c) => new Promise((resolve, reject) => {
						const t = setTimeout(resolve, Math.max(0, untilMs - Date.now()));
						c.abortSignal?.addEventListener("abort", () => { clearTimeout(t); reject(c.abortSignal?.reason); });
					}),
					context: (c, at, cx) => self.session.commit({ type: "host" }, (tx) => tx.context(c, at), cx).then((r) => r.value),
					newestEntry: (c, o, cx) => self.session.commit({ type: "host" }, (tx) => tx.newestEntry(c, o), cx).then((r) => r.value),
					rewindable: (c, cx) => self.session.commit({ type: "host" }, (tx) => tx.snapshot({ doc: "rewindable", conversationId: c }), cx, { docs: [{ doc: "rewindable", conversationId: c }] }).then((r) => r.value),
					sticky: (c, cx) => self.session.commit({ type: "host" }, (tx) => tx.snapshot({ doc: "sticky", conversationId: c }), cx, { docs: [{ doc: "sticky", conversationId: c }] }).then((r) => r.value),
				};
			},
		});
	}

	private async init(options: HarnessOptions<Ks>) {
		const { storage } = this.session;
		// Root conversation on a fresh store.
		const conversations = await storage.conversations(this.ctx);
		if (conversations.length === 0) {
			await this.session.commit({ type: "host" }, (tx) => tx.createConversation({ rewindable: options.root?.rewindable, sticky: options.root?.sticky }), this.ctx);
		} else {
			for (const c of conversations) if (c.owner !== undefined) this.recordAncestry(c, conversations);
		}
		// Load live tasks; orphan the ones with no kind.
		for (const t of await storage.scanTasks({ status: ["pending", "running"] }, this.ctx)) this.session.liveTasks.set(t.id, t);
		this.session.listeners.add((r) => {
			for (const c of r.effects.conversations) if (c.owner !== undefined) this.recordAncestry(c, undefined);
		});
	}

	private recordAncestry(c: Conversation, all: Conversation[] | undefined) {
		const owner = this.session.liveTasks.get(c.owner!)?.conversationId ?? all?.find((x) => x.id === c.owner)?.id;
		if (owner === undefined) return;
		this.ancestry.set(c.id, [...(this.ancestry.get(owner) ?? []), owner]);
	}

	resume() {
		this.scheduler.resume();
	}

	/** Registries. Registering bumps a revision that in-flight preparations compare against (§12.5). */
	registerTool(tool: ToolDeclaration): () => void {
		this.tools.set(tool.name, tool);
		this.revisions.tools++;
		return () => { this.tools.delete(tool.name); this.revisions.tools++; };
	}
	registerSection(section: SystemSection): () => void {
		this.sectionMap.set(section.key, section);
		this.revisions.sections++;
		return () => { this.sectionMap.delete(section.key); this.revisions.sections++; };
	}
	async close(ctx: Context) {
		this.scheduler.stop();
		await this.scheduler.joinAll();
		await this.session.close(ctx);
	}

	/** Register handlers for one kind's hook points, harness-wide. */
	hooks<K extends AnyKind>(kind: K, handlers: Partial<HooksOf<K>>): () => void {
		const reg: HookRegistration = { kind, handlers };
		this.hookRegistrations.push(reg);
		return () => void this.hookRegistrations.splice(this.hookRegistrations.indexOf(reg), 1);
	}

	async root(ctx: Context): Promise<ConversationHandle<ConfigFor<Ks>>> {
		return this.conversation(1, ctx).then((c) => c!);
	}

	async conversation(id: Id, ctx: Context): Promise<ConversationHandle<ConfigFor<Ks>> | undefined> {
		const c = await this.session.read((s) => s.conversation(id, ctx));
		if (c === undefined) return undefined;
		return this.handle(c);
	}

	async createConversation(spec: ConversationSpec & { input?: UserInput }, ctx: Context): Promise<ConversationHandle<ConfigFor<Ks>>> {
		const id = spec.parent === undefined
			? (await this.session.commit({ type: "host" }, (tx) => tx.createConversation(spec), ctx)).value
			: await this.session.fork(spec.parent.conversationId, spec.parent.at, spec, ctx);
		const h = await this.conversation(id, ctx);
		if (spec.input !== undefined) await h!.send({ content: spec.input }, ctx);
		return h!;
	}

	waitForIdle(ctx: Context): Promise<void> {
		return this.waitIdle(undefined, ctx);
	}
	abortTask(id: Id, ctx: Context): Promise<"marked" | "terminal"> {
		return this.scheduler.abortTask(id, ctx);
	}
	entries(scan: EntryScan, ctx: Context): Promise<Entry[]> {
		return this.session.read((s) => s.scanEntries(scan, ctx));
	}

	private waitIdle(conversationId: Id | undefined, ctx: Context): Promise<void> {
		return new Promise((resolve, reject) => {
			const check = () => this.scheduler.isIdle(conversationId);
			if (check()) return resolve();
			const l = () => { if (check()) { this.session.listeners.delete(l); resolve(); } };
			this.session.listeners.add(l);
			ctx.abortSignal?.addEventListener("abort", () => { this.session.listeners.delete(l); reject(ctx.abortSignal?.reason); });
		});
	}

	private handle(c: Conversation): ConversationHandle<ConfigFor<Ks>> {
		const self = this;
		const host = { type: "host" as const };
		const docs: DocRef[] = [{ doc: "rewindable", conversationId: c.id }, { doc: "sticky", conversationId: c.id }];
		const commit = <T>(fn: (tx: Tx) => T | Promise<T>, ctx: Context) => self.session.commit(host, fn, ctx, { docs }).then((r) => r.value);
		const config: ConfigFacade<ConfigFor<Ks>> = {
			get: (ctx) => commit((tx) => {
				const r = tx.snapshot({ doc: "rewindable", conversationId: c.id }) as Record<string, unknown>;
				const s = tx.snapshot({ doc: "sticky", conversationId: c.id }) as Record<string, unknown>;
				const out: Record<string, unknown> = {};
				for (const [key, doc] of self.configRoutes) out[key] = (doc === "rewindable" ? r : s)[key] ?? self.defaultFor(key);
				return out as ConfigFor<Ks>;
			}, ctx),
			set: (patch, ctx) => commit((tx) => {
				for (const [key, value] of Object.entries(patch)) {
					const doc = self.configRoutes.get(key);
					if (doc === undefined) throw new Error(`unknown config key "${key}"`);
					(doc === "rewindable" ? tx.rewindable(c.id) : tx.sticky(c.id))[key] = value;
				}
			}, ctx),
		};
		return {
			id: c.id,
			config,
			async send(input, ctx) {
				const id = await commit((tx) => tx.send(c.id, input), ctx);
				self.scheduler.resume();
				return self.inputHandle(id, c.id);
			},
			write: (entry, ctx) => commit((tx) => tx.write(c.id, entry), ctx),
			commit,
			rewindable: (ctx) => commit((tx) => tx.snapshot({ doc: "rewindable", conversationId: c.id }), ctx),
			sticky: (ctx) => commit((tx) => tx.snapshot({ doc: "sticky", conversationId: c.id }), ctx),
			async fork(at, spec, ctx) {
				const id = await self.session.fork(c.id, at, spec, ctx);
				return (await self.conversation(id, ctx))!;
			},
			collapse: (instructions, ctx) =>
				commit(async (tx) => {
					const { entries } = await tx.context(c.id);
					const { keepRecent } = tx.rewindable(c.id);
					const through = (await import("./kinds/others.ts")).chooseThrough(entries, keepRecent);
					if (through === undefined) throw new Error("nothing to collapse");
					return tx.createTask({ kind: "knightcode.collapse", conversationId: c.id, background: true, input: { reason: "manual", through, ...(instructions ? { instructions } : {}) } });
				}, ctx),
			reset: (handoff, ctx) =>
				commit(async (tx) => {
					await tx.write(c.id, handoff === undefined ? { kind: "knightcode.reset", head: "self" } : { kind: "knightcode.handoff", head: "self", model: [{ role: "user", content: handoff, timestamp: Date.now() }] });
				}, ctx),
			async abort(ctx) {
				// Foreground set: live non-background tasks here, plus conversations they own, recursively.
				const set: Task[] = [];
				const visit = (conversationId: Id) => {
					for (const t of self.session.liveTasks.values()) {
						if (t.conversationId !== conversationId || t.background) continue;
						set.push(t);
						for (const owned of t.owns) visit(owned);
					}
				};
				visit(c.id);
				await commit(async (tx) => {
					for (const t of set) await tx.markTask(t.id);
					const s = tx.sticky(c.id);
					const withdrawn = s.inbox.filter((q) => q.mode !== "write").map((q) => q.id);
					removeWhere(s.inbox, (q) => q.mode !== "write");
					await tx.resolveInputs(withdrawn, { status: "unanswered", reason: "aborted" });
				}, ctx);
				for (const t of set) await self.scheduler.abortTask(t.id, ctx);
				// Resolve when the whole foreground set is terminal, owned conversations included.
				await Promise.all([...new Set([c.id, ...set.flatMap((t) => t.owns)])].map((id) => self.waitIdle(id, ctx)));
			},
			waitForIdle: (ctx) => self.waitIdle(c.id, ctx),
			hooks(kind, handlers, opts) {
				const reg: HookRegistration = { kind, handlers, conversationId: c.id, subtree: opts?.subtree };
				self.hookRegistrations.push(reg);
				return () => void self.hookRegistrations.splice(self.hookRegistrations.indexOf(reg), 1);
			},
			async watch(ctx) {
				// Subscribe INSIDE the capture commit, on the line, so every commit after
				// this one is delivered. Deltas are buffered until start() is called.
				let listener: ((d: ConversationDelta) => void) | undefined;
				const buffer: ConversationDelta[] = [];
				const onCommit = (r: CommitResult<unknown>) => {
					const d: ConversationDelta = {
						entries: r.effects.entries.filter((e) => e.conversationId === c.id),
						tasks: r.effects.tasks.filter((t) => t.conversationId === c.id),
					};
					for (const { ref, ops } of r.effects.docs) {
						if (ref.doc === "rewindable" && ref.conversationId === c.id) d.rewindable = ops;
						if (ref.doc === "sticky" && ref.conversationId === c.id) d.sticky = ops;
					}
					if (!(d.entries.length || d.tasks.length || d.rewindable || d.sticky)) return;
					if (listener) listener(d);
					else buffer.push(d);
				};
				const view = await self.session.commit(host, async (tx): Promise<ConversationView> => {
					const { head } = await tx.context(c.id);
					const all = await tx.scanEntries({ conversationId: c.id, limit: 100_000 });
					const boundary = head?.head ?? 0;
					const entries = all.filter((e) => e.id >= boundary).reverse();
					const tasks = [...self.session.liveTasks.values()].filter((t) => t.conversationId === c.id);
					self.session.listeners.add(onCommit); // on the line: nothing can land between capture and subscribe
					return { conversation: c, entries, tasks, rewindable: tx.snapshot({ doc: "rewindable", conversationId: c.id }), sticky: tx.snapshot({ doc: "sticky", conversationId: c.id }) };
				}, ctx, { docs }).then((r) => r.value);
				return {
					view,
					start: (l) => {
						listener = l;
						for (const d of buffer.splice(0)) l(d);
					},
					stop: () => self.session.listeners.delete(onCommit),
				};
			},
		};
	}

	private defaultFor(key: string): unknown {
		for (const k of this.kinds.values()) for (const doc of ["rewindable", "sticky"] as const) { const cfg = k.config?.[doc] as Record<string, unknown> | undefined; if (cfg && key in cfg) return cfg[key]; }
		return undefined;
	}

	private inputHandle(id: Id, conversationId: Id): InputHandle {
		const self = this;
		return {
			id,
			result: (ctx) => self.session.read((s) => s.input(id, ctx)),
			wait: (ctx) => self.scheduler.waitForInput(id, ctx),
			abort: (ctx) =>
				self.session.commit({ type: "host" }, async (tx) => {
					const i = await tx.input(id);
					if (i === undefined) return "not_found" as const;
					if (i.status !== "queued") return "already_placed" as const;
					removeWhere(tx.sticky(conversationId).inbox, (q) => q.id === id);
					await tx.setInput(id, { status: "unanswered", reason: "aborted" });
					return "aborted" as const;
				}, ctx, { docs: [{ doc: "sticky", conversationId }] }).then((r) => r.value),
		};
	}
}

export { defaultRewindable, defaultSticky, withAbortSignal };
/** The built-in kinds, as typed witnesses for `api.task`, `waitForTask`, and `hooks(kind, …)`. */
export const kinds = { generation, tool, postTools, collapse, job, plugin } as const;
export const entries = builtinEntries;
