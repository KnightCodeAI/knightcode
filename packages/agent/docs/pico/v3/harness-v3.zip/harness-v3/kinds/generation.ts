import type { Context } from "@knightcode/chord";
import type { AssistantMessage, AssistantMessageFrame, DeferredHandle, ToolCall } from "@knightcode/ai";
import { AssistantMessageFrameEncoder, isRetryableAssistantError, retryDelayMs } from "@knightcode/ai";
import { estimateContextTokens } from "@knightcode/ai/utils/estimate";
import { planManagedEntry, prepareDraft, sameSnapshot, type SystemInstructionsHooks, takeSnapshot } from "../system.ts";
import type { Closure, Completion, HookInfo, Id, Kind, ModelRef, RequestMessage, RetryPolicy, Runtime, Step, SystemMessage, Task, ThinkingLevel, Tx } from "../types.ts";
import { applyFrame } from "./frames.ts";
import { chooseThrough } from "./others.ts";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface GenerationInput {
	inputs: Id[];
}
/** Captured once at `prepared`; carried unchanged except `attempt`. */
interface Prep {
	cutoff: Id;
	system: Id | null;
	model: ModelRef;
	thinkingLevel: ThinkingLevel;
	tools: string[];
	retry: RetryPolicy;
	attempt: number;
}
export type GenerationCheckpoint =
	| ({ phase: "prepared" } & Prep)
	| ({ phase: "requesting" } & Prep)
	| ({ phase: "retrying"; untilMs: number; lastError: string } & Prep)
	| ({ phase: "deferred"; handle: DeferredHandle } & Prep);
export interface GenerationResult {
	assistant: Id;
	tools: Id[];
	postTools?: Id;
	successor?: Id;
}
export interface GenerationFailure {
	reason: "provider" | "overflow" | "retries_exhausted" | "no_model";
	detail: string;
	assistant?: Id;
}

/** Hook points this kind calls. Register with `h.hooks(kinds.generation, { … })`. */
export interface GenerationHooks extends SystemInstructionsHooks {
	/** Before every request (also on retry and recovery). Chain. */
	beforeRequest(request: { messages: RequestMessage[] }, info: HookInfo & { cutoff: Id }, ctx: Context): { messages: RequestMessage[] } | void | Promise<{ messages: RequestMessage[] } | void>;
	/** Every terminal provider message, before classification. Observer. */
	afterResponse(message: AssistantMessage, info: HookInfo & { attempt: number }, ctx: Context): void | Promise<void>;
	/** On a final answer with nothing queued. First `{ continue }` wins and starts a continuation. */
	onYield(answer: AssistantMessage, info: HookInfo, ctx: Context): { continue: string } | void | Promise<{ continue: string } | void>;
}

/** Configuration this kind reads, with defaults. `model` has none: absent → failed/no_model. */
export const generationConfig = {
	rewindable: { model: undefined as ModelRef | undefined, thinkingLevel: "off" as ThinkingLevel, selectedTools: [] as string[], profile: "default" as string },
	sticky: { retry: { enabled: true, maxRetries: 3, baseDelayMs: 2000, maxAgentDelayMs: 60_000 } as RetryPolicy },
} as const;

type G = Task<GenerationInput, GenerationCheckpoint>;
type Rt = Runtime<GenerationHooks>;
type S = Step<GenerationCheckpoint, GenerationResult, GenerationFailure>;
type Out = Closure<GenerationResult, GenerationFailure>;

const fail = (reason: GenerationFailure["reason"], detail: string, assistant?: Id): Completion<GenerationResult, GenerationFailure> => ({ status: "failed", failure: { reason, detail, ...(assistant === undefined ? {} : { assistant }) } });
/** Every generation failure releases its input group (unanswered/failed) and clears the turn view. */
const failStep = (task: G, reason: GenerationFailure["reason"], detail: string): S => ({
	done: async (tx, current) => {
		tx.sticky(current.conversationId).turn = { tools: [] };
		await tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "failed", detail });
		return fail(reason, detail);
	},
});
const estimate = (messages: RequestMessage[]) => estimateContextTokens(messages.filter((m): m is Exclude<RequestMessage, SystemMessage> => m.role !== "system")).tokens;
const emptyUsage = (): AssistantMessage["usage"] => ({ input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } });

// ---------------------------------------------------------------------------
// The kind
// ---------------------------------------------------------------------------

export const generation: Kind<GenerationInput, GenerationCheckpoint, GenerationResult, GenerationFailure, { assistant?: Id }, GenerationHooks, typeof generationConfig> = {
	name: "knightcode.generation",
	core: true,
	turn: true,
	config: generationConfig,

	// Step 1 (§12.5): snapshot S on the line; systemInstructions off the line; then in one
	// commit re-take S′, retry if it moved, else append the managed entry and checkpoint
	// `prepared` with the cutoff. Runs once per generation; never on recovery.
	async initial(task, rt, ctx) {
		const info = { taskId: task.id, conversationId: task.conversationId };
		const { snapshot, canonical, seed } = await rt.commit((tx, current) => takeSnapshot(tx, current.conversationId, rt.registries.sections, rt.registries.tools), ctx);
		if (snapshot.settings.model === undefined) return failStep(task, "no_model", "no model configured");
		const retry = (await rt.sticky(task.conversationId, ctx)).retry;

		const { desired, tools } = await prepareDraft(rt, rt.registries.sections, canonical, seed, snapshot.settings, info, () => {}, ctx);
		const model = snapshot.settings.model as ModelRef;
		const thinkingLevel = snapshot.settings.thinkingLevel as ThinkingLevel;

		return {
			next: async (tx, current) => {
				const c = current.conversationId;
				const again = await takeSnapshot(tx, c, rt.registries.sections, rt.registries.tools);
				if (!sameSnapshot(again.snapshot, snapshot)) return "retry";
				const plan = await planManagedEntry(tx, c, snapshot, canonical, desired, tools, rt.now());
				const system = plan === undefined ? null : tx.appendEntry(c, { kind: "knightcode.system", ...plan });
				const cutoff = system ?? (await tx.newestEntry(c))!.id;
				tx.sticky(c).turn = { tools: [] }; // a new generation starts a fresh turn view
				return { phase: "prepared", cutoff, system, model, thinkingLevel, tools: tools.map((t) => t.name), retry, attempt: 0 };
			},
		};
	},

	phases: {
		// Step 2: derive the request from the cutoff (hooks rerun), overflow check, write the
		// in-flight checkpoint, call the provider. Reached fresh from `initial`/`retrying`,
		// and again on recovery of `prepared` (step 1 never reruns).
		async prepared(task, rt, ctx) {
			const cp = task.checkpoint;
			const model = rt.models.resolve(cp.model);
			if (model === undefined) return failStep(task, "no_model", `model ${cp.model.provider}/${cp.model.modelId} unavailable`);
			const derived = await derive(task, cp, rt, ctx);
			if (estimate(derived.messages) > model.contextWindow - model.maxTokens) return overflow(task, rt);
			const attempt = cp.attempt + 1;
			await rt.commit((tx) => tx.checkpoint({ ...cp, phase: "requesting", attempt }), ctx); // before the effect
			const { terminal, deferred } = await stream(cp, model, derived.messages, rt, ctx);
			if (deferred !== undefined) return { next: { ...cp, phase: "deferred", attempt, handle: deferred } };
			return classify(task, { ...cp, attempt }, terminal!, rt, ctx);
		},

		// Only reached by the scheduler after a crash: the call may have happened and there
		// is no result lookup. Count it as a failed attempt and retry per policy.
		async requesting(task, rt) {
			const cp = task.checkpoint;
			const decision = retryDecision(cp, null, rt.now());
			if (decision.kind === "fail") return failStep(task, decision.reason, "interrupted");
			return {
				next: (tx, current) => {
					tx.appendEntry(current.conversationId, { kind: "knightcode.usage", data: { attempt: cp.attempt, error: "interrupted" } });
					return { ...cp, phase: "retrying", untilMs: decision.untilMs, lastError: "interrupted" };
				},
			};
		},

		// Durable backoff, then back to step 2. Resets the streaming view.
		async retrying(task, rt, ctx) {
			const cp = task.checkpoint;
			await rt.sleep(cp.untilMs, ctx);
			const { untilMs: _u, lastError: _e, ...prep } = cp;
			return {
				next: (tx, current) => {
					tx.sticky(current.conversationId).turn.message = undefined;
					return { ...prep, phase: "prepared" };
				},
			};
		},

		// Provider-side async. Poll; not the retry backoff. Same after a crash: the handle is durable.
		async deferred(task, rt, ctx) {
			const cp = task.checkpoint;
			const model = rt.models.resolve(cp.model);
			if (model === undefined) return failStep(task, "no_model", "model disappeared");
			await rt.sleep(rt.now() + (cp.handle.pollAfterMs ?? 5000), ctx);
			const result = await rt.models.fetchDeferred(model, cp.handle, ctx);
			if ("deferred" in result && result.deferred !== undefined) return { next: { ...cp, handle: result.deferred } };
			const message = result as AssistantMessage;
			await rt.commit((tx, current) => {
				tx.sticky(current.conversationId).turn.message = message;
			}, ctx);
			const { handle: _h, ...prep } = cp;
			return classify(task, prep, message, rt, ctx);
		},
	},

	async abort(task, rt, ctx) {
		const cp = task.checkpoint;
		if (cp?.phase === "deferred") {
			const model = rt.models.resolve(cp.model);
			if (model) await rt.models.cancelDeferred(model, cp.handle, ctx).catch(() => {});
		}
		return async (tx, current) => {
			const partial = tx.sticky(current.conversationId).turn.message;
			let assistant: Id | undefined;
			if (partial && partial.content.length > 0) assistant = tx.appendEntry(current.conversationId, { kind: "knightcode.assistant", model: [{ ...partial, stopReason: "aborted" }], data: { attempt: cp?.attempt ?? 0 } });
			tx.sticky(current.conversationId).turn = { tools: [] };
			await tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "aborted" });
			return assistant === undefined ? {} : { assistant };
		};
	},
};

// ---------------------------------------------------------------------------
// Request derivation and streaming
// ---------------------------------------------------------------------------

async function derive(task: G, cp: Prep, rt: Rt, ctx: Context): Promise<{ messages: RequestMessage[] }> {
	const { messages } = await rt.context(task.conversationId, cp.cutoff, ctx);
	const info = { taskId: task.id, conversationId: task.conversationId, cutoff: cp.cutoff };
	let request = { messages };
	await rt.hooks.each(ctx, (h) => h.beforeRequest?.(request, info, ctx), (v) => { request = v; });
	return request;
}

/** Stream, coalescing frames into the turn view. Flush on size or time. */
async function stream(cp: Prep, model: NonNullable<ReturnType<Rt["models"]["resolve"]>>, messages: RequestMessage[], rt: Rt, ctx: Context): Promise<{ terminal?: AssistantMessage; deferred?: DeferredHandle }> {
	const encoder = new AssistantMessageFrameEncoder();
	let pending: AssistantMessageFrame[] = [];
	let pendingBytes = 0;
	let lastFlush = 0;
	let terminal: AssistantMessage | undefined;
	let deferred: DeferredHandle | undefined;
	const flush = async () => {
		const batch = pending;
		pending = [];
		pendingBytes = 0;
		lastFlush = rt.now();
		await rt.commit((tx, current) => { const turn = tx.sticky(current.conversationId).turn; for (const f of batch) applyFrame(turn, f); }, ctx);
	};
	try {
		for await (const event of rt.models.stream(model, { messages, thinkingLevel: cp.thinkingLevel }, ctx)) {
			if (event.type === "done") { encoder.encode(event); if (event.reason === "deferred" && event.message.deferred !== undefined) deferred = event.message.deferred; else terminal = event.message; break; }
			if (event.type === "error") { encoder.encode(event); terminal = event.error; break; }
			const frame = encoder.encode(event);
			if (frame === undefined) continue;
			pending.push(frame);
			pendingBytes += "delta" in frame ? frame.delta.length : 64;
			if (pendingBytes >= 256 || rt.now() - lastFlush >= 100) await flush();
		}
	} catch (error) {
		if (ctx.abortSignal?.aborted) throw error;
		terminal = { role: "assistant", content: [], api: model.api, provider: model.provider, model: model.id, usage: emptyUsage(), stopReason: "error", errorMessage: String(error), timestamp: rt.now() };
	}
	if (pending.length > 0) await flush();
	if (terminal === undefined && deferred === undefined) throw new Error("stream ended without a terminal message");
	return { terminal, deferred };
}

// ---------------------------------------------------------------------------
// Steps 3–5: classify the terminal message.
// ---------------------------------------------------------------------------

async function classify(task: G, cp: Prep, message: AssistantMessage, rt: Rt, ctx: Context): Promise<S> {
	const info = { taskId: task.id, conversationId: task.conversationId, attempt: cp.attempt };
	await rt.hooks.each(ctx, (h) => h.afterResponse?.(message, info, ctx));

	if (message.stopReason === "error") {
		const decision = retryDecision(cp, message, rt.now());
		if (decision.kind === "retry") {
			return {
				next: (tx, current) => {
					tx.appendEntry(current.conversationId, { kind: "knightcode.usage", data: { attempt: cp.attempt, usage: message.usage, error: message.errorMessage ?? "provider error" } });
					return { ...cp, phase: "retrying", untilMs: decision.untilMs, lastError: message.errorMessage ?? "provider error" };
				},
			};
		}
		return { done: terminalError(task, cp, message, decision.reason) };
	}
	if (message.stopReason === "aborted") return { done: terminalError(task, cp, message, "provider") };

	const calls = message.content.filter((c): c is ToolCall => c.type === "toolCall");
	if (calls.length > 0) {
		return {
			done: async (tx, current) => {
				const c = current.conversationId;
				const assistant = tx.appendEntry(c, { kind: "knightcode.assistant", model: [message], data: { attempt: cp.attempt } });
				const turn = tx.sticky(c).turn;
				turn.message = undefined;
				turn.tools = calls.map((call) => ({ callId: call.id, name: call.name, args: call.arguments }));
				const tools = calls.map((call, index) => tx.createTask({ kind: "knightcode.tool", input: { assistant, call, offered: cp.tools, index } }));
				const postTools = tx.createTask({ kind: "knightcode.post_tools", after: tools, input: { inputs: task.input.inputs, assistant, tools } });
				await maybeThresholdCollapse(tx, c, message);
				return { status: "completed", result: { assistant, tools, postTools } };
			},
		};
	}

	let continueText: string | undefined;
	await rt.hooks.each(ctx, (h) => h.onYield?.(message, info, ctx), (v) => { continueText = v.continue; return true; });
	return {
		done: async (tx, current) => {
			const c = current.conversationId;
			const assistant = tx.appendEntry(c, { kind: "knightcode.assistant", model: [message], data: { attempt: cp.attempt } });
			tx.sticky(c).turn = { tools: [] };
			await maybeThresholdCollapse(tx, c, message);
			const { triggers, terminated } = await tx.boundary(c, "final");
			if (continueText !== undefined && triggers.length === 0 && !terminated) {
				tx.appendEntry(c, { kind: "knightcode.user", model: [{ role: "user", content: continueText, timestamp: rt.now() }], data: { continuation: true, from: assistant } });
				const successor = tx.createTask({ kind: "knightcode.generation", input: { inputs: task.input.inputs } });
				return { status: "completed", result: { assistant, tools: [], successor } };
			}
			await tx.resolveInputs(task.input.inputs, { status: "done", answer: assistant });
			if (triggers.length > 0) {
				const successor = tx.createTask({ kind: "knightcode.generation", input: { inputs: triggers } });
				return { status: "completed", result: { assistant, tools: [], successor } };
			}
			return { status: "completed", result: { assistant, tools: [] } };
		},
	};
}

function terminalError(task: G, cp: Prep, message: AssistantMessage, reason: "provider" | "retries_exhausted"): Out {
	return async (tx, current) => {
		const assistant = tx.appendEntry(current.conversationId, { kind: "knightcode.assistant", model: [message], data: { attempt: cp.attempt } });
		tx.sticky(current.conversationId).turn = { tools: [] };
		await tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "failed", detail: message.errorMessage });
		return fail(reason, message.errorMessage ?? "provider error", assistant);
	};
}

type RetryDecision = { kind: "retry"; untilMs: number } | { kind: "fail"; reason: "provider" | "retries_exhausted" };
export function retryDecision(cp: { retry: RetryPolicy; attempt: number }, message: AssistantMessage | null, now: number): RetryDecision {
	if (message !== null && !isRetryableAssistantError(message)) return { kind: "fail", reason: "provider" };
	if (!cp.retry.enabled) return { kind: "fail", reason: "provider" };
	if (cp.attempt > cp.retry.maxRetries) return { kind: "fail", reason: "retries_exhausted" };
	return { kind: "retry", untilMs: now + retryDelayMs({ ...cp.retry, maxAgentDelayMs: cp.retry.maxAgentDelayMs ?? 60_000 }, cp.attempt) };
}

// ---------------------------------------------------------------------------
// Collapse triggers
// ---------------------------------------------------------------------------

async function maybeThresholdCollapse(tx: Tx, conversationId: Id, message: AssistantMessage) {
	const state = tx.rewindable(conversationId);
	if (state.threshold <= 0) return;
	const { entries, messages } = await tx.context(conversationId);
	const used = Math.max((message.usage?.input ?? 0) + (message.usage?.output ?? 0), estimate(messages));
	if (used <= state.threshold) return;
	const through = chooseThrough(entries, state.keepRecent);
	if (through !== undefined) tx.createTask({ kind: "knightcode.collapse", input: { reason: "threshold", through } });
}

function overflow(task: G, rt: Rt): S {
	return {
		done: async (tx, current) => {
			const c = current.conversationId;
			const state = tx.rewindable(c);
			const { entries } = await tx.context(c);
			const through = chooseThrough(entries, state.keepRecent);
			tx.sticky(c).turn = { tools: [] };
			if (through === undefined) {
				await tx.write(c, { kind: "knightcode.notice", model: [{ role: "user", content: "Context too large; nothing to compact.", timestamp: rt.now() }] });
				await tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "failed", detail: "overflow" });
				return fail("overflow", "request exceeds context window and nothing is collapsible");
			}
			const collapse = tx.createTask({ kind: "knightcode.collapse", input: { reason: "overflow", through } });
			tx.createTask({ kind: "knightcode.generation", after: [collapse], input: { inputs: task.input.inputs } });
			return fail("overflow", `collapsing through ${through}`);
		},
	};
}
