import type { AssistantMessage, ToolResultMessage, UserMessage } from "@knightcode/ai";
import { defineEntry, type Entry, type Id, type SystemMessage, type ToolControl } from "../types.ts";

export type UserEntry = Entry & { kind: "knightcode.user"; model: [UserMessage]; data?: { continuation: true; from: Id } };
export type AssistantEntry = Entry & { kind: "knightcode.assistant"; model: [AssistantMessage]; data: { attempt: number } };
export type ToolResultEntry = Entry & { kind: "knightcode.tool_result"; model: [ToolResultMessage]; data: { details?: unknown; diagnostics?: unknown; control?: ToolControl; truncated?: { bytes: number; lines: number } } };
export type SystemEntry = Entry & { kind: "knightcode.system"; model: [SystemMessage]; data: { baseline: boolean } };
export type NoticeEntry = Entry & { kind: "knightcode.notice"; model: [UserMessage] };
export type UsageEntry = Entry & { kind: "knightcode.usage"; data: { attempt: number; usage?: AssistantMessage["usage"]; error: string } };
export type SummaryEntry = Entry & { kind: "knightcode.summary"; model: [UserMessage]; data: { through: Id }; head: Id };
export type HandoffEntry = Entry & { kind: "knightcode.handoff"; model: [UserMessage]; head: Id };
export type ResetEntry = Entry & { kind: "knightcode.reset"; head: Id };

export const entries = {
	user: defineEntry<UserEntry>("knightcode.user"),
	assistant: defineEntry<AssistantEntry>("knightcode.assistant"),
	toolResult: defineEntry<ToolResultEntry>("knightcode.tool_result"),
	system: defineEntry<SystemEntry>("knightcode.system"),
	notice: defineEntry<NoticeEntry>("knightcode.notice"),
	usage: defineEntry<UsageEntry>("knightcode.usage"),
	summary: defineEntry<SummaryEntry>("knightcode.summary"),
	handoff: defineEntry<HandoffEntry>("knightcode.handoff"),
	reset: defineEntry<ResetEntry>("knightcode.reset"),
} as const;
