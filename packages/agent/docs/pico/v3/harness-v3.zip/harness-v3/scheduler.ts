import type { Context } from "@knightcode/chord";
import { withAbortSignal } from "@knightcode/chord/context";
import type { Session, TxImpl } from "./session.ts";
import type { AnyKind, Checkpoint, ContextView, Entry, Id, Input, Invoker, Outcome, PhaseHandler, Runtime, Step, Task } from "./types.ts";

interface Invocation {
	task: Task;
	mode: "run" | "abort";
	controller: AbortController;
	done: Promise<void>;
}

export interface SchedulerDeps {
	session: Session;
	kinds: ReadonlyMap<string, AnyKind>;
	runtime(task: Task, mode: "run" | "abort", ctx: Context): Runtime;
	ctx: Context;
}

/**
 * pico §6 and §7.1, unchanged in substance:
 *   eligible: live and (marked → fresh abort, ignoring deps)
 *                  or (pending, unmarked, every `after` terminal → running, run)
 *                  or (running, unmarked, no invocation → run)   ← recovery is the same call
 */
export class Scheduler {
	private enabled = false;
	private dirty = false;
	private draining = false;
	private readonly invocations = new Map<Id, Invocation>();
	private readonly taskWaiters = new Map<Id, Set<(t: Task) => void>>();
	private readonly inputWaiters = new Map<Id, Set<(i: Input) => void>>();

	constructor(private readonly deps: SchedulerDeps) {
		deps.session.listeners.add((r) => {
			// A mark landed by any commit revokes the running invocation: signal it so fresh abort can follow.
			for (const t of r.effects.tasks) {
				const inv = this.invocations.get(t.id);
				if (t.abort === true && inv?.mode === "run") inv.controller.abort();
			}
			for (const t of r.effects.tasks) if (t.status === "terminal") this.taskWaiters.get(t.id)?.forEach((w) => w(t));
			for (const i of r.effects.inputs) if (i.status === "done" || i.status === "unanswered") this.inputWaiters.get(i.id)?.forEach((w) => w(i));
			if (r.effects.tasks.length > 0) this.kick();
		});
	}

	resume() {
		this.enabled = true;
		this.kick();
	}
	stop() {
		this.enabled = false;
	}

	kick() {
		if (!this.enabled) return;
		this.dirty = true;
		if (!this.draining) void this.drain();
	}

	private async drain() {
		this.draining = true;
		try {
			while (this.dirty && this.enabled) {
				this.dirty = false;
				const reserved = await this.reserveEligible();
				for (const { task, mode } of reserved) this.dispatch(task, mode);
			}
		} catch (error) {
			if (!this.enabled) return; // closing
			throw error;
		} finally {
			this.draining = false;
		}
	}

	/** On the line: reserve every eligible task. */
	private async reserveEligible(): Promise<{ task: Task; mode: "run" | "abort" }[]> {
		const { session } = this.deps;
		const out: { task: Task; mode: "run" | "abort" }[] = [];
		await session.commit({ type: "host" }, async (tx) => {
			for (const task of [...session.liveTasks.values()]) {
				const inv = this.invocations.get(task.id);
				if (task.abort === true) {
					if (inv?.mode === "abort") continue; // abort already running; repeat mark is a no-op
					if (inv?.mode === "run") continue; // old invocation still winding down; dispatch after it returns
					const running: Task = task.status === "pending" ? { ...task, status: "running" } : task;
					if (running !== task) tx.setTask(running);
					out.push({ task: running, mode: "abort" });
					continue;
				}
				if (inv !== undefined) continue;
				if (task.status === "pending") {
					const deps = await Promise.all(task.after.map((id) => tx.task(id)));
					if (!deps.every((d) => d?.status === "terminal")) continue;
					const running: Task = { ...task, status: "running" };
					tx.setTask(running);
					out.push({ task: running, mode: "run" });
				} else if (task.status === "running") {
					out.push({ task, mode: "run" }); // loaded at open: dispatch into its current phase
				}
			}
		}, this.deps.ctx);
		return out;
	}

	/** Off the line: run the kind's phases, then its closure on the line. */
	private dispatch(task: Task, mode: "run" | "abort") {
		const { session, kinds } = this.deps;
		const kind = kinds.get(task.kind);
		if (kind === undefined) {
			void this.orphan(task);
			return;
		}
		const controller = new AbortController();
		const ctx = withAbortSignal(controller.signal, this.deps.ctx);
		const rt = this.deps.runtime(task, mode, ctx);
		const invoker: Invoker = { type: "task", id: task.id, conversationId: task.conversationId, core: kind.core === true, mode };

		const done = (async () => {
			try {
				if (mode === "run") {
					const closure = await this.runPhases(task, kind, rt, invoker, ctx);
					if (closure === undefined || controller.signal.aborted) return; // marked meanwhile: discard closure, fresh abort follows
					await session.commit(invoker, async (tx) => {
						const current = session.liveTasks.get(task.id);
						if (current === undefined || current.abort === true) return; // discard
						const completion = (await closure(tx, current)) as Outcome;
						tx.setTask({ ...current, status: "terminal", outcome: completion });
					}, ctx);
				} else {
					const closure = await kind.abort(task as never, rt as never, ctx);
					await session.commit(invoker, async (tx) => {
						const current = session.liveTasks.get(task.id);
						if (current === undefined) return;
						const result = await closure(tx, current);
						tx.setTask({ ...current, status: "terminal", outcome: { status: "aborted", result } });
					}, ctx);
				}
			} catch (error) {
				if (controller.signal.aborted) return; // cancelled: fresh abort will run
				if (mode === "abort") throw error; // a failing abort faults
				// A throwing run is a domain failure with no typed outcome: terminalize failed.
				await session.commit(invoker, async (tx) => {
					const current = session.liveTasks.get(task.id);
					if (current === undefined || current.abort === true) return;
					tx.setTask({ ...current, status: "terminal", outcome: { status: "failed", failure: { reason: "threw", detail: String(error) } } });
				}, ctx);
			} finally {
				this.invocations.delete(task.id);
				const terminal = !session.liveTasks.has(task.id);
				if (terminal && this.enabled) await session.retire(task, this.deps.ctx).catch(() => {});
				this.kick();
			}
		})();
		this.invocations.set(task.id, { task, mode, controller, done });
	}

	/**
	 * The phase loop. No checkpoint → `initial`; otherwise the handler for the current
	 * phase. A step either finishes (return its closure) or names the next checkpoint,
	 * written on the line — possibly by a builder that may terminalize instead, or ask
	 * for the same handler to run again ("retry": its snapshot went stale).
	 */
	private async runPhases(task: Task, kind: AnyKind, rt: Runtime, invoker: Invoker, ctx: Context): Promise<((tx: import("./session.ts").TxImpl, current: Task) => unknown) | undefined> {
		const { session } = this.deps;
		let current = task;
		for (;;) {
			const cp = current.checkpoint as Checkpoint | undefined;
			const handler = cp === undefined ? kind.initial : (kind.phases as Record<string, PhaseHandler<unknown, Checkpoint, string, unknown, unknown, object>>)[cp.phase];
			if (handler === undefined) throw new Error(`${kind.name}: no handler for phase ${cp?.phase}`);
			const step: Step<Checkpoint, unknown, unknown> = await handler(current as never, rt as never, ctx);
			if ("done" in step) return step.done as never;
			if (ctx.abortSignal?.aborted) return undefined;
			const outcome = await session.commit(invoker, async (tx) => {
				const live = session.liveTasks.get(task.id);
				if (live === undefined || live.abort === true) return "discard" as const;
				const next = typeof step.next === "function" ? await step.next(tx, live) : step.next;
				if (next === "retry") return "retry" as const;
				if ("status" in next) {
					tx.setTask({ ...live, status: "terminal", outcome: next as Outcome });
					return "terminal" as const;
				}
				tx.checkpoint(next);
				current = { ...live, checkpoint: next };
				return "advanced" as const;
			}, ctx);
			if (outcome.value === "retry") { current = session.liveTasks.get(task.id) ?? current; continue; }
			if (outcome.value !== "advanced") return undefined;
		}
	}

	/** Mark, revoke, signal, join. The scheduler then reserves the fresh abort on its next drain. */
	async abortTask(id: Id, ctx: Context): Promise<"marked" | "terminal"> {
		const { session } = this.deps;
		const r = await session.commit({ type: "host" }, (tx) => tx.markTask(id), ctx);
		if (r.value === "terminal") return "terminal";
		const inv = this.invocations.get(id);
		if (inv?.mode === "run") {
			inv.controller.abort();
			await inv.done.catch(() => {});
		}
		this.kick();
		return "marked";
	}

	private async orphan(task: Task) {
		await this.deps.session.commit({ type: "host" }, (tx) => {
			tx.setTask({ ...task, status: "terminal", outcome: { status: "orphaned" } });
		}, this.deps.ctx);
	}

	waitForTask(id: Id, ctx: Context): Promise<Task> {
		return new Promise((resolve, reject) => {
			const live = this.deps.session.liveTasks.get(id);
			if (live === undefined) {
				void this.deps.session.storage.task(id, ctx).then((t) => (t ? resolve(t) : reject(new Error(`task ${id} not found`))));
				return;
			}
			const set = this.taskWaiters.get(id) ?? new Set();
			this.taskWaiters.set(id, set);
			const w = (t: Task) => {
				set.delete(w);
				resolve(t);
			};
			set.add(w);
			ctx.abortSignal?.addEventListener("abort", () => {
				set.delete(w);
				reject(ctx.abortSignal?.reason);
			});
		});
	}

	waitForInput(id: Id, ctx: Context): Promise<Input> {
		return new Promise((resolve, reject) => {
			void this.deps.session.storage.input(id, ctx).then((i) => {
				if (i === undefined) return reject(new Error(`input ${id} not found`));
				if (i.status === "done" || i.status === "unanswered") return resolve(i);
				const set = this.inputWaiters.get(id) ?? new Set();
				this.inputWaiters.set(id, set);
				const w = (r: Input) => {
					set.delete(w);
					resolve(r);
				};
				set.add(w);
				ctx.abortSignal?.addEventListener("abort", () => {
					set.delete(w);
					reject(ctx.abortSignal?.reason);
				});
			});
		});
	}

	/** Signal and join every invocation (close). */
	async joinAll() {
		for (const inv of this.invocations.values()) inv.controller.abort();
		await Promise.allSettled([...this.invocations.values()].map((i) => i.done));
	}

	isIdle(conversationId?: Id): boolean {
		for (const t of this.deps.session.liveTasks.values()) {
			if (t.background) continue;
			if (conversationId !== undefined && t.conversationId !== conversationId) continue;
			return false;
		}
		return true;
	}
}

export type { ContextView, Entry, TxImpl };
