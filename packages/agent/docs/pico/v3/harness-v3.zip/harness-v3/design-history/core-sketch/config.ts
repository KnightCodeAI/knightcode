import type { RetryPolicy } from "@knightcode/ai";
import type { ThinkingLevel } from "../../types.ts";
import { internalConversationValue } from "./addresses.ts";
import type { Stored } from "./core.ts";
import type { ConfigBundle } from "./tasks.ts";

export type ModelRef = { readonly provider: string; readonly modelId: string };

// §2.1 — the fixed bundles, verbatim.

export const generationConfig = {
	model: internalConversationValue<ModelRef, true>("knightcode.model", { rewind: true }),
	thinkingLevel: internalConversationValue<ThinkingLevel, true>("knightcode.thinking", { rewind: true, default: "off" }),
	selectedTools: internalConversationValue<readonly string[], true>("knightcode.tools.selected", { rewind: true, default: [] }),
	profile: internalConversationValue<string, true>("knightcode.prompt.profile", { rewind: true, default: "default" }),
	retry: internalConversationValue<Stored<RetryPolicy>, false>("knightcode.generation.retry", {
		rewind: false,
		default: { enabled: true, maxRetries: 3, baseDelayMs: 2000, maxAgentDelayMs: 60_000 },
	}),
} satisfies ConfigBundle;

export const postToolsConfig = {
	steeringMode: internalConversationValue<"all" | "one-at-a-time", false>("knightcode.queue.steering", {
		rewind: false,
		default: "one-at-a-time",
	}),
	followUpMode: internalConversationValue<"all" | "one-at-a-time", false>("knightcode.queue.follow_up", {
		rewind: false,
		default: "one-at-a-time",
	}),
} satisfies ConfigBundle;

export const toolConfig = {} satisfies ConfigBundle;

export const collapseConfig = {
	threshold: internalConversationValue<number, true>("knightcode.collapse.threshold", { rewind: true, default: 0 }),
	keepRecent: internalConversationValue<number, true>("knightcode.collapse.keep_recent", { rewind: true, default: 20_000 }),
} satisfies ConfigBundle;
