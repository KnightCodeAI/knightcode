import type { AssistantMessage, RetryPolicy } from "@knightcode/ai";
import { isRetryableAssistantError, retryDelayMs } from "@knightcode/ai";
import type { Stored } from "./core.ts";

/**
 * One retry decision for both generation (§10.1 step 3) and collapse (§10.4).
 *
 * `message === null` is an interruption (recover of an inflight phase): the
 * call may have happened, there is no result lookup, so it counts as a
 * retryable failed attempt for the persisted attempt number.
 */
export type RetryDecision =
	| { readonly kind: "retry"; readonly untilMs: number }
	| { readonly kind: "fail"; readonly reason: "provider" | "retries_exhausted" };

export function decideRetry(
	policy: Stored<RetryPolicy>,
	attempt: number,
	message: AssistantMessage | null,
	now: number,
): RetryDecision {
	if (message !== null && !isRetryableAssistantError(message)) return { kind: "fail", reason: "provider" };
	if (!policy.enabled) return { kind: "fail", reason: "provider" };
	if (attempt > policy.maxRetries) return { kind: "fail", reason: "retries_exhausted" };
	return { kind: "retry", untilMs: now + retryDelayMs(policy as RetryPolicy, attempt) };
}

export function errorDetail(message: AssistantMessage | null, fallback: string): string {
	if (message === null) return fallback;
	return message.errorMessage ?? fallback;
}
