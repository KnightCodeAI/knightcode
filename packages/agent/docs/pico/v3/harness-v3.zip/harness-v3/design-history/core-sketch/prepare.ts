import type { Context } from "@knightcode/chord";
import type { SystemMessage, Tool } from "@knightcode/ai";
import type { RuntimeRegistries, RuntimeTranscriptReads, SystemSection, ToolDeclaration, TranscriptReads } from "./assumed.ts";
import { generationConfig } from "./config.ts";
import type { Id, JsonValue, Stored } from "./core.ts";
import { type ContextEdit, defineEntry, type Entry, type EntryBase, type SectionRecord, type SystemEntryData } from "./entries.ts";
import type { HookRunner } from "./hooks.ts";
import { generationHooks, type Settings, type SystemSectionDraft } from "./witnesses.ts";

// ---------------------------------------------------------------------------
// Entry witness
// ---------------------------------------------------------------------------

export type SystemEntry = EntryBase & {
	readonly model: readonly [] | readonly [Stored<SystemMessage>];
	readonly data: SystemEntryData;
	readonly edits?: readonly ContextEdit[];
};
export const systemEntry = defineEntry<SystemEntry>("knightcode.system");

// ---------------------------------------------------------------------------
// Canonical section state (§12.4): fold fork-visible managed entries from the
// newest baseline forward. Head- and edit-independent by design.
// ---------------------------------------------------------------------------

type SectionState = { readonly value: JsonValue; readonly rendered: string };
type Canonical = ReadonlyMap<string, SectionState>; // insertion order = canonical order

async function foldCanonical(reads: TranscriptReads, conversationId: Id): Promise<{ canonical: Canonical; newestManaged: Id | null; newestBaseline: Id | null }> {
	// Newest-first scan of knightcode.system only. Collect until we pass a baseline.
	const managed: SystemEntry[] = [];
	let cursor: Id | undefined;
	let baselineId: Id | null = null;
	scan: for (;;) {
		const page = await reads.scanEntries({ conversationId, kind: "knightcode.system", limit: 64, ...(cursor === undefined ? {} : { cursor }) });
		for (const entry of page.items) {
			if (!systemEntry.is(entry)) continue;
			managed.push(entry);
			if (entry.data.baseline === true) {
				baselineId = entry.id;
				break scan;
			}
		}
		if (!page.more) break;
		cursor = page.items[page.items.length - 1]!.id;
	}
	managed.reverse(); // chronological, baseline first if any

	const canonical = new Map<string, SectionState>();
	for (const entry of managed) {
		for (const record of entry.data.sections) {
			if (record.action === "remove") canonical.delete(record.key);
			else canonical.set(record.key, { value: record.value, rendered: record.rendered });
		}
	}
	const newest = managed[managed.length - 1];
	return { canonical, newestManaged: newest?.id ?? null, newestBaseline: baselineId };
}

// ---------------------------------------------------------------------------
// Draft (§12.2)
// ---------------------------------------------------------------------------

class Draft implements SystemSectionDraft {
	private readonly values = new Map<string, JsonValue>();
	private readonly wrappers = new Map<string, ((rendered: string) => string)[]>();
	private readonly touched = new Set<string>();
	private readonly deleted = new Set<string>();

	constructor(private readonly sections: RuntimeRegistries["registries"]["sections"], seed: Canonical) {
		for (const [key, state] of seed) this.values.set(key, state.value);
	}

	get<T extends JsonValue>(section: SystemSection<T>): T | undefined {
		const value = this.values.get(section.key);
		return value === undefined ? undefined : (structuredClone(value) as T);
	}
	set<T extends JsonValue>(section: SystemSection<T>, value: T): void {
		this.values.set(section.key, value);
		this.deleted.delete(section.key);
		this.touched.add(section.key);
	}
	delete(section: { readonly key: string }): void {
		this.values.delete(section.key);
		this.wrappers.delete(section.key);
		this.deleted.add(section.key);
		this.touched.add(section.key);
	}
	wrap<T extends JsonValue>(section: SystemSection<T>, transform: (rendered: string) => string): void {
		const list = this.wrappers.get(section.key) ?? [];
		list.push(transform);
		this.wrappers.set(section.key, list);
		this.touched.add(section.key);
	}

	/** Snapshot for rollback of a throwing handler's edits. */
	snapshot() {
		return { values: new Map(this.values), wrappers: new Map(this.wrappers), touched: new Set(this.touched), deleted: new Set(this.deleted) };
	}
	restore(s: ReturnType<Draft["snapshot"]>) {
		this.values.clear(); for (const [k, v] of s.values) this.values.set(k, v);
		this.wrappers.clear(); for (const [k, v] of s.wrappers) this.wrappers.set(k, v);
		this.touched.clear(); for (const k of s.touched) this.touched.add(k);
		this.deleted.clear(); for (const k of s.deleted) this.deleted.add(k);
	}

	/** Render touched sections; wrappers apply after rendering, in registration order. */
	freeze(canonical: Canonical): { desired: Canonical; removed: readonly string[] } {
		const desired = new Map<string, SectionState>();
		for (const [key, value] of this.values) {
			if (!this.touched.has(key)) {
				const existing = canonical.get(key);
				if (existing) desired.set(key, existing); // untouched keeps previous rendered text
				continue;
			}
			const definition = this.sections.get(key);
			if (definition === undefined) continue; // unregistered: keep stored payload, cannot re-render
			let rendered = definition.render(value);
			for (const wrap of this.wrappers.get(key) ?? []) rendered = wrap(rendered);
			desired.set(key, { value, rendered });
		}
		return { desired, removed: [...this.deleted].filter((key) => canonical.has(key)) };
	}
}

// ---------------------------------------------------------------------------
// Snapshot S (§12.5). Compared field-by-field on the line before commit.
// ---------------------------------------------------------------------------

export interface PreparationSnapshot {
	readonly newestManaged: Id | null;
	readonly newestBaseline: Id | null;
	readonly newestHead: Id | null;
	readonly settings: Settings;
	readonly sectionsRev: number;
	readonly toolsRev: number;
}

function sameSnapshot(a: PreparationSnapshot, b: PreparationSnapshot): boolean {
	return (
		a.newestManaged === b.newestManaged &&
		a.newestBaseline === b.newestBaseline &&
		a.newestHead === b.newestHead &&
		a.sectionsRev === b.sectionsRev &&
		a.toolsRev === b.toolsRev &&
		JSON.stringify(a.settings) === JSON.stringify(b.settings)
	);
}

export async function takeSnapshot(
	reads: TranscriptReads & { value: (def: (typeof generationConfig)[keyof typeof generationConfig]) => { get(): Promise<unknown> } },
	registries: RuntimeRegistries["registries"],
	conversationId: Id,
): Promise<{ snapshot: PreparationSnapshot; canonical: Canonical }> {
	const { canonical, newestManaged, newestBaseline } = await foldCanonical(reads, conversationId);
	const head = await reads.newestHead(conversationId);
	const settings: Settings = {
		model: (await reads.value(generationConfig.model).get()) as Settings["model"],
		thinkingLevel: (await reads.value(generationConfig.thinkingLevel).get()) as string,
		selectedTools: (await reads.value(generationConfig.selectedTools).get()) as readonly string[],
		profile: (await reads.value(generationConfig.profile).get()) as string,
	};
	return {
		snapshot: { newestManaged, newestBaseline, newestHead: head?.id ?? null, settings, sectionsRev: registries.sections.revision, toolsRev: registries.tools.revision },
		canonical,
	};
}

// ---------------------------------------------------------------------------
// Off-line phase: run systemInstructions handlers, render, collect tools.
// ---------------------------------------------------------------------------

export interface PreparedDraft {
	readonly desired: Canonical;
	readonly removed: readonly string[];
	readonly tools: readonly ToolDeclaration[];
}

export async function runPreparation(
	hooks: HookRunner<typeof generationHooks>,
	registries: RuntimeRegistries["registries"],
	canonical: Canonical,
	settings: Settings,
	onReport: (message: string) => void,
	ctx: Context,
): Promise<PreparedDraft> {
	const draft = new Draft(registries.sections, canonical);

	// Default loadout: selectedTools resolved against the registry; unknown names dropped and reported.
	const defaultTools: ToolDeclaration[] = [];
	for (const name of settings.selectedTools) {
		const declaration = registries.tools.get(name);
		if (declaration === undefined) onReport(`selected tool ${name} is not registered`);
		else defaultTools.push(declaration);
	}

	// collect/skip: each handler's draft edits roll back on throw (§11.2 table note).
	// The runner handles the fold; rollback is ours because the runner does not see the draft.
	let tools: readonly ToolDeclaration[] = defaultTools;
	const before = draft.snapshot();
	const result = await hooks.run(generationHooks.systemInstructions, { sections: draft, config: settings, tools: defaultTools }, ctx);
	if (result.threw !== undefined) draft.restore(before);
	for (const output of result.outputs) if (output.tools !== undefined) tools = output.tools; // last override wins

	const { desired, removed } = draft.freeze(canonical);
	return { desired, removed, tools };
}

// ---------------------------------------------------------------------------
// On-line phase: diff desired against canonical, decide baseline vs delta,
// produce the managed entry input (or nothing). Called inside the `prepared`
// transition after re-taking the snapshot.
// ---------------------------------------------------------------------------

export interface ManagedEntryInput {
	readonly data: SystemEntryData;
	readonly model: readonly [] | readonly [Stored<SystemMessage>];
	readonly edits?: readonly ContextEdit[];
}

function toolOf(declaration: ToolDeclaration): Tool {
	return { name: declaration.name, description: declaration.description, parameters: declaration.parameters };
}

export async function planManagedEntry(
	reads: TranscriptReads,
	conversationId: Id,
	snapshot: PreparationSnapshot,
	canonical: Canonical,
	prepared: PreparedDraft,
	previousTools: readonly ToolDeclaration[],
	now: number,
): Promise<ManagedEntryInput | undefined> {
	// A usable baseline must follow the newest head (§12.4).
	const needBaseline = snapshot.newestHead !== null && (snapshot.newestBaseline === null || snapshot.newestHead > snapshot.newestBaseline);

	// Diff.
	const changed: SectionRecord[] = [];
	for (const [key, state] of prepared.desired) {
		const existing = canonical.get(key);
		if (existing === undefined || existing.rendered !== state.rendered || JSON.stringify(existing.value) !== JSON.stringify(state.value)) {
			changed.push({ key, action: "set", value: state.value, rendered: state.rendered });
		}
	}
	for (const key of prepared.removed) changed.push({ key, action: "remove" });

	const previousNames = new Set(previousTools.map((t) => t.name));
	const desiredNames = new Set(prepared.tools.map((t) => t.name));
	const toolsAdded = prepared.tools.filter((t) => !previousNames.has(t.name) || previousTools.find((p) => p.name === t.name) !== t);
	const toolsRemoved = previousTools.filter((t) => !desiredNames.has(t.name));

	if (!needBaseline && changed.length === 0 && toolsAdded.length === 0 && toolsRemoved.length === 0) return undefined;

	if (needBaseline) {
		// Full ordered state, plus omission edits for every retained superseded managed entry between head and tail.
		const sections: SectionRecord[] = [...prepared.desired].map(([key, s]) => ({ key, action: "set", value: s.value, rendered: s.rendered }));
		const content = sections.map((s) => (s.action === "set" ? `## ${s.key}\n${s.rendered}` : "")).filter(Boolean).join("\n\n");
		const { entries } = await reads.readContext(conversationId);
		const edits: ContextEdit[] = entries
			.filter((e) => systemEntry.is(e) && e.id > (snapshot.newestHead ?? 0))
			.map((e) => ({ target: e.id, action: "omit" as const }));
		const message: SystemMessage = { role: "system", content, toolsAdded: prepared.tools.map(toolOf), timestamp: now };
		return { data: { baseline: true, sections }, model: [message as Stored<SystemMessage>], ...(edits.length ? { edits } : {}) };
	}

	// Delta.
	const content = changed
		.map((s) => (s.action === "set" ? `The ${s.key} section now reads:\n${s.rendered}` : `The ${s.key} section no longer applies.`))
		.join("\n\n");
	const renderChanged = changed.some((s) => s.action === "remove" || canonical.get(s.key)?.rendered !== (s as Extract<SectionRecord, { action: "set" }>).rendered);
	if (!renderChanged && toolsAdded.length === 0 && toolsRemoved.length === 0) {
		return { data: { sections: changed }, model: [] }; // metadata-only delta
	}
	const message: SystemMessage = {
		role: "system",
		content,
		...(toolsAdded.length ? { toolsAdded: toolsAdded.map(toolOf) } : {}),
		...(toolsRemoved.length ? { toolsRemoved: toolsRemoved.map(toolOf) } : {}),
		timestamp: now,
	};
	return { data: { sections: changed }, model: [message as Stored<SystemMessage>] };
}

/** Tools effective in a projected request: fold toolsAdded/toolsRemoved across its SystemMessages (§12). */
export function effectiveTools(messages: readonly { role: string }[]): readonly Tool[] {
	const tools = new Map<string, Tool>();
	for (const m of messages) {
		if (m.role !== "system") continue;
		const s = m as SystemMessage;
		for (const t of s.toolsRemoved ?? []) tools.delete(t.name);
		for (const t of s.toolsAdded ?? []) tools.set(t.name, t);
	}
	return [...tools.values()];
}

export { sameSnapshot };

// NOTE: §8.1 section seed (private metadata on conversation.create, applied while the
// conversation has no local managed entry) is not modelled here. It belongs to the
// creation planner, not to preparation; preparation would read it as part of the
// canonical seed when `newestManaged === null`.
