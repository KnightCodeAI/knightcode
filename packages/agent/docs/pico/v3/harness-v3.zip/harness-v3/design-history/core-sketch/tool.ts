import type { Context } from "@knightcode/chord";
import type { ImageContent, TextContent, ToolCall, ToolResultMessage } from "@knightcode/ai";
import { Value } from "@sinclair/typebox/value";
import { type CoreRuntimeExtras, defineCoreStateTask, type ToolDeclaration } from "./assumed.ts";
import { toolConfig } from "./config.ts";
import type { Id, JsonObject, JsonValue, Stored } from "./core.ts";
import type { ToolControl, ToolDiagnostic, ToolResultData, ToolUsage } from "./entries.ts";
import { toolHooks, toolResultEntry } from "./witnesses.ts";

// ---------------------------------------------------------------------------
// Types (§10.2, §11.1 normative part, delta §5.6)
// ---------------------------------------------------------------------------

export interface ToolInput extends JsonObject {
	readonly assistant: Id;
	readonly call: Stored<ToolCall>;
	readonly offered: readonly string[]; // delta §5.6: input, not another task's checkpoint
}

export interface ToolResult<D extends JsonValue = JsonValue> {
	content: readonly (TextContent | ImageContent)[];
	details?: D;
	isError?: boolean;
	usage?: ToolUsage;
	diagnostics?: readonly ToolDiagnostic[];
	control?: ToolControl;
}

export type ToolCarry = Record<never, never>; // nothing carried; `started` holds the whole evidence

export type ToolCheckpoint = {
	readonly phase: "started";
	readonly replay: "safe" | "unsafe";
	readonly call: Stored<ToolCall>; // final, identity-preserving, schema-validated
};

export interface ToolTaskResult extends JsonObject {
	readonly entry: Id;
	readonly control?: ToolControl;
}
export type ToolFailure = never;
export interface ToolAborted extends JsonObject {
	readonly entry: Id;
}
export type ToolOutputState = { progress?: string; log: string[]; details?: JsonValue };

// ---------------------------------------------------------------------------
// Synthetic results. Every path that does not invoke the tool ends here.
// ---------------------------------------------------------------------------

const syntheticError = (text: string, code: string): ToolResult => ({
	content: [{ type: "text", text }],
	isError: true,
	diagnostics: [{ severity: "error", message: text, code }],
});

function validateArguments(declaration: ToolDeclaration, call: ToolCall): string | undefined {
	const errors = [...Value.Errors(declaration.parameters, call.arguments)];
	if (errors.length === 0) return undefined;
	return errors.map((e) => `${e.path || "/"}: ${e.message}`).join("; ");
}

function sameIdentity(a: ToolCall, b: ToolCall): boolean {
	const { arguments: _a, ...ia } = a;
	const { arguments: _b, ...ib } = b;
	return JSON.stringify(ia) === JSON.stringify(ib);
}

// ---------------------------------------------------------------------------
// Output bounding (§11.1: knightcode.tool enforces `output` bounds and owns the
// truncation diagnostics).
// ---------------------------------------------------------------------------

const DEFAULT_BOUNDS = { maxBytes: 64 * 1024, maxLines: 200, retain: "head" as const };

function bound(result: ToolResult, declared: ToolDeclaration["output"] | undefined): { result: ToolResult; truncated?: { bytes: number; lines: number } } {
	const bounds = { ...DEFAULT_BOUNDS, ...declared };
	let droppedBytes = 0;
	let droppedLines = 0;
	const content = result.content.map((block) => {
		if (block.type !== "text") return block;
		let text = block.text;
		const lines = text.split("\n");
		if (lines.length > bounds.maxLines) {
			droppedLines += lines.length - bounds.maxLines;
			text = (bounds.retain === "head" ? lines.slice(0, bounds.maxLines) : lines.slice(-bounds.maxLines)).join("\n");
		}
		const bytes = Buffer.byteLength(text, "utf8");
		if (bytes > bounds.maxBytes) {
			droppedBytes += bytes - bounds.maxBytes;
			text = bounds.retain === "head" ? Buffer.from(text).subarray(0, bounds.maxBytes).toString("utf8") : Buffer.from(text).subarray(-bounds.maxBytes).toString("utf8");
		}
		return { ...block, text };
	});
	if (droppedBytes === 0 && droppedLines === 0) return { result };
	const note: ToolDiagnostic = { severity: "warn", code: "truncated", message: `output truncated: ${droppedLines} lines, ${droppedBytes} bytes dropped (${bounds.retain} retained)` };
	return { result: { ...result, content, diagnostics: [...(result.diagnostics ?? []), note] }, truncated: { bytes: droppedBytes, lines: droppedLines } };
}

// ---------------------------------------------------------------------------
// The kind
// ---------------------------------------------------------------------------

export const toolKind = defineCoreStateTask<ToolInput, ToolCarry, ToolCheckpoint, ToolTaskResult, ToolFailure, ToolAborted, ToolOutputState>()({
	kind: "knightcode.tool",
	config: toolConfig,
	hooks: toolHooks,
	output: { kind: { kind: "knightcode.tool" }, initial: () => ({ log: [] }) },

	// -------------------------------------------------------------------------
	// initial: offered-set check, lookup, validate, beforeTool, validate again.
	// No checkpoint yet, so a crash here reruns everything — correct, because
	// nothing external has happened.
	// -------------------------------------------------------------------------
	initial: {
		role: "start",
		async run(task, rt, actions, ctx) {
			const x = rt as unknown as CoreRuntimeExtras & typeof rt;
			const original = task.input.call as unknown as ToolCall;

			// Offered-set check against input. No registry consulted.
			if (!task.input.offered.includes(original.name)) {
				return actions.terminal(closeWith(task, syntheticError(`tool ${original.name} was not offered`, "not_offered"), undefined));
			}

			const declaration = x.registries.tools.get(original.name);
			if (declaration === undefined) {
				return actions.terminal(closeWith(task, syntheticError(`tool ${original.name} is not registered`, "missing_tool"), undefined));
			}

			const invalid = validateArguments(declaration, original);
			if (invalid !== undefined) {
				return actions.terminal(closeWith(task, syntheticError(`invalid arguments: ${invalid}`, "invalid_arguments"), declaration));
			}

			// beforeTool: chain, stops on block; a throw under onThrow:abort sets block.
			const hooked = await rt.hooks.run(toolHooks.beforeTool, { call: original }, ctx);
			const folded = hooked.threw !== undefined ? { call: original, block: { reason: String(hooked.threw) } } : hooked.output;
			if (folded.block !== undefined) {
				return actions.terminal(closeWith(task, syntheticError(`blocked: ${folded.block.reason}`, "blocked"), declaration));
			}
			const final = folded.call ?? original;
			if (!sameIdentity(original, final)) {
				return actions.terminal(closeWith(task, syntheticError("blocked: call identity changed", "blocked"), declaration));
			}
			const invalidFinal = validateArguments(declaration, final);
			if (invalidFinal !== undefined) {
				return actions.terminal(closeWith(task, syntheticError(`invalid arguments after hook: ${invalidFinal}`, "invalid_arguments"), declaration));
			}

			// Only the invocation branch commits `started`.
			return actions.transition("started", {}, () => ({ replay: declaration.replay ?? "unsafe", call: final as Stored<ToolCall> }));
		},
	},

	phases: {
		// -----------------------------------------------------------------------
		// started: the effect may be in flight. Invoke outside the line through
		// the executor; afterTool; closure appends exactly one knightcode.tool_result.
		// -----------------------------------------------------------------------
		started: {
			role: "inflight",
			async run(task, rt, actions, ctx) {
				const x = rt as unknown as CoreRuntimeExtras & typeof rt;
				const call = task.checkpoint.call as unknown as ToolCall;
				const declaration = x.registries.tools.get(call.name);
				return invoke(task, rt, actions, call, declaration, ctx);
			},

			// A started checkpoint never reruns beforeTool: the stored final call is the evidence.
			async recover(task, rt, actions, ctx) {
				const x = rt as unknown as CoreRuntimeExtras & typeof rt;
				const call = task.checkpoint.call as unknown as ToolCall;
				const declaration = x.registries.tools.get(call.name);

				if (declaration === undefined) {
					return actions.terminal(closeWith(task, syntheticError(`tool ${call.name} unavailable after restart`, "unavailable"), undefined));
				}
				const currentSafe = (declaration.replay ?? "unsafe") === "safe";
				if (task.checkpoint.replay !== "safe" || !currentSafe) {
					return actions.terminal(closeWith(task, syntheticError(`tool ${call.name} was interrupted and cannot be replayed`, "interrupted"), declaration));
				}
				if (validateArguments(declaration, call) !== undefined) {
					return actions.terminal(closeWith(task, syntheticError(`tool ${call.name} was interrupted; persisted arguments no longer validate`, "interrupted"), declaration));
				}
				return invoke(task, rt, actions, call, declaration, ctx);
			},
		},
	},

	// -------------------------------------------------------------------------
	// abort: children/subagents are gated (§11.1), so in WP10 there is nothing
	// to mark. Closure appends an aborted result.
	// -------------------------------------------------------------------------
	async abort(task, _rt, _ctx) {
		return async (tx, current) => {
			const call = (task.checkpoint?.call ?? task.input.call) as unknown as ToolCall;
			const entry = tx.entry(toolResultEntry, current.conversationId, {
				model: [toolResultMessage(call, syntheticError("tool aborted", "aborted"), _rt.now()) as Stored<ToolResultMessage>],
				data: { diagnostics: [{ severity: "error", message: "aborted", code: "aborted" }] },
			});
			return { entry };
		};
	},
});

// ---------------------------------------------------------------------------
// Invocation and closure
// ---------------------------------------------------------------------------

type Actions = Parameters<(typeof toolKind)["phases"]["started"]["run"]>[2];
type RunTask = Parameters<(typeof toolKind)["phases"]["started"]["run"]>[0];
type Rt = Parameters<(typeof toolKind)["phases"]["started"]["run"]>[1];
type AnyTask = { readonly input: ToolInput; readonly conversationId: Id };

async function invoke(task: RunTask, rt: Rt, actions: Actions, call: ToolCall, declaration: ToolDeclaration | undefined, ctx: Context) {
	const x = rt as unknown as CoreRuntimeExtras & typeof rt;
	let result: ToolResult;
	try {
		result = await x.toolExecutor.execute(call, ctx);
	} catch (error) {
		if (ctx.abortSignal?.aborted) throw error;
		result = syntheticError(`tool threw: ${String(error)}`, "threw");
	}
	const hooked = await rt.hooks.run(toolHooks.afterTool, { call, result }, ctx);
	return actions.terminal(closeWith(task, hooked.output.result ?? result, declaration));
}

function toolResultMessage(call: ToolCall, result: ToolResult, now: number): ToolResultMessage {
	return {
		role: "toolResult",
		toolCallId: call.id,
		toolName: call.name,
		content: result.content,
		isError: result.isError ?? false,
		timestamp: now,
	} as ToolResultMessage;
}

/** Build the terminal closure: bound, store the exact model message and the rest as data. */
function closeWith(task: AnyTask, raw: ToolResult, declaration: ToolDeclaration | undefined) {
	return (tx: Parameters<Parameters<Actions["terminal"]>[0]>[0], current: { conversationId: Id }) => {
		const { result, truncated } = bound(raw, declaration?.output);
		const call = task.input.call as unknown as ToolCall;
		const message = toolResultMessage(call, result, Date.now());
		const data: ToolResultData = {
			...(result.details === undefined ? {} : { details: result.details }),
			...(result.usage === undefined ? {} : { usage: result.usage }),
			...(result.diagnostics === undefined ? {} : { diagnostics: result.diagnostics }),
			...(result.control === undefined ? {} : { control: result.control }),
			...(truncated === undefined ? {} : { truncated }),
		};
		const entry = tx.entry(toolResultEntry, current.conversationId, { model: [message as Stored<ToolResultMessage>], data });
		return { status: "completed" as const, result: { entry, ...(result.control === undefined ? {} : { control: result.control }) } };
	};
}

// NOTES
//
// - Diagnostics are "rendered after the output" in the model message per
//   §11.1. `toolResultMessage` does not append them to content here; that
//   rendering rule (format, separator) is unspecified. Left as data only.
//
// - `children` phase and everything under the §11.1 gate is absent by design.
//   `abort` therefore has no children to mark.
//
// - `closeWith` uses `Date.now()` for the message timestamp because the
//   terminal closure signature has no `rt`. Either the closure gets `now` or
//   the timestamp is computed outside and captured. Minor.
