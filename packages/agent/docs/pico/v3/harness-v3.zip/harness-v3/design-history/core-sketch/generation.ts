import type { Context } from "@knightcode/chord";
import type { AssistantMessage, AssistantMessageFrame, DeferredHandle, Message, RetryPolicy } from "@knightcode/ai";
import { AssistantMessageFrameEncoder } from "@knightcode/ai";
import type { ThinkingLevel } from "../../types.ts";
import {
	type CoreRuntimeExtras,
	defineCoreStateTask,
	estimate,
	RETRY,
	type ToolDeclaration,
} from "./assumed.ts";
import { collapseConfig, generationConfig, type ModelRef } from "./config.ts";
import type { Id, JsonObject, Stored } from "./core.ts";
import { effectiveTools, planManagedEntry, runPreparation, sameSnapshot, systemEntry, takeSnapshot } from "./prepare.ts";
import { decideRetry, errorDetail } from "./retry.ts";
import { collapseKind } from "./collapse.ts";
import { postToolsKind } from "./post-tools.ts";
import { toolKind } from "./tool.ts";
import { assistantEntry, generationHooks, noticeEntry, usageEntry, userEntry } from "./witnesses.ts";

// ---------------------------------------------------------------------------
// Types (§10.1)
// ---------------------------------------------------------------------------

export interface GenerationInput extends JsonObject {
	readonly inputs: readonly Id[];
}

/** Captured once at `prepared`; carried unchanged except `attempt` and `tools`. */
export interface Prep extends JsonObject {
	readonly cutoff: Id;
	readonly system: Id | null;
	readonly model: ModelRef;
	readonly thinkingLevel: ThinkingLevel;
	readonly tools: readonly string[];
	readonly retry: Stored<RetryPolicy>;
	readonly attempt: number;
}

export type GenerationCheckpoint =
	| { readonly phase: "prepared" }
	| { readonly phase: "requesting"; readonly requestKey: string }
	| { readonly phase: "retrying"; readonly untilMs: number; readonly lastError: string }
	| { readonly phase: "deferred"; readonly handle: Stored<DeferredHandle> };

export interface GenerationResult extends JsonObject {
	readonly assistant: Id;
	readonly tools: readonly Id[];
	readonly postTools?: Id;
	readonly successor?: Id;
}
export interface GenerationFailure extends JsonObject {
	readonly reason: "provider" | "overflow" | "retries_exhausted" | "no_model";
	readonly detail: string;
	readonly assistant?: Id;
}
export interface GenerationAborted extends JsonObject {
	readonly assistant?: Id;
}
export type GenerationOutput = { message?: Stored<AssistantMessage> };

const fail = (reason: GenerationFailure["reason"], detail: string, assistant?: Id) =>
	({ status: "failed", failure: { reason, detail, ...(assistant === undefined ? {} : { assistant }) } }) as const;

// ---------------------------------------------------------------------------
// Frame reducer: applies one encoded frame to the tracked output message.
// Same switch and invariants as @knightcode/ai's reduceAssistantMessageFrames, which is
// the test oracle. Never buffers, never re-reduces, never keeps a second
// message.
// ---------------------------------------------------------------------------

type BlockState = { kind: "text" | "thinking"; ended: boolean } | { kind: "toolCall"; ended: boolean; json: string };

class FrameReducer {
	private readonly states = new Map<number, BlockState>();

	apply(o: GenerationOutput, frame: AssistantMessageFrame): void {
		if (frame.type === "start") {
			o.message = frame.partial as Stored<AssistantMessage>; // encoder's clone, never the provider's partial
			return;
		}
		const message = o.message;
		if (message === undefined) throw new Error(`${frame.type} frame before start`);
		const content = message.content as unknown as Record<string, unknown>[];

		const active = (index: number, kind: BlockState["kind"]) => {
			const block = content[index];
			const state = this.states.get(index);
			if (block === undefined || state === undefined || state.kind !== kind || state.ended) {
				throw new Error(`invalid ${frame.type} frame for block ${index}`);
			}
			return { block, state };
		};

		switch (frame.type) {
			case "text_start":
				content[frame.contentIndex] = { ...frame.content };
				this.states.set(frame.contentIndex, { kind: "text", ended: false });
				break;
			case "text_delta":
				(active(frame.contentIndex, "text").block.text as string) += frame.delta;
				break;
			case "text_end": {
				const { block, state } = active(frame.contentIndex, "text");
				block.text = frame.content;
				delete block.textSignature;
				if (frame.textSignature !== undefined) block.textSignature = frame.textSignature;
				state.ended = true;
				break;
			}
			case "thinking_start":
				content[frame.contentIndex] = { ...frame.content };
				this.states.set(frame.contentIndex, { kind: "thinking", ended: false });
				break;
			case "thinking_delta":
				(active(frame.contentIndex, "thinking").block.thinking as string) += frame.delta;
				break;
			case "thinking_end": {
				const { block, state } = active(frame.contentIndex, "thinking");
				block.thinking = frame.content;
				delete block.thinkingSignature;
				delete block.redacted;
				if (frame.thinkingSignature !== undefined) block.thinkingSignature = frame.thinkingSignature;
				if (frame.redacted !== undefined) block.redacted = frame.redacted;
				state.ended = true;
				break;
			}
			case "toolcall_start":
				content[frame.contentIndex] = { ...frame.toolCall };
				this.states.set(frame.contentIndex, { kind: "toolCall", ended: false, json: "" });
				break;
			case "toolcall_checkpoint": {
				const { block, state } = active(frame.contentIndex, "toolCall");
				(state as Extract<BlockState, { kind: "toolCall" }>).json = frame.json;
				block.arguments = safeParse(frame.json);
				break;
			}
			case "toolcall_delta": {
				const { state } = active(frame.contentIndex, "toolCall");
				(state as Extract<BlockState, { kind: "toolCall" }>).json += frame.delta;
				break;
			}
			case "toolcall_end": {
				const { block, state } = active(frame.contentIndex, "toolCall");
				block.id = frame.id;
				block.name = frame.name;
				block.arguments = frame.arguments;
				if (frame.thoughtSignature !== undefined) block.thoughtSignature = frame.thoughtSignature;
				if (frame.namespace !== undefined) block.namespace = frame.namespace;
				state.ended = true;
				break;
			}
		}
	}
}

function safeParse(json: string): unknown {
	try {
		return JSON.parse(json);
	} catch {
		return {};
	}
}

// ---------------------------------------------------------------------------
// Request derivation (step 2): immutable snapshot from the cutoff, hooks on a
// private copy, overflow check, effective tools.
// ---------------------------------------------------------------------------

interface DerivedRequest {
	readonly messages: readonly Message[];
	readonly tools: readonly string[];
	readonly overflow: boolean;
}

async function deriveRequest(
	rt: CoreRuntimeExtras & { hooks: { run: Function } },
	conversationId: Id,
	prep: Prep,
	model: { contextWindow: number; maxTokens: number },
	ctx: Context,
): Promise<DerivedRequest> {
	const { messages } = await rt.readContext(conversationId, prep.cutoff, ctx);
	const hooked = await (rt.hooks.run as (p: unknown, i: unknown, c: Context) => Promise<{ output: { request: { messages: readonly Message[] } } }>)(
		generationHooks.beforeRequest,
		{ request: { messages: [...messages] }, cutoff: prep.cutoff },
		ctx,
	);
	const final = hooked.output.request.messages;
	return {
		messages: final,
		tools: effectiveTools(final).map((t) => t.name),
		overflow: estimate(final) > model.contextWindow - model.maxTokens,
	};
}

// ---------------------------------------------------------------------------
// `through` selection for automatic collapse (§10.1, "Choosing through").
// ---------------------------------------------------------------------------

function chooseThrough(entries: readonly { id: Id; model?: readonly Message[]; head?: Id }[], messagesByEntry: ReadonlyMap<Id, readonly Message[]>, keepRecent: number): Id | undefined {
	// Group into complete exchanges: an assistant entry plus its tool results; user/notice alone.
	const exchanges: { last: Id; tokens: number }[] = [];
	let current: { last: Id; tokens: number } | undefined;
	for (const entry of entries) {
		const msgs = messagesByEntry.get(entry.id) ?? [];
		const role = msgs[0]?.role;
		const tokens = estimate(msgs);
		if (role === "assistant") {
			current = { last: entry.id, tokens };
			exchanges.push(current);
		} else if (role === "toolResult" && current !== undefined) {
			current.last = entry.id;
			current.tokens += tokens;
		} else {
			current = undefined;
			exchanges.push({ last: entry.id, tokens });
		}
	}
	let retained = 0;
	let i = exchanges.length - 1;
	while (i >= 0 && retained + exchanges[i]!.tokens <= keepRecent) {
		retained += exchanges[i]!.tokens;
		i--;
	}
	if (i < 0) return undefined; // everything fits
	if (i === exchanges.length - 1) return exchanges[i - 1]?.last; // newest exchange alone exceeds keepRecent: keep just it
	return exchanges[i]!.last;
}

// ---------------------------------------------------------------------------
// The kind
// ---------------------------------------------------------------------------

export const generationKind = defineCoreStateTask<
	GenerationInput,
	Prep,
	GenerationCheckpoint,
	GenerationResult,
	GenerationFailure,
	GenerationAborted,
	GenerationOutput
>()({
	kind: "knightcode.generation",
	config: generationConfig,
	hooks: generationHooks,
	output: { kind: { kind: "knightcode.generation" }, initial: () => ({}) },

	// -------------------------------------------------------------------------
	// initial → prepared (step 1, §12.5). Loops until a snapshot commits.
	// -------------------------------------------------------------------------
	initial: {
		role: "start",
		async run(task, rt, actions, ctx) {
			const x = rt as unknown as CoreRuntimeExtras & typeof rt;
			const conversation = await rt.conversation(task.conversationId, ctx);
			if (conversation === undefined) throw new Error("own conversation missing");

			// On-line snapshot S, read through the public conversation handle (initial has no commit).
			const reads = {
				...x,
				readContext: (c: Id, at?: Id) => x.readContext(c, at, ctx),
				newestHead: (c: Id, at?: Id) => x.newestHead(c, at, ctx),
				scanEntries: (q: Parameters<typeof x.scanEntries>[0]) => x.scanEntries(q, ctx),
				newestEntry: (c: Id) => x.newestEntry(c, ctx),
				value: (def: (typeof generationConfig)[keyof typeof generationConfig]) => ({ get: () => conversation.value(def).get(ctx) }),
			};
			const { snapshot, canonical } = await takeSnapshot(reads, x.registries, task.conversationId);

			if (snapshot.settings.model === undefined) return actions.terminal(() => fail("no_model", "no model configured"));

			// Off-line: handlers, render, tools.
			const prepared = await runPreparation(rt.hooks, x.registries, canonical, snapshot.settings, () => {}, ctx);
			const previousTools = effectiveTools((await reads.readContext(task.conversationId)).messages);
			const previousDecls = previousTools.map((t) => x.registries.tools.get(t.name)).filter((t): t is ToolDeclaration => t !== undefined);

			const retry = (await conversation.value(generationConfig.retry).get(ctx)) as Stored<RetryPolicy>;

			// On-line: re-take S', compare, append managed entry, checkpoint prepared.
			return actions.transition(
				"prepared",
				{ cutoff: 0, system: null, model: snapshot.settings.model, thinkingLevel: snapshot.settings.thinkingLevel as ThinkingLevel, tools: [], retry, attempt: 0 },
				async (tx, current) => {
					const again = await takeSnapshot(
						{ ...tx, value: (def) => ({ get: () => tx.value(def).get() }) },
						x.registries,
						current.conversationId,
					);
					if (!sameSnapshot(again.snapshot, snapshot)) return RETRY;

					const plan = await planManagedEntry(tx, current.conversationId, snapshot, canonical, prepared, previousDecls, rt.now());
					const system = plan === undefined ? null : tx.entry(systemEntry, current.conversationId, plan);
					const cutoff = system ?? (await tx.newestEntry(current.conversationId))?.id;
					if (cutoff === undefined) throw new Error("conversation has no entries"); // an input was placed: impossible

					// The carry is rewritten here with the real cutoff/system; attempt stays 0 until `requesting`.
					(current as { carry: Prep }).carry = { ...current.carry, cutoff, system };
					return {};
				},
			);
		},
	},

	phases: {
		// -----------------------------------------------------------------------
		// prepared → requesting (step 2). Hooks rerun on recovery; step 1 never does.
		// -----------------------------------------------------------------------
		prepared: {
			role: "start",
			async run(task, rt, actions, ctx) {
				const x = rt as unknown as CoreRuntimeExtras & typeof rt;
				const model = x.models.resolve(task.carry.model);
				if (model === undefined) return actions.terminal(() => fail("no_model", `model ${task.carry.model.provider}/${task.carry.model.modelId} unavailable`));

				const derived = await deriveRequest(x, task.conversationId, task.carry, model, ctx);

				if (derived.overflow) return overflow(task, rt, actions, ctx);

				const requestKey = crypto.randomUUID();
				return actions.transition("requesting", { ...task.carry, tools: derived.tools, attempt: task.carry.attempt + 1 }, () => ({ requestKey }));
			},
		},

		// -----------------------------------------------------------------------
		// requesting: the provider call is in flight.
		// -----------------------------------------------------------------------
		requesting: {
			role: "inflight",
			async run(task, rt, actions, ctx) {
				const x = rt as unknown as CoreRuntimeExtras & typeof rt;
				const model = x.models.resolve(task.carry.model);
				if (model === undefined) return actions.terminal(() => fail("no_model", "model disappeared"));
				const derived = await deriveRequest(x, task.conversationId, task.carry, model, ctx);

				const encoder = new AssistantMessageFrameEncoder();
				const reducer = new FrameReducer();
				let pending: AssistantMessageFrame[] = [];
				let lastFlush = 0;
				const INTERVAL_MS = 50;
				let terminal: AssistantMessage | undefined;
				let deferred: DeferredHandle | undefined;

				const flush = () =>
					rt.commit((tx) => {
						const o = tx.output();
						for (const f of pending) reducer.apply(o, f);
						pending = [];
					}, ctx);

				try {
					for await (const event of x.models.stream(model, { messages: derived.messages, thinkingLevel: task.carry.thinkingLevel, signal: ctx.abortSignal }, ctx)) {
						if (event.type === "done" || event.type === "error") {
							encoder.encode(event);
							terminal = event.message;
							break;
						}
						if (event.type === "deferred") {
							deferred = event.handle;
							break;
						}
						const frame = encoder.encode(event);
						if (frame === undefined) continue;
						pending.push(frame);
						const now = rt.now();
						if (now - lastFlush < INTERVAL_MS) continue;
						lastFlush = now;
						await flush();
					}
				} catch (error) {
					if (ctx.abortSignal?.aborted) throw error; // Pico mark: unwind, fresh abort follows
					terminal = { role: "assistant", content: [], stopReason: "error", errorMessage: String(error), timestamp: rt.now() } as AssistantMessage;
				}
				if (pending.length) await flush();

				if (deferred !== undefined) {
					const handle = deferred;
					return actions.transition("deferred", task.carry, () => ({ handle: handle as Stored<DeferredHandle> }));
				}
				if (terminal === undefined) throw new Error("stream ended without a terminal message");
				return classify(task, rt, actions, terminal, ctx);
			},

			// The effect may have happened; no result lookup. Failed attempt with usage absent.
			async recover(task, rt, actions, ctx) {
				const decision = decideRetry(task.carry.retry, task.carry.attempt, null, rt.now());
				if (decision.kind === "fail") {
					return actions.terminal((tx, current) => {
						tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "failed", detail: "interrupted" });
						return fail(decision.reason, "interrupted");
					});
				}
				return actions.transition("retrying", task.carry, (tx, current) => {
					tx.entry(usageEntry, current.conversationId, { data: { attempt: task.carry.attempt, error: "interrupted" } });
					return { untilMs: decision.untilMs, lastError: "interrupted" };
				});
			},
		},

		// -----------------------------------------------------------------------
		// retrying: durable backoff, then back to step 2 with attempt + 1.
		// -----------------------------------------------------------------------
		retrying: {
			role: "start",
			async run(task, rt, actions, ctx) {
				await rt.sleep(task.checkpoint.untilMs, ctx);
				return actions.transition("prepared", task.carry, (tx) => {
					tx.output().message = undefined;
					tx.rebaseOutput(); // reset must be a base, or retries accumulate ops that fold to nothing
					return {};
				});
			},
		},

		// -----------------------------------------------------------------------
		// deferred: provider-side async. Poll; not the retry backoff.
		// -----------------------------------------------------------------------
		deferred: {
			role: "inflight",
			async run(task, rt, actions, ctx) {
				const x = rt as unknown as CoreRuntimeExtras & typeof rt;
				const model = x.models.resolve(task.carry.model);
				if (model === undefined) return actions.terminal(() => fail("no_model", "model disappeared"));
				const handle = task.checkpoint.handle as unknown as DeferredHandle;
				await rt.sleep(rt.now() + (handle.pollAfterMs ?? 5000), ctx);
				const result = await x.models.fetchDeferred(model, handle, ctx);
				if ("deferred" in result) {
					const next = result.deferred;
					return actions.transition("deferred", task.carry, () => ({ handle: next as Stored<DeferredHandle> }));
				}
				await rt.commit((tx) => {
					tx.output().message = result as Stored<AssistantMessage>;
					tx.rebaseOutput();
				}, ctx);
				return classify(task, rt, actions, result, ctx);
			},
			async recover(task, rt, actions, ctx) {
				// The handle is durable; polling simply resumes.
				return this.run(task, rt, actions, ctx);
			},
		},
	},

	// -------------------------------------------------------------------------
	// abort: cancel a deferred request best-effort; store the partial as an
	// aborted assistant entry if any content exists; resolve inputs aborted.
	// -------------------------------------------------------------------------
	async abort(task, rt, ctx) {
		const x = rt as unknown as CoreRuntimeExtras & typeof rt;
		if (task.checkpoint?.phase === "deferred") {
			const model = x.models.resolve(task.carry.model);
			if (model !== undefined) {
				try {
					await x.models.cancelDeferred(model, task.checkpoint.handle as unknown as DeferredHandle, ctx);
				} catch {}
			}
		}
		return async (tx, current) => {
			const partial = tx.output.message as Stored<AssistantMessage> | undefined;
			let assistant: Id | undefined;
			if (partial !== undefined && partial.content.length > 0) {
				assistant = tx.entry(assistantEntry, current.conversationId, {
					model: [{ ...partial, stopReason: "aborted" } as Stored<AssistantMessage>],
					data: { attempt: task.carry?.attempt ?? 0 },
				});
			}
			tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "aborted" });
			return assistant === undefined ? {} : { assistant };
		};
	},
});

// ---------------------------------------------------------------------------
// Step 3/3b/4/5: classify a terminal provider message.
// ---------------------------------------------------------------------------

type Actions = Parameters<(typeof generationKind)["phases"]["requesting"]["run"]>[2];
type RunTask = Parameters<(typeof generationKind)["phases"]["requesting"]["run"]>[0];
type Rt = Parameters<(typeof generationKind)["phases"]["requesting"]["run"]>[1];

async function classify(task: RunTask, rt: Rt, actions: Actions, message: AssistantMessage, ctx: Context) {
	// afterResponse observes every terminal message before any classification.
	await rt.hooks.run(generationHooks.afterResponse, { message, usage: message.usage, attempt: task.carry.attempt }, ctx);

	// 3: provider error → retry policy.
	if (message.stopReason === "error") {
		const decision = decideRetry(task.carry.retry, task.carry.attempt, message, rt.now());
		if (decision.kind === "retry") {
			return actions.transition("retrying", task.carry, (tx, current) => {
				tx.entry(usageEntry, current.conversationId, {
					data: { attempt: task.carry.attempt, ...(message.usage ? { usage: message.usage as Stored<typeof message.usage> } : {}), error: message.errorMessage ?? "provider error" },
				});
				return { untilMs: decision.untilMs, lastError: message.errorMessage ?? "provider error" };
			});
		}
		return terminalNonRetryable(task, actions, message, decision.reason);
	}

	// 3b: provider-side abort without a Pico mark.
	if (message.stopReason === "aborted") return terminalNonRetryable(task, actions, message, "provider");

	// 5: tool calls.
	const calls = message.content.filter((c) => c.type === "toolCall");
	if (calls.length > 0) {
		return actions.terminal(async (tx, current) => {
			const assistant = tx.entry(assistantEntry, current.conversationId, {
				model: [message as Stored<AssistantMessage>],
				data: { attempt: task.carry.attempt },
			});
			const tools = calls.map((call) =>
				tx.task(toolKind, { input: { assistant, call: call as Stored<typeof call>, offered: task.carry.tools } }),
			);
			const postTools = tx.task(postToolsKind, { after: tools, input: { inputs: task.input.inputs, assistant, tools } });
			// Threshold collapse rides along (foreground).
			await maybeThresholdCollapse(tx, current.conversationId, message);
			return { status: "completed", result: { assistant, tools, postTools } };
		});
	}

	// 4: final answer. onYield off the line only if nothing is queued right now.
	const yieldDecision = await rt.hooks.run(generationHooks.onYield, { answer: message }, ctx);
	const continueText = yieldDecision.output?.continue;

	return actions.terminal(async (tx, current) => {
		const assistant = tx.entry(assistantEntry, current.conversationId, {
			model: [message as Stored<AssistantMessage>],
			data: { attempt: task.carry.attempt },
		});
		await maybeThresholdCollapse(tx, current.conversationId, message);

		const boundary = await tx.finalAnswerBoundary(current.conversationId);

		// Yield continuation: valid only if no trigger arrived meanwhile and no self-head was placed.
		if (continueText !== undefined && boundary.triggers.length === 0) {
			const head = await tx.newestHead(current.conversationId);
			const selfHeadPlaced = head !== undefined && head.id > assistant;
			if (!selfHeadPlaced) {
				tx.entry(userEntry, current.conversationId, {
					model: [{ role: "user", content: continueText, timestamp: rt.now() }],
					data: { continuation: true, from: assistant },
				});
				const successor = tx.task(generationKind, { input: { inputs: task.input.inputs } });
				return { status: "completed", result: { assistant, tools: [], successor } };
			}
		}

		tx.resolveInputs(task.input.inputs, { status: "done", answer: assistant });
		if (boundary.triggers.length > 0) {
			const successor = tx.task(generationKind, { input: { inputs: boundary.triggers } });
			return { status: "completed", result: { assistant, tools: [], successor } };
		}
		return { status: "completed", result: { assistant, tools: [] } };
	});
}

function terminalNonRetryable(task: RunTask, actions: Actions, message: AssistantMessage, reason: "provider" | "retries_exhausted") {
	return actions.terminal((tx, current) => {
		// Display-only assistant entry; never in context, never creates tools.
		const assistant = tx.entry(assistantEntry, current.conversationId, {
			model: [message as Stored<AssistantMessage>],
			data: { attempt: task.carry.attempt },
		});
		tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "failed", detail: message.errorMessage });
		return fail(reason, message.errorMessage ?? "provider error", assistant);
	});
}

async function maybeThresholdCollapse(
	tx: Parameters<Parameters<Actions["terminal"]>[0]>[0],
	conversationId: Id,
	message: AssistantMessage,
): Promise<void> {
	const threshold = await tx.value(collapseConfig.threshold).get();
	if (threshold <= 0) return;
	const { entries, messages } = await tx.readContext(conversationId);
	const used = Math.max((message.usage?.input ?? 0) + (message.usage?.output ?? 0), estimate(messages));
	if (used <= threshold) return;
	const keepRecent = await tx.value(collapseConfig.keepRecent).get();
	const byEntry = new Map<Id, readonly Message[]>();
	for (const e of entries) byEntry.set(e.id, (e.model ?? []) as readonly Message[]);
	const through = chooseThrough(entries, byEntry, keepRecent);
	if (through === undefined) return;
	tx.task(collapseKind, { input: { reason: "threshold", through } });
}

// ---------------------------------------------------------------------------
// Overflow (step 2a): before requesting, before calling the provider.
// ---------------------------------------------------------------------------

async function overflow(task: RunTask, rt: Rt, actions: Actions, ctx: Context) {
	const x = rt as unknown as CoreRuntimeExtras & typeof rt;
	return actions.terminal(async (tx, current) => {
		const keepRecent = await tx.value(collapseConfig.keepRecent).get();
		const { entries } = await tx.readContext(current.conversationId);
		const byEntry = new Map<Id, readonly Message[]>();
		for (const e of entries) byEntry.set(e.id, (e.model ?? []) as readonly Message[]);
		const through = chooseThrough(entries, byEntry, keepRecent);

		if (through === undefined) {
			// Nothing collapsible: notice, resolve inputs failed, terminalize.
			await tx.write(current.conversationId, noticeEntry, {
				model: [{ role: "user", content: "context too large; nothing to compact", timestamp: rt.now() }],
			});
			tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "failed", detail: "overflow" });
			return fail("overflow", "request exceeds context window and nothing is collapsible");
		}

		// Foreground collapse C and replacement generation G{after:[C]} owning the same inputs.
		const collapse = tx.task(collapseKind, { input: { reason: "overflow", through } });
		tx.task(generationKind, { after: [collapse], input: { inputs: task.input.inputs } });
		return fail("overflow", `request exceeds context window; collapsing through ${through}`);
		// Input ownership transfers to the replacement (§10.1: "without resolving inputs").
	});
}

// NOTES
//
// - `initial` rewrites `current.carry` in its transition to inject the real cutoff.
//   That is a hack around `transition(phase, carry, commit)` fixing the carry
//   before the commit runs. The commit needs to produce the carry (it mints the
//   system entry ID). Cleaner: let the transition builder return
//   `{ carry, payload }`. Open item for §16.
//
// - The replacement generation after overflow "reads C's outcome first" per
//   §10.1. That branch (C failed → notice + failed/overflow) is not in this
//   file: it belongs in `initial.run` as a check of `task.after` outcomes, and
//   needs `tx.getTask` on the after IDs. Omitted for length; ~10 lines.
//
// - The self-head check in the yield path reads `newestHead` after the boundary
//   and compares against the assistant ID. That is correct only because the
//   boundary places writes after the assistant in the same batch; it depends on
//   §9.5's ordering guarantee rather than a direct "was a self-head placed"
//   signal from `finalAnswerBoundary`. The helper should probably return that.
