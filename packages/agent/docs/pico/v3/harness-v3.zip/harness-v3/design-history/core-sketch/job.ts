import type { Context } from "@knightcode/chord";
import { type CoreRuntimeExtras, defineStateTask, type ProcessOutput, type ProcessSpec, type ProcessStatus } from "./assumed.ts";
import type { Id, JsonObject } from "./core.ts";
import { noticeEntry } from "./witnesses.ts";

// ---------------------------------------------------------------------------
// Types (§10.5)
// ---------------------------------------------------------------------------

export interface JobInput extends JsonObject {
	readonly command: string;
	readonly args: readonly string[];
	readonly cwd: string;
	readonly env?: { readonly [name: string]: string };
	readonly notify: boolean;
	readonly rerun: boolean;
	readonly every?: number;
	readonly notBefore?: number;
}

export interface JobCarry extends JsonObject {
	readonly occurrence: number;
}

export type JobCheckpoint =
	| { readonly phase: "waiting"; readonly untilMs: number }
	| { readonly phase: "spawning"; readonly key: string } // inflight: the host may have started it
	| { readonly phase: "running"; readonly key: string };

export interface JobResult extends JsonObject {
	readonly exitCode: number;
	readonly occurrences: number;
}
export interface JobFailure extends JsonObject {
	readonly reason: "spawn" | "interrupted";
	readonly detail: string;
}
export interface JobAborted extends JsonObject {
	readonly killed: boolean;
}
export type JobOutput = { -readonly [K in keyof ProcessOutput]: ProcessOutput[K] } & { exitCode?: number; occurrence: number };

const fail = (reason: JobFailure["reason"], detail: string) => ({ status: "failed", failure: { reason, detail } }) as const;

const spec = (input: JobInput): ProcessSpec => ({ command: input.command, args: input.args, cwd: input.cwd, ...(input.env === undefined ? {} : { env: input.env }) });

/** Same backoff schedule as retries, capped at 1 s. */
function pollDelay(poll: number): number {
	return Math.min(1000, 100 * 2 ** Math.min(poll, 4));
}

function mirror(o: JobOutput, s: Extract<ProcessStatus, { status: "running" | "exited" }>): void {
	o.stdout = s.stdout;
	o.stderr = s.stderr;
	o.droppedStdout = s.droppedStdout;
	o.droppedStderr = s.droppedStderr;
	if (s.status === "exited") o.exitCode = s.exitCode;
}

// ---------------------------------------------------------------------------
// The kind. Ordinary: notices are passive `write`s.
// ---------------------------------------------------------------------------

export const jobKind = defineStateTask<JobInput, JobCarry, JobCheckpoint, JobResult, JobFailure, JobAborted, JobOutput>()({
	kind: "knightcode.job",
	output: { kind: { kind: "knightcode.job" }, initial: (): JobOutput => ({ stdout: "", stderr: "", droppedStdout: 0, droppedStderr: 0, occurrence: 1 }) },

	// -------------------------------------------------------------------------
	// initial: occurrence 1. No host → failed/spawn before any checkpoint.
	// -------------------------------------------------------------------------
	initial: {
		role: "start",
		async run(task, rt, actions, _ctx) {
			const x = rt as unknown as CoreRuntimeExtras & typeof rt;
			if (x.processHost === undefined) return actions.terminal(() => fail("spawn", "no process host"));
			return schedule(task.input, { occurrence: 1 }, rt, actions);
		},
	},

	phases: {
		// -----------------------------------------------------------------------
		// waiting: absolute deadline, idempotent sleep.
		// -----------------------------------------------------------------------
		waiting: {
			role: "start",
			async run(task, rt, actions, ctx) {
				await rt.sleep(task.checkpoint.untilMs, ctx);
				const key = `${task.id}:${task.carry.occurrence}`;
				return actions.transition("spawning", task.carry, () => ({ key }));
			},
		},

		// -----------------------------------------------------------------------
		// spawning: `start` may have happened. Committed BEFORE any OS effect.
		// -----------------------------------------------------------------------
		spawning: {
			role: "inflight",
			async run(task, rt, actions, ctx) {
				const x = rt as unknown as CoreRuntimeExtras & typeof rt;
				const host = x.processHost;
				if (host === undefined) return actions.terminal(() => fail("spawn", "no process host"));
				try {
					await host.start(task.checkpoint.key, spec(task.input), ctx);
				} catch (error) {
					if (ctx.abortSignal?.aborted) throw error;
					return actions.terminal(async (tx, current) => {
						if (task.input.notify) {
							await tx.write(noticeEntry, {
								model: [{ role: "user", content: `job ${task.id} failed to start: ${String(error)}`, timestamp: rt.now() }],
							});
						}
						return fail("spawn", String(error));
					});
				}
				return actions.transition("running", task.carry, () => ({ key: task.checkpoint.key }));
			},
			async recover(task, rt, actions, ctx) {
				return reconcile(task, rt, actions, ctx);
			},
		},

		// -----------------------------------------------------------------------
		// running: poll status until exited, mirroring output.
		// -----------------------------------------------------------------------
		running: {
			role: "inflight",
			async run(task, rt, actions, ctx) {
				return poll(task, rt, actions, ctx);
			},
			async recover(task, rt, actions, ctx) {
				return reconcile(task, rt, actions, ctx);
			},
		},
	},

	// -------------------------------------------------------------------------
	// abort by checkpoint. A kill rejection is the failing-abort fault (§7.3).
	// -------------------------------------------------------------------------
	async abort(task, rt, ctx) {
		const x = rt as unknown as CoreRuntimeExtras & typeof rt;
		const cp = task.checkpoint;
		if (cp === undefined || cp.phase === "waiting" || x.processHost === undefined) {
			return async () => ({ killed: false });
		}
		const host = x.processHost;
		await host.kill(cp.key, "SIGTERM", ctx);
		await rt.sleep(rt.now() + 5000, ctx);
		await host.kill(cp.key, "SIGKILL", ctx);
		return async () => ({ killed: true });
	},
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

type Actions = Parameters<(typeof jobKind)["phases"]["running"]["run"]>[2];
type Rt = Parameters<(typeof jobKind)["phases"]["running"]["run"]>[1];
type RunningTask = Parameters<(typeof jobKind)["phases"]["running"]["run"]>[0];
type SpawningTask = Parameters<(typeof jobKind)["phases"]["spawning"]["run"]>[0];
type AnyTask = { readonly id: Id; readonly input: JobInput; readonly carry: JobCarry };

/** Decide whether occurrence `n` waits or spawns now. */
function schedule(input: JobInput, carry: JobCarry, rt: Rt, actions: Actions) {
	const now = rt.now();
	const untilMs = carry.occurrence === 1 ? (input.notBefore ?? now) : now + (input.every ?? 0);
	if (untilMs > now) return actions.transition("waiting", carry, () => ({ untilMs }));
	return actions.transition("spawning", carry, (_tx, current) => ({ key: `${current.id}:${carry.occurrence}` }));
}

/** Recover from `spawning` or `running`: ask the host what it knows. */
async function reconcile(task: SpawningTask | RunningTask, rt: Rt, actions: Actions, ctx: Context) {
	const x = rt as unknown as CoreRuntimeExtras & typeof rt;
	const host = x.processHost;
	if (host === undefined) return actions.terminal(() => fail("interrupted", "no process host after restart"));

	let status: ProcessStatus;
	try {
		status = await host.status(task.checkpoint.key, ctx);
	} catch (error) {
		if (ctx.abortSignal?.aborted) throw error;
		return actions.terminal(() => fail("interrupted", `host status failed: ${String(error)}`));
	}

	if (status.status === "unknown") {
		if (!task.input.rerun) return actions.terminal(() => fail("interrupted", "process outcome unknown after restart"));
		// Possible duplicate external effect; exactly the uncertainty §3.2 allows.
		return actions.transition("spawning", task.carry, () => ({ key: task.checkpoint.key }));
	}
	if (task.checkpoint.phase === "spawning") {
		return actions.transition("running", task.carry, () => ({ key: task.checkpoint.key }));
	}
	return poll(task as RunningTask, rt, actions, ctx, status);
}

/** Poll until exited, mirroring output on each change. */
async function poll(task: RunningTask, rt: Rt, actions: Actions, ctx: Context, first?: ProcessStatus) {
	const x = rt as unknown as CoreRuntimeExtras & typeof rt;
	const host = x.processHost;
	if (host === undefined) return actions.terminal(() => fail("interrupted", "no process host"));

	let n = 0;
	let status = first;
	for (;;) {
		if (status === undefined) {
			try {
				status = await host.status(task.checkpoint.key, ctx);
			} catch (error) {
				if (ctx.abortSignal?.aborted) throw error;
				return actions.terminal(() => fail("interrupted", `host status failed: ${String(error)}`));
			}
		}
		if (status.status === "unknown") {
			if (!task.input.rerun) return actions.terminal(() => fail("interrupted", "process outcome unknown"));
			return actions.transition("spawning", task.carry, () => ({ key: task.checkpoint.key }));
		}
		const s = status;
		await rt.commit((tx) => mirror(tx.output(), s), ctx); // empty flush if nothing changed

		if (s.status === "exited") return exited(task, s.exitCode, rt, actions);

		await rt.sleep(rt.now() + pollDelay(n++), ctx);
		status = undefined;
	}
}

/** On exit: notice (same commit as the next checkpoint or terminal), then loop or complete. */
function exited(task: AnyTask, exitCode: number, rt: Rt, actions: Actions) {
	const n = task.carry.occurrence;
	const notice = async (tx: { write: (k: typeof noticeEntry, i: unknown) => Promise<Id> }) => {
		if (!task.input.notify) return;
		await tx.write(noticeEntry, {
			model: [{ role: "user", content: `job ${task.id} occurrence ${n} exited with code ${exitCode}`, timestamp: rt.now() }],
		});
	};

	if (task.input.every !== undefined) {
		const next = { occurrence: n + 1 };
		const untilMs = rt.now() + task.input.every;
		return actions.transition("waiting", next, async (tx) => {
			await notice(tx as never);
			const o = tx.output();
			o.stdout = ""; o.stderr = ""; o.droppedStdout = 0; o.droppedStderr = 0;
			delete o.exitCode;
			o.occurrence = n + 1;
			tx.rebaseOutput(); // fresh state for n + 1
			return { untilMs };
		});
	}
	return actions.terminal(async (tx) => {
		await notice(tx as never);
		return { status: "completed", result: { exitCode, occurrences: n } };
	});
}

// NOTES
//
// - `schedule` for occurrence > 1 uses `every` from the moment of exit. §10.5
//   says "no backlog is inferred after downtime", which this satisfies: a
//   `waiting` recovered late just sleeps until the stored untilMs and runs once.
//
// - This is an ordinary kind, so `tx.write` is the boundary-safe passive form
//   (own conversation, no conversationId argument). The `write` returns an
//   input ID that is deliberately not recorded in `result` (§10.5: placement
//   may happen after the job terminalized).
