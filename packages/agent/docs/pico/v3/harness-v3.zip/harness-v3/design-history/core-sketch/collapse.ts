import type { AssistantMessage, Message, RetryPolicy, SystemMessage } from "@knightcode/ai";
import type { ThinkingLevel } from "../../types.ts";
import { type CoreRuntimeExtras, defineCoreStateTask } from "./assumed.ts";
import { collapseConfig, generationConfig, type ModelRef } from "./config.ts";
import type { Id, JsonObject, Stored } from "./core.ts";
import { effectiveTools } from "./prepare.ts";
import { decideRetry, errorDetail } from "./retry.ts";
import { collapseHooks, summaryEntry } from "./witnesses.ts";

// ---------------------------------------------------------------------------
// Types (§10.4, delta §5.4, §5.5)
// ---------------------------------------------------------------------------

export type CollapseReason = "threshold" | "manual" | "overflow";

export interface CollapseInput extends JsonObject {
	readonly reason: CollapseReason;
	readonly through: Id;
	readonly instructions?: string;
}

export interface CollapseCarry extends JsonObject {
	readonly expectedHead: Id | null;
	readonly instructions?: string;
	readonly model: ModelRef;
	readonly thinkingLevel: ThinkingLevel;
	readonly retry: Stored<RetryPolicy>;
	readonly attempt: number;
}

export type CollapseCheckpoint =
	| { readonly phase: "summarizing" }
	| { readonly phase: "retrying"; readonly untilMs: number; readonly lastError: string }
	| { readonly phase: "prepared"; readonly summary: string };

export interface CollapseResult extends JsonObject {
	readonly summary: Id;
}
export interface CollapseFailure extends JsonObject {
	readonly reason: "stale" | "declined" | "provider" | "retries_exhausted" | "no_model";
	readonly detail: string;
}
export type CollapseAborted = null;

const fail = (reason: CollapseFailure["reason"], detail: string) => ({ status: "failed", failure: { reason, detail } }) as const;

const summaryText = (message: AssistantMessage): string =>
	message.content
		.filter((b): b is Extract<typeof b, { type: "text" }> => b.type === "text")
		.map((b) => b.text)
		.join("");

// ---------------------------------------------------------------------------
// Summarizer request: tool-free, request-local (§10.4).
// ---------------------------------------------------------------------------

function summaryRequest(carry: CollapseCarry, messages: readonly Message[], now: number): readonly Message[] {
	const effective = effectiveTools(messages);
	const strip: SystemMessage = { role: "system", content: "", toolsRemoved: [...effective], timestamp: now };
	const ask: Message = {
		role: "user",
		content:
			(carry.instructions ?? "Summarize the conversation so far for continuation. Preserve decisions, open questions, and any state the assistant must remember.") +
			"\n\nRespond with the summary only.",
		timestamp: now,
	};
	return effective.length ? [...messages, strip, ask] : [...messages, ask];
}

// ---------------------------------------------------------------------------
// The kind
// ---------------------------------------------------------------------------

export const collapseKind = defineCoreStateTask<CollapseInput, CollapseCarry, CollapseCheckpoint, CollapseResult, CollapseFailure, CollapseAborted>()({
	kind: "knightcode.collapse",
	config: collapseConfig,
	hooks: collapseHooks,

	// -------------------------------------------------------------------------
	// initial: off-line snapshot, hook, then one transition that re-checks the
	// head atomically with the checkpoint.
	// -------------------------------------------------------------------------
	initial: {
		role: "start",
		async run(task, rt, actions, ctx) {
			const x = rt as unknown as CoreRuntimeExtras & typeof rt;
			const conversation = await rt.conversation(task.conversationId, ctx);
			if (conversation === undefined) throw new Error("own conversation missing");

			const model = (await conversation.value(generationConfig.model).get(ctx)) as ModelRef | undefined;
			if (model === undefined) return actions.terminal(() => fail("no_model", "no model configured"));

			const head = await x.newestHead(task.conversationId, undefined, ctx);
			const { entries } = await x.readContext(task.conversationId, task.input.through, ctx);

			const decision = await rt.hooks.run(
				collapseHooks.beforeCollapse,
				{ reason: task.input.reason, through: task.input.through, entries },
				ctx,
			);
			const d = decision.output;
			if (d !== undefined && "decline" in d) return actions.terminal(() => fail("declined", "declined by beforeCollapse"));

			const carry: CollapseCarry = {
				expectedHead: head?.id ?? null,
				...((d?.instructions ?? task.input.instructions) === undefined ? {} : { instructions: d?.instructions ?? task.input.instructions }),
				model,
				thinkingLevel: (await conversation.value(generationConfig.thinkingLevel).get(ctx)) as ThinkingLevel,
				retry: (await conversation.value(generationConfig.retry).get(ctx)) as Stored<RetryPolicy>,
				attempt: 1,
			};
			const summary = d?.summary;

			return actions.transition(summary === undefined ? "summarizing" : "prepared", carry, async (tx, current) => {
				const nowHead = await tx.newestHead(current.conversationId);
				if ((nowHead?.id ?? null) !== carry.expectedHead) return fail("stale", "head moved during beforeCollapse");
				return summary === undefined ? {} : { summary };
			});
		},
	},

	phases: {
		summarizing: {
			role: "inflight",
			async run(task, rt, actions, ctx) {
				const x = rt as unknown as CoreRuntimeExtras & typeof rt;
				const model = x.models.resolve(task.carry.model);
				if (model === undefined) return actions.terminal(() => fail("no_model", "model unavailable"));

				const { messages } = await x.readContext(task.conversationId, task.input.through, ctx);
				const request = summaryRequest(task.carry, messages, rt.now());

				let message: AssistantMessage | undefined;
				try {
					for await (const event of x.models.stream(model, { messages: request, thinkingLevel: task.carry.thinkingLevel, signal: ctx.abortSignal }, ctx)) {
						if (event.type === "done" || event.type === "error") {
							message = event.message;
							break;
						}
					}
				} catch (error) {
					if (ctx.abortSignal?.aborted) throw error;
					return retry(task.carry, null, String(error), rt, actions);
				}
				if (message === undefined) return retry(task.carry, null, "stream ended without a message", rt, actions);

				if (message.content.some((c) => c.type === "toolCall")) {
					return retry(task.carry, { ...message, stopReason: "error", errorMessage: "summarizer returned tool calls" }, "summarizer returned tool calls", rt, actions);
				}
				if (message.stopReason === "error") return retry(task.carry, message, errorDetail(message, "provider error"), rt, actions);

				const summary = summaryText(message);
				return actions.transition("prepared", task.carry, () => ({ summary }));
			},

			async recover(task, rt, actions, _ctx) {
				return retry(task.carry, null, "interrupted", rt, actions);
			},
		},

		retrying: {
			role: "start",
			async run(task, rt, actions, ctx) {
				await rt.sleep(task.checkpoint.untilMs, ctx);
				return actions.transition("summarizing", { ...task.carry, attempt: task.carry.attempt + 1 }, () => ({}));
			},
		},

		prepared: {
			role: "start",
			async run(task, _rt, actions, _ctx) {
				const { summary } = task.checkpoint;
				const { expectedHead } = task.carry;
				const through = task.input.through;

				return actions.terminal(async (tx, current) => {
					const { head, entries } = await tx.readContext(current.conversationId);
					if ((head?.id ?? null) !== expectedHead) return fail("stale", "head moved during collapse");

					const retained = entries.find((e) => e.id > through);
					const id = tx.entry(summaryEntry, current.conversationId, {
						data: { through },
						model: [{ role: "user", content: summary, timestamp: Date.now() }],
						head: retained?.id ?? "self",
					});
					return { status: "completed", result: { summary: id } };
				});
			},
		},
	},

	async abort() {
		return async () => null;
	},
});

// ---------------------------------------------------------------------------
// Shared retry step (run: provider failure; recover: interruption).
// ---------------------------------------------------------------------------

type Actions = Parameters<(typeof collapseKind)["phases"]["summarizing"]["run"]>[2];
type Rt = Parameters<(typeof collapseKind)["phases"]["summarizing"]["run"]>[1];

function retry(carry: CollapseCarry, message: AssistantMessage | null, detail: string, rt: Rt, actions: Actions) {
	const decision = decideRetry(carry.retry, carry.attempt, message, rt.now());
	if (decision.kind === "fail") return actions.terminal(() => fail(decision.reason, detail));
	return actions.transition("retrying", carry, () => ({ untilMs: decision.untilMs, lastError: detail }));
}

// NOTES
//
// - "One live collapse per conversation; a second creation returns the
//   existing ID" (§10.4) is a creation-time rule on `tx.task(collapseKind, …)`,
//   not on the kind. It belongs in the task creator, keyed on kind +
//   conversation + live status.
//
// - The summarizer is driven through `models.stream` and only the terminal
//   message is kept. There is no output for collapse, so nothing to stream to.
