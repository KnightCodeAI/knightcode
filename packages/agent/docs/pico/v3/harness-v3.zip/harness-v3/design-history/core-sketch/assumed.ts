// ---------------------------------------------------------------------------
// ASSUMED SURFACES
//
// Everything the core kinds depend on that is NOT in pico-handoff-v2.md or the
// current src/harness/pico/*.ts. Each item is either (a) a delta decision from
// pico-design-delta.md, or (b) a gap discovered while writing the kinds and
// marked NEW below.
//
// This file is declarations only. It exists so the kinds compile against one
// honest list rather than silently inventing methods.
// ---------------------------------------------------------------------------

import type { Context } from "@knightcode/chord";
import type { Message } from "@knightcode/ai";
import type { Id, JsonValue } from "./core.ts";
import type { Entry } from "./entries.ts";
import type { EntryScan, Page } from "./storage.ts";
import type {
	BaseTaskTx,
	CoreFinalTx,
	CoreTaskTx,
	FinalTx,
	RunningTask,
	TaskRuntime,
	CoreTaskRuntime,
} from "./runtime.ts";
import type {
	Completion,
	ConfigBundle,
	NoExtra,
	OutputState,
	TaskCheckpoint,
	TaskKind,
	CoreTaskKind,
} from "./tasks.ts";
import type { HookPoints, EmptyHookPoints } from "./hooks.ts";
import type { AbortClosure, AbortTaskRuntime, CoreAbortClosure, CoreAbortTaskRuntime } from "./runtime.ts";

// ---------------------------------------------------------------------------
// Delta §5.2 — transcript reads (three methods, two views)
// ---------------------------------------------------------------------------

export interface ReadContextResult {
	/** Newest fork-visible head-bearing entry at or before `at`. */
	readonly head: Entry | undefined;
	/** Selected entries: head first, inner heads dropped. Ascending. */
	readonly entries: readonly Entry[];
	/** Projected messages: edits applied, tool results reordered, fork gaps synthesized. */
	readonly messages: readonly Message[];
}

export interface TranscriptReads {
	/** Model view (§1.3). `at` defaults to the tip. */
	readContext(conversationId: Id, at?: Id): Promise<ReadContextResult>;
	/** Head only. Cheap; used by §12.5 snapshots. */
	newestHead(conversationId: Id, at?: Id): Promise<Entry | undefined>;
	/** Record view. Kind-filtered, head- and edit-independent (§12.4). Newest first. */
	scanEntries(query: EntryScan): Promise<Page<Entry>>;
	/** Newest fork-visible entry of any kind. Used for the request cutoff. */
	newestEntry(conversationId: Id): Promise<Entry | undefined>;
}

// Mirrored on the runtime so a phase with nothing to write need not open a commit.
export interface RuntimeTranscriptReads {
	readContext(conversationId: Id, at: Id | undefined, ctx: Context): Promise<ReadContextResult>;
	newestHead(conversationId: Id, at: Id | undefined, ctx: Context): Promise<Entry | undefined>;
	scanEntries(query: EntryScan, ctx: Context): Promise<Page<Entry>>;
	newestEntry(conversationId: Id, ctx: Context): Promise<Entry | undefined>;
}

// ---------------------------------------------------------------------------
// Delta §4.5 — output as a tracked handle on tx
// ---------------------------------------------------------------------------

export interface OutputTx<O extends OutputState> {
	/** The tracked proxy. Mutate it directly; the runtime flushes at commit end. Valid only inside this closure. */
	output(): O;
	/** Force the next flush of the output to be a full base (`["r", value]`). Use on reset. */
	rebaseOutput(): void;
}

// ---------------------------------------------------------------------------
// NEW — boundary helpers. Referenced throughout §1.4, §5.3, §9.5, §10.1, §10.3
// as things CoreTaskTx has ("admission and boundary helpers", "input-group
// resolution"). Never declared anywhere.
// ---------------------------------------------------------------------------

export type InputResolution =
	| { readonly status: "done"; readonly answer?: Id }
	| { readonly status: "unanswered"; readonly reason: "terminated" | "aborted" | "failed" | "stale"; readonly detail?: string };

export interface BoundaryTx {
	/** Write StoredInputResult for every ID. Only core kinds may call this. */
	resolveInputs(ids: readonly Id[], resolution: InputResolution): void;

	/**
	 * Final-answer boundary (§9.5): places all queued writes, steer per
	 * steeringMode, followUp per followUpMode, strictly by ascending input ID,
	 * applying the self-head staling rules. Returns the IDs of placed
	 * steer/followUp entries, which form the successor group if non-empty.
	 */
	finalAnswerBoundary(conversationId: Id): Promise<{ readonly triggers: readonly Id[] }>;

	/**
	 * Post-tools boundary (§9.5): places all queued writes and steer per
	 * steeringMode. Returns steer IDs to join the active group. `terminated`
	 * is true when a placed self-head write ended the old group; the caller
	 * then resolves that group `unanswered/terminated` and only `triggers`
	 * admitted after the head may start a fresh generation.
	 */
	postToolsBoundary(conversationId: Id): Promise<{ readonly triggers: readonly Id[]; readonly terminated: boolean }>;
}

// ---------------------------------------------------------------------------
// Delta §5.6 — ToolInput carries the offered set
// ---------------------------------------------------------------------------

// see tool.ts: ToolInput = { assistant: Id; call: Stored<ToolCall>; offered: readonly string[] }

// ---------------------------------------------------------------------------
// Delta §5.3 + §5.4 + NEW — the state adapter with Carry, transition-can-finish,
// and a retry result for §12.5's "discard, repeat preparation" loop.
// ---------------------------------------------------------------------------

export type PhaseOf<C extends TaskCheckpoint> = C["phase"];
export type PhasePayload<C extends TaskCheckpoint, P extends PhaseOf<C>> = Omit<Extract<C, { readonly phase: P }>, "phase">;

/** The durable checkpoint shape the adapter writes: phase + carry + phase payload. */
export type StateCheckpoint<Carry, C extends TaskCheckpoint> = {
	[P in PhaseOf<C>]: { readonly phase: P; readonly carry: Carry } & PhasePayload<C, P>;
}[PhaseOf<C>];

export type PhaseTask<I extends JsonValue, Carry, C extends TaskCheckpoint, O extends OutputState, P extends PhaseOf<C>> = Omit<
	RunningTask<I, StateCheckpoint<Carry, C>, O>,
	"checkpoint"
> & {
	readonly checkpoint: Extract<StateCheckpoint<Carry, C>, { readonly phase: P }>;
	readonly carry: Carry;
};

export type InitialTask<I extends JsonValue, C extends TaskCheckpoint, O extends OutputState> = Omit<
	RunningTask<I, C, O>,
	"checkpoint"
> & { readonly checkpoint?: never };

/** A transition builder may advance, finish, or ask the adapter to re-run the current handler. */
export const RETRY: unique symbol = Symbol("pico.stateTask.retry");
export type Retry = typeof RETRY;

export type TransitionResult<C extends TaskCheckpoint, P extends PhaseOf<C>, R extends JsonValue, F extends JsonValue> =
	| PhasePayload<C, P>
	| Completion<R, F>
	| Retry;

export interface StateTransition<I extends JsonValue, Carry, C extends TaskCheckpoint, R extends JsonValue, F extends JsonValue, O extends OutputState, P extends PhaseOf<C>> {
	readonly type: "transition";
	readonly phase: P;
	readonly carry: Carry;
	readonly commit: (
		tx: CoreFinalTx<StateCheckpoint<Carry, C>, O> & TranscriptReads & OutputTx<O> & BoundaryTx,
		current: RunningTask<I, StateCheckpoint<Carry, C>, O>,
	) => TransitionResult<C, P, R, F> | Promise<TransitionResult<C, P, R, F>>;
}

export interface StateTerminal<I extends JsonValue, Carry, C extends TaskCheckpoint, R extends JsonValue, F extends JsonValue, O extends OutputState> {
	readonly type: "terminal";
	readonly closure: (
		tx: CoreFinalTx<StateCheckpoint<Carry, C>, O> & TranscriptReads & OutputTx<O> & BoundaryTx,
		current: RunningTask<I, StateCheckpoint<Carry, C>, O>,
	) => Completion<R, F> | Promise<Completion<R, F>>;
}

export type StateResult<I extends JsonValue, Carry, C extends TaskCheckpoint, R extends JsonValue, F extends JsonValue, O extends OutputState> =
	| { [P in PhaseOf<C>]: StateTransition<I, Carry, C, R, F, O, P> }[PhaseOf<C>]
	| StateTerminal<I, Carry, C, R, F, O>;

export interface StateActions<I extends JsonValue, Carry, C extends TaskCheckpoint, R extends JsonValue, F extends JsonValue, O extends OutputState> {
	transition<P extends PhaseOf<C>>(
		phase: P,
		carry: Carry,
		commit: StateTransition<I, Carry, C, R, F, O, P>["commit"],
	): StateTransition<I, Carry, C, R, F, O, P>;
	terminal(closure: StateTerminal<I, Carry, C, R, F, O>["closure"]): StateTerminal<I, Carry, C, R, F, O>;
}

/** Runtime inside a phase handler: no `commit` before the first checkpoint (initial), full afterwards. */
export type StateRuntime<I extends JsonValue, Carry, C extends TaskCheckpoint, O extends OutputState, H extends HookPoints> = Omit<
	CoreTaskRuntime<I, StateCheckpoint<Carry, C>, O, H>,
	"commit" | "output"
> &
	RuntimeTranscriptReads & {
		commit<T>(
			build: (
				tx: CoreTaskTx<StateCheckpoint<Carry, C>> & TranscriptReads & OutputTx<O>,
				current: RunningTask<I, StateCheckpoint<Carry, C>, O>,
			) => T | Promise<T>,
			ctx: Context,
		): Promise<T>;
	};

export type InitialStateRuntime<I extends JsonValue, Carry, C extends TaskCheckpoint, O extends OutputState, H extends HookPoints> = Omit<
	StateRuntime<I, Carry, C, O, H>,
	"commit"
>;

export type PhaseHandler<I extends JsonValue, Carry, C extends TaskCheckpoint, R extends JsonValue, F extends JsonValue, O extends OutputState, P extends PhaseOf<C>, H extends HookPoints> =
	| {
			readonly role: "start";
			readonly recover?: never;
			run(
				task: PhaseTask<I, Carry, C, O, P>,
				rt: StateRuntime<I, Carry, C, O, H>,
				actions: StateActions<I, Carry, C, R, F, O>,
				ctx: Context,
			): Promise<StateResult<I, Carry, C, R, F, O>>;
	  }
	| {
			readonly role: "inflight";
			run(
				task: PhaseTask<I, Carry, C, O, P>,
				rt: StateRuntime<I, Carry, C, O, H>,
				actions: StateActions<I, Carry, C, R, F, O>,
				ctx: Context,
			): Promise<StateResult<I, Carry, C, R, F, O>>;
			recover(
				task: PhaseTask<I, Carry, C, O, P>,
				rt: StateRuntime<I, Carry, C, O, H>,
				actions: StateActions<I, Carry, C, R, F, O>,
				ctx: Context,
			): Promise<StateResult<I, Carry, C, R, F, O>>;
	  };

export type StateTaskDefinition<I extends JsonValue, Carry, C extends TaskCheckpoint, R extends JsonValue, F extends JsonValue, A extends JsonValue, O extends OutputState, H extends HookPoints> = {
	readonly kind: string;
	readonly hooks?: H;
	readonly config?: ConfigBundle;
	readonly output?: { readonly kind: { readonly kind: string }; initial(input: I): O };
	readonly initial: {
		readonly role: "start";
		run(
			task: InitialTask<I, StateCheckpoint<Carry, C>, O>,
			rt: InitialStateRuntime<I, Carry, C, O, H>,
			actions: StateActions<I, Carry, C, R, F, O>,
			ctx: Context,
		): Promise<StateResult<I, Carry, C, R, F, O>>;
	};
	readonly phases: { readonly [P in PhaseOf<C>]: PhaseHandler<I, Carry, C, R, F, O, P, H> };
	abort(
		task: RunningTask<I, StateCheckpoint<Carry, C>, O>,
		rt: CoreAbortTaskRuntime<I, StateCheckpoint<Carry, C>, O, H>,
		ctx: Context,
	): Promise<CoreAbortClosure<I, StateCheckpoint<Carry, C>, A, O>>;
};

export declare function defineCoreStateTask<
	I extends JsonValue,
	Carry,
	C extends TaskCheckpoint,
	R extends JsonValue,
	F extends JsonValue,
	A extends JsonValue,
	O extends OutputState = never,
>(): <H extends HookPoints = EmptyHookPoints, D extends StateTaskDefinition<I, Carry, C, R, F, A, O, H> = StateTaskDefinition<I, Carry, C, R, F, A, O, H>>(
	definition: NoExtra<StateTaskDefinition<I, Carry, C, R, F, A, O, H>, D>,
) => D & CoreTaskKind<I, StateCheckpoint<Carry, C>, R, F, A, O, H>;

/** Ordinary variant (knightcode.job): BaseTaskTx instead of CoreTaskTx, no boundary helpers, `write` instead of `entry`. */
export declare function defineStateTask<
	I extends JsonValue,
	Carry,
	C extends TaskCheckpoint,
	R extends JsonValue,
	F extends JsonValue,
	A extends JsonValue,
	O extends OutputState = never,
>(): <H extends HookPoints = EmptyHookPoints, D = unknown>(definition: D) => D & TaskKind<I, StateCheckpoint<Carry, C>, R, F, A, O, H>;

// ---------------------------------------------------------------------------
// NEW — process host injection. §10.5 says "injected through
// HarnessOpenOptions.processHost" but the job kind has no declared way to
// reach it. Assumed: the runtime exposes it.
// ---------------------------------------------------------------------------

export interface ProcessSpec {
	readonly command: string;
	readonly args: readonly string[];
	readonly cwd: string;
	readonly env?: { readonly [name: string]: string };
}
export interface ProcessOutput {
	readonly stdout: string;
	readonly stderr: string;
	readonly droppedStdout: number;
	readonly droppedStderr: number;
}
export type ProcessStatus =
	| ({ readonly status: "running" } & ProcessOutput)
	| ({ readonly status: "exited"; readonly exitCode: number } & ProcessOutput)
	| { readonly status: "unknown" };
export interface ProcessHost {
	start(key: string, spec: ProcessSpec, ctx: Context): Promise<void>;
	status(key: string, ctx: Context): Promise<ProcessStatus>;
	kill(key: string, signal: "SIGTERM" | "SIGKILL", ctx: Context): Promise<void>;
}
export interface RuntimeProcessHost {
	readonly processHost: ProcessHost | undefined;
}

// ---------------------------------------------------------------------------
// NEW — provider access. §10.1 calls "the provider" and `models.stream`,
// `models.fetchDeferred`, `models.cancelDeferred` but never says where a task
// gets `models` from. Assumed: on the runtime.
// ---------------------------------------------------------------------------

import type { AssistantMessage, AssistantMessageEvent, DeferredHandle, Model, Api, Tool } from "@knightcode/ai";
import type { ModelRef } from "./config.ts";

export interface StreamRequest {
	readonly messages: readonly Message[];
	readonly thinkingLevel: string;
	readonly signal: AbortSignal | undefined;
}
export interface Models {
	resolve(ref: ModelRef): Model<Api> | undefined;
	stream(model: Model<Api>, request: StreamRequest, ctx: Context): AsyncIterable<AssistantMessageEvent>;
	fetchDeferred(model: Model<Api>, handle: DeferredHandle, ctx: Context): Promise<AssistantMessage | { readonly deferred: DeferredHandle }>;
	cancelDeferred(model: Model<Api>, handle: DeferredHandle, ctx: Context): Promise<void>;
}
export interface RuntimeModels {
	readonly models: Models;
}

// ---------------------------------------------------------------------------
// NEW — registries. §12 and §10.2 reference `h.sections`, `h.tools` and their
// revisions from inside preparation and tool lookup. No task-facing surface.
// ---------------------------------------------------------------------------

import type { TSchema } from "@sinclair/typebox";

export interface ToolDeclaration<P extends TSchema = TSchema> {
	readonly name: string;
	readonly description: string;
	readonly parameters: P;
	readonly replay?: "safe" | "unsafe";
	readonly output?: { readonly maxBytes?: number; readonly maxLines?: number; readonly retain?: "head" | "tail" };
}
export interface SystemSection<T extends JsonValue = JsonValue> {
	readonly key: string;
	render(value: T): string;
}
export interface Registries {
	readonly sections: { get(key: string): SystemSection | undefined; all(): readonly SystemSection[]; readonly revision: number };
	readonly tools: { get(name: string): ToolDeclaration | undefined; readonly revision: number };
}
export interface RuntimeRegistries {
	readonly registries: Registries;
}

// The internal test executor for WP10 (§11.1: "knightcode.tool is implemented and
// tested against an internal test executor that returns ToolResults").
import type { ToolCall } from "@knightcode/ai";
import type { ToolResult } from "./tool.ts";
export interface ToolExecutor {
	execute(call: ToolCall, ctx: Context): Promise<ToolResult>;
}
export interface RuntimeToolExecutor {
	readonly toolExecutor: ToolExecutor;
}

// Estimation (App. A imports it from @knightcode/ai; declared here so the kinds have one name).
export declare function estimate(messages: readonly Message[]): number;

// The union every core runtime is assumed to carry.
export type CoreRuntimeExtras = RuntimeTranscriptReads & RuntimeModels & RuntimeRegistries & RuntimeToolExecutor & RuntimeProcessHost;
