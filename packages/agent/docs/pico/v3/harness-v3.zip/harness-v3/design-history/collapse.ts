import type { AssistantMessage, ModelRef, RetryPolicy, ThinkingLevel, UserMessage } from "@knightcode/ai";
import { isRetryableAssistantError, retryDelayMs } from "@knightcode/ai";
import type { Context } from "../context.ts";
import { defineEntry } from "./entries.ts";
import { defineHookPoint } from "./hooks.ts";
import { defineStateTask } from "./tasks.ts";
import type { Entry, Id, JsonObject, Stored } from "./core.ts";
import { generationKind } from "./generation.ts";

// ---------------------------------------------------------------------------
// MISSING SURFACE (see notes at the bottom of this file).
//
// `Storage` has `scanEntries` and `newestHead`. Neither is reachable from any
// task-facing type in the spec: `TxReaders` exposes only get-by-id, and
// `TaskConversation` exposes only state + `send`. §10.4 requires collapse to
// read `newestHead` and the entries to summarize *on the line*, and §10.1
// requires generation to derive a request from a cutoff. Both are impossible
// as written.
//
// Everything below assumes `TxReaders` gains these two. They are the minimum
// that makes the two core kinds expressible, and they are read-only, so they
// fit the read-before-write rule without further change.
// ---------------------------------------------------------------------------
declare module "./runtime.ts" {
  interface TxReaders {
    /** Newest fork-visible entry carrying a head, at or before `at` (default: tip). */
    newestHead(conversationId: Id, at?: Id): Promise<Entry | undefined>;
    /** Fork-visible entries, newest first; `through` is an inclusive upper bound. */
    scanEntries(query: {
      conversationId: Id;
      through?: Id;
      cursor?: Id;
      kind?: string;
      limit?: number;
    }): Promise<{ items: readonly Entry[]; more: boolean }>;
  }
}

// ---------------------------------------------------------------------------
// Entry kind
// ---------------------------------------------------------------------------

export interface SummaryEntry extends Entry {
  readonly kind: "knightcode.summary";
  readonly data: { readonly through: Id };
  readonly model: readonly [UserMessage];
  readonly head: Id;
}

export const summaryEntry = defineEntry<SummaryEntry>("knightcode.summary");

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export interface BeforeCollapseIn extends JsonObject {
  readonly reason: CollapseReason;
  readonly through: Id;
  readonly entries: readonly Entry[];
  readonly instructions?: string;
}

export type BeforeCollapseOut =
  | { readonly decline: true }
  | { readonly instructions: string }
  | { readonly summary: string }
  | undefined;

export const beforeCollapse = defineHookPoint<BeforeCollapseIn, BeforeCollapseOut>({
  name: "knightcode.before_collapse",
  fold: "first",
});

// ---------------------------------------------------------------------------
// Task types
// ---------------------------------------------------------------------------

export type CollapseReason = "threshold" | "manual" | "overflow";

export interface CollapseInput extends JsonObject {
  readonly reason: CollapseReason;
  readonly through: Id;
  readonly instructions?: string;
}

/** Captured once, before `beforeCollapse`; carried unchanged except `attempt`. */
export interface Base extends JsonObject {
  readonly expectedHead: Id | null;
  readonly instructions?: string;
  readonly model: ModelRef;
  readonly thinkingLevel: ThinkingLevel;
  readonly retry: Stored<RetryPolicy>;
  readonly attempt: number;
}

export type CollapseCheckpoint =
  | ({ readonly phase: "summarizing" } & Base)
  | ({ readonly phase: "retrying"; readonly untilMs: number; readonly lastError: string } & Base)
  | ({ readonly phase: "prepared"; readonly summary: string } & Base);

export interface CollapseResult extends JsonObject {
  readonly summary: Id;
}

export interface CollapseFailure extends JsonObject {
  readonly reason: "stale" | "declined" | "provider" | "no_model";
  readonly detail: string;
}

export type CollapseAborted = null;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const fail = (reason: CollapseFailure["reason"], detail: string) =>
  ({ status: "failed", failure: { reason, detail } }) as const;

function baseOf(cp: CollapseCheckpoint): Base {
  const { phase, ...rest } = cp;
  const { untilMs, lastError, summary, ...base } = rest as Record<string, unknown>;
  return base as unknown as Base;
}

/** The head a new summary must carry: the first retained entry after `through`. */
async function firstRetained(
  tx: { scanEntries: TxReadersExt["scanEntries"] },
  conversationId: Id,
  through: Id,
): Promise<Id | "self"> {
  // Scans are newest-first, so walk back from the tip until `through` is passed.
  // The retained tail is `keepRecent`-bounded, so this is bounded too.
  let cursor: Id | undefined;
  let candidate: Id | "self" = "self";
  for (;;) {
    const page = await tx.scanEntries({ conversationId, limit: 256, ...(cursor ? { cursor } : {}) });
    for (const entry of page.items) {
      if (entry.id <= through) return candidate;
      candidate = entry.id;
    }
    if (!page.more) return candidate;
    cursor = page.items[page.items.length - 1]!.id;
  }
}

async function entriesThrough(
  tx: { scanEntries: TxReadersExt["scanEntries"] },
  conversationId: Id,
  through: Id,
): Promise<readonly Entry[]> {
  const out: Entry[] = [];
  let cursor: Id | undefined;
  for (;;) {
    const page = await tx.scanEntries({ conversationId, through, limit: 512, ...(cursor ? { cursor } : {}) });
    out.push(...page.items);
    if (!page.more) return out.reverse(); // scan is newest-first; summarizer wants chronological
    cursor = page.items[page.items.length - 1]!.id;
  }
}

function summaryText(message: AssistantMessage): string {
  return message.content
    .filter((block): block is Extract<typeof block, { type: "text" }> => block.type === "text")
    .map((block) => block.text)
    .join("");
}

function canRetry(base: Base, message: AssistantMessage | null): boolean {
  if (!base.retry.enabled) return false;
  if (base.attempt > base.retry.maxRetries) return false;
  // A null message is an interruption: treated as a retryable failed attempt.
  return message === null || isRetryableAssistantError(message);
}

// ---------------------------------------------------------------------------
// The kind
// ---------------------------------------------------------------------------

export const collapseKind = defineStateTask<
  CollapseInput,
  CollapseCheckpoint,
  CollapseResult,
  CollapseFailure,
  CollapseAborted
>()({
  kind: "knightcode.collapse",
  config: {
    model: generationKind.config.model,
    thinkingLevel: generationKind.config.thinkingLevel,
    retry: generationKind.config.retry,
  },
  hooks: { beforeCollapse },

  // -------------------------------------------------------------------------
  // initial: capture Base + the snapshot, run the hook, branch.
  // No checkpoint exists yet, so this runs exactly once per task.
  // -------------------------------------------------------------------------
  initial: {
    role: "start",
    async run(task, rt, actions, ctx) {
      const snapshot = await rt.commit(async (tx, current) => {
        const model = await tx.value(collapseKind.config.model).get();
        if (model === undefined) return null;
        const head = await tx.newestHead(current.conversationId);
        return {
          expectedHead: head?.id ?? null,
          model,
          thinkingLevel: await tx.value(collapseKind.config.thinkingLevel).get(),
          retry: await tx.value(collapseKind.config.retry).get(),
          entries: await entriesThrough(tx, current.conversationId, task.input.through),
        };
      }, ctx);

      // §10.4: no model terminalizes before the hook and before any checkpoint.
      if (snapshot === null) return actions.terminal(() => fail("no_model", "no model configured"));

      const decision = await rt.hooks.run(
        "beforeCollapse",
        {
          reason: task.input.reason,
          through: task.input.through,
          entries: snapshot.entries,
          ...(task.input.instructions === undefined ? {} : { instructions: task.input.instructions }),
        },
        ctx,
      );

      if (decision !== undefined && "decline" in decision)
        return actions.terminal(() => fail("declined", "declined by beforeCollapse"));

      const instructions =
        decision !== undefined && "instructions" in decision ? decision.instructions : task.input.instructions;

      const base: Base = {
        expectedHead: snapshot.expectedHead,
        ...(instructions === undefined ? {} : { instructions }),
        model: snapshot.model,
        thinkingLevel: snapshot.thinkingLevel,
        retry: snapshot.retry,
        attempt: 1,
      };

      // The hook ran outside the line; re-check the head before trusting its
      // decision. A head that moved means it decided against a superseded
      // context (§10.4: never pair old entries with a new head).
      const hookSummary = decision !== undefined && "summary" in decision ? decision.summary : undefined;

      if (hookSummary !== undefined)
        return actions.transition("prepared", async (tx, current) => {
          const head = await tx.newestHead(current.conversationId);
          if ((head?.id ?? null) !== base.expectedHead) throw new Stale();
          return { summary: hookSummary, ...base };
        });

      return actions.transition("summarizing", async (tx, current) => {
        const head = await tx.newestHead(current.conversationId);
        if ((head?.id ?? null) !== base.expectedHead) throw new Stale();
        return base;
      });
    },
  },

  phases: {
    // -----------------------------------------------------------------------
    // summarizing: the provider call is in flight. `inflight` forces a
    // `recover` arm at compile time — this is the phase whose effect may have
    // happened without us knowing.
    // -----------------------------------------------------------------------
    summarizing: {
      role: "inflight",

      async run(task, rt, actions, ctx) {
        const base = baseOf(task.checkpoint);

        // Re-read the prefix rather than carrying it through the checkpoint:
        // `through` is fixed by the input and `expectedHead` guards staleness,
        // so the read is reproducible. Carrying it would put the whole prefix
        // in every checkpoint.
        const entries = await rt.commit(
          (tx, current) => entriesThrough(tx, current.conversationId, task.input.through),
          ctx,
        );

        let message: AssistantMessage;
        try {
          message = await rt.models.complete(
            base.model,
            // Request-local and tool-free (§10.4): every tool effective in the
            // projected history is removed and none are offered. A summarizer
            // that emits tool calls anyway is a provider failure.
            toolFree(buildSummaryRequest(base, entries)),
            { thinkingLevel: base.thinkingLevel, signal: ctx.signal },
          );
        } catch (error) {
          return retryOrFail(base, null, String(error), rt, actions, ctx);
        }

        if (message.toolCalls !== undefined && message.toolCalls.length > 0)
          return retryOrFail(base, message, "summarizer returned tool calls", rt, actions, ctx);

        if (message.stopReason === "error")
          return retryOrFail(base, message, message.errorMessage ?? "provider error", rt, actions, ctx);

        const summary = summaryText(message);
        return actions.transition("prepared", () => ({ summary, ...base }));
      },

      async recover(task, rt, actions, ctx) {
        // The call may have happened and there is no result lookup. Count it as
        // that attempt's failure — never replay the same attempt number.
        return retryOrFail(baseOf(task.checkpoint), null, "interrupted", rt, actions, ctx);
      },
    },

    // -----------------------------------------------------------------------
    // retrying: durable backoff. `start` means run and recover are the same
    // function — the sleep is idempotent because `untilMs` is absolute.
    // -----------------------------------------------------------------------
    retrying: {
      role: "start",
      async run(task, rt, actions, ctx) {
        await rt.sleep(task.checkpoint.untilMs, ctx);
        const base = baseOf(task.checkpoint);
        return actions.transition("summarizing", () => ({ ...base, attempt: base.attempt + 1 }));
      },
    },

    // -----------------------------------------------------------------------
    // prepared: the candidate text is durable. Only finalization remains, so
    // this phase never calls the provider on recovery.
    // -----------------------------------------------------------------------
    prepared: {
      role: "start",
      async run(task, _rt, actions, _ctx) {
        const { summary, expectedHead } = task.checkpoint;
        const through = task.input.through;

        return actions.terminal(async (tx, current) => {
          // Head read first: if someone else collapsed meanwhile, the summary
          // we computed describes a prefix that is no longer the prefix.
          // Edits appended in between do not stale (they carry no head).
          const head = await tx.newestHead(current.conversationId);
          if ((head?.id ?? null) !== expectedHead) return fail("stale", "head moved during collapse");

          const id = tx.entry(summaryEntry, current.conversationId, {
            data: { through },
            model: [{ role: "user", content: summary }],
            head: await firstRetained(tx, current.conversationId, through),
          });

          return { status: "completed", result: { summary: id } };
        });
      },
    },
  },

  // -------------------------------------------------------------------------
  // abort: collapse owns no external resource and creates no work, so there is
  // nothing to wind down. The partial summary, if any, lives in the checkpoint
  // and is retired with the task.
  // -------------------------------------------------------------------------
  async abort() {
    return async () => null;
  },
});

// ---------------------------------------------------------------------------
// Retry decision, shared by `run` (real provider failure) and `recover`
// (interruption). Both record the attempt that failed and let the next
// `summarizing` use attempt + 1.
// ---------------------------------------------------------------------------
async function retryOrFail(
  base: Base,
  message: AssistantMessage | null,
  detail: string,
  rt: { now(): number },
  actions: { transition: Function; terminal: Function },
  _ctx: Context,
) {
  if (!canRetry(base, message)) {
    const reason = base.retry.enabled && base.attempt > base.retry.maxRetries ? "provider" : "provider";
    return actions.terminal(() => fail(reason, detail));
  }
  const untilMs = rt.now() + retryDelayMs(base.retry, base.attempt);
  return actions.transition("retrying", () => ({ untilMs, lastError: detail, ...base }));
}

class Stale extends Error {}

// ---------------------------------------------------------------------------
// NOTES / GAPS
//
// 1. TxReaders has no transcript access at all. Declared above as the minimum
//    addition. Affects knightcode.generation identically (it cannot derive a request
//    from its cutoff). This is not part of the §11.1 gate.
//
// 2. `firstRetained` walks the tail newest-first because `scanEntries` only
//    descends. It is bounded by `keepRecent`, but a dedicated
//    "first entry after X" read would be cheaper and is the mirror of
//    `newestHead`, which exists for exactly this reason on the other side.
//
// 3. The stale check in `initial` throws rather than terminalizing, because a
//    transition payload builder can only return a payload — it has no way to
//    say "actually, terminalize". §16's `actions` are available in `run`, not
//    inside `transition`'s commit callback. Either the payload builder needs a
//    terminal escape, or the head re-check has to move into `run` as a separate
//    read-only commit before the transition, which reopens the gap the
//    re-check exists to close. This is a real hole in the state adapter, not
//    just in this kind.
//
// 4. `baseOf` destructures phase-specific fields out by name. The spread-based
//    checkpoint shape (`{ phase } & Base`) makes this unavoidable and
//    unchecked: add a field to one phase and `baseOf` silently carries it
//    forward. A nested `{ phase, base, ... }` shape would type-check instead.
//
// 5. `retryOrFail`'s `reason` computation is degenerate (both branches are
//    "provider") because §10.4 gives no distinct failure reason for exhausted
//    retries, while §10.1 gives generation "retries_exhausted". Probably an
//    inconsistency between the two sections rather than intent.
// ---------------------------------------------------------------------------
