# Pico v2 — design delta

Status: design discussion. No spec or source changes made. Two code sketches
exist (`collapse.ts`, `collapse2.ts`) written to test the design, not to land.
Written against `packages/agent/docs/pico/pico-handoff-v2.md` @ `a9930d2`
(pico branch).

This is a **delta**: it records only where the design should change, what was
found wrong, and what was checked and left alone. Everything not mentioned
stands as written.

---

## 1. Summary

**Changes to make:**

| # | change | §
|---|---|---|
| 1 | Collapse `value`, `list` and shared task-output into one delta-backed state kind | 2, 14 |
| 2 | `tx.value(address)` returns a mutable tracked handle; runtime flushes at commit end | 2, 5 |
| 3 | Fold `TaskOutput` into `tx`; delete it as a separate surface | 3.4, 5.3, 5.4 |
| 4 | Give tasks transcript reads — they currently have none at all | 5.3, 5.4 |
| 5 | Add `readContext` (projected model view) alongside `newestHead` and a kind-filtered `scanEntries` | 4, 5.3 |
| 6 | `actions.transition` may return a completion, not only a payload | 16 |
| 7 | `defineStateTask` gains an explicit `Carry` type parameter | 16 |
| 8 | Make `knightcode.collapse` (and probably `knightcode.generation`) state tasks | 10.1, 10.4 |

**Bugs / gaps found:** §4 below. Item 4 above is the serious one.

**Checked and left alone:** no effect gate needed; post-crash cancellation runs
`abort` not `recover`; phase unions beat journal-replay here; the commit rate is
fine and needs no kernel change.

---

## 2. Closed questions (no change)

### 2.1 No effect gate

The lane harness has `Gate.admit(invoke)` — a synchronous check-then-invoke that
refuses to start an effect once the lane is closing. Pico needs no equivalent.

The lane needs it because its cancellation is not primarily durable:
`requestAbort` calls `beginAbort` synchronously *before* the lane mutation lands,
so admission closes before the marker commits. The gate compensates for a
non-instant marker.

Pico inverts the order — mark durably, revoke the old invocation's writes, then
signal — so there is nothing to compensate for. A process-local gate is also
strictly weaker than a durable mark: it evaporates on crash, and recovery trusts
only durable control. The commit line is itself the gate that matters, since
commits close as soon as the task is marked or the session closes. And effects
honouring the ctx signal must be assumed regardless.

Possibly worth one sentence in §7 explaining the absence, since anyone arriving
from the lane harness will look for it.

### 2.2 Post-crash cancellation runs `abort`

Scheduler eligibility (§6) checks the mark first and ignores dependencies:
live + marked → fresh abort, full stop. "Fresh" means `abort` is always a new
invocation with a new invocation object and ctx, never a continuation.

- In-process: revoke the old invocation's writes, signal, join, discard its
  closure, reserve the fresh one.
- After a crash: no old invocation to revoke or join. Straight to reserving the
  fresh one. Same path, fewer steps.

A task still `pending` when marked is promoted to `running` purely so `abort`
receives a `RunningTask`. It never executes. `abort` must cope with a checkpoint
written by a dead process; it can read scratch and output and checkpoint its own
cleanup, but cannot create work.

**Noted, not in the spec:** `abort`'s liveness is unbounded. A stuck or
repeatedly-crashing `abort` re-runs from its checkpoint forever — there is no
mark-of-a-mark — so a bad `abort` can keep a conversation from reaching
`closed`. Should be written down as a known limit and an authoring constraint.

### 2.3 Phase unions over journal-replay

`execute` never reads the checkpoint: it runs the whole straight-line algorithm,
placing checkpoints where needed. Only `recover` reads a phase and jumps in
partway. The asymmetry is sharp — adding a checkpoint to `execute` is a local
edit that silently creates a durable phase with no arm in `recover`.

The Temporal / Restate / Cloudflare Workflows alternative (linear function,
`step.do(name, fn)`, journal results, re-run from the top with memoized steps)
was rejected:

- Replace-whole checkpoints with no event log rule out journal-replay outright.
- A phase union is a durable recorded program counter; a journal replay is a
  *reconstruction* correct only if nobody violated an unenforced determinism
  rule. Temporal spends enormous effort — sandboxed runtimes, patched clocks,
  non-determinism detectors — because that rule cannot live in the type system.
- The phase union fails at compile time; journal replay fails on the
  least-exercised path in production.
- `step.do` obfuscates linear flow anyway: step names are load-bearing durable
  identity, so renaming or reordering breaks in-flight workflows.

The one real cost — a value computed in phase 2 and needed in phase 12 must be
threaded through every intermediate phase — does not bite, because pico's tasks
are short. See §5.3 (`Carry`) for the part of it that does.

### 2.4 Commit rate is fine

Considered at length, resolved as a non-issue. Recorded because the reasoning is
easy to re-derive incorrectly.

§10.1 already specifies one incremental `output.mutate` per frame, and every
mutate is a commit. So **pico already commits per token**, as does the lane
harness (`pendingAssistantFrames`). Nothing in this delta changes that rate.

Three worries were raised and all three are wrong:

- *Backpressure on the provider.* No. @knightcode/ai's `EventStream.push` is synchronous
  — hands to a waiting consumer or enqueues, unbounded. The producer never sees
  the consumer's rate.
- *Tail latency at high token rates.* Only if commits are slow. A commit is an
  uncontended mutex, a tracker diff (42µs on the pathological 200KB case, far
  less normally), a row append, an index update and one envelope. Tens of
  microseconds without a durable flush.
- *Line fairness — one hot stream starving other conversations.* Same answer,
  plus there are not many parallel conversations in practice.

So throttling a streaming loop is a constant-factor overhead reduction worth
three lines of imperative code (a last-commit timestamp compared per iteration),
not a correctness or fairness mechanism. Not normative.

**The one case that could matter:** a backend forcing a durable flush per commit
— Postgres round-trip, SQLite at `synchronous=FULL`. That is a backend property,
so if it matters it belongs in §15, not as a rule on generation.

---

## 3. The state changes

### 3.1 One state kind

§2 currently has `kind: "value" | "list"`, plus a third implicit kind — shared
task output, Chord deltas streamed as `task_output` events, with no public
constructor. These are one thing at three points on a spectrum of how much of
the state a single write replaces.

- **Delta encoding is a property of the data, not the scope.** Nothing about
  being task-owned makes output need deltas. A list's appends already *are* a
  delta encoding.
- **Value is a degenerate delta**: the newest write is the entire state, so the
  fold is O(1) and history is a lookup rather than a replay.
- **Lists are already the fold case.** This is exactly why list reads are total
  with no pagination: a list is operations, the anchor is a `clear`, and you
  cannot find the anchor without scanning. Rewindable lists already carry the
  cost that would supposedly make rewindable deltas unacceptable.

All three are an operation log plus a durable marker saying where the fold can
start:

| kind | marker behaviour |
|---|---|
| value | every write is a new baseline; window of one |
| list | `clear` writes a marker |
| output | the writer chooses when to snapshot |

### 3.2 Chord's vocabulary is already exactly this

`packages/chord/src/delta/index.ts` (1268 lines, read in full) is far lighter
than assumed — **no CRDT, no per-document identity, no vector clocks.** Six op
verbs over plain JSON:

```ts
type Op =
  | ["r", JsonValue]                          // replace root — the only whole-value write
  | ["s", NonEmptyPath, JsonValue]            // set
  | ["d", NonEmptyPath]                       // delete
  | ["a", NonEmptyPath, string]               // append to string
  | ["t", NonEmptyPath, number]               // truncate string
  | ["p", Path, number, number, JsonValue[]]  // splice array
```

`isBase(ops)` is `ops[0][0] === "r"`, and flush guarantees `r` is at index 0 or
absent. The source comment is explicit that **a base batch is a recovery point**
— a reader replays from the last one with a fresh decoder, which is why the
encoder clears its path dictionary on `r`. That is the truncation marker,
already first-class. So:

- **value** = a document where every write is `r`
- **list** = root is an array written with `p`; `clear` is `r` with `[]`
- **output** = the same vocabulary, unrestricted

One storage shape: append ops, find the last `r`, fold forward.

Other details worth knowing: string diffing prefers
`after.slice(0, before.length) === before` over `startsWith` (845µs → 42µs on a
200KB cons string — someone had streaming in mind); sparse arrays are rejected
both for JSON round-trip fidelity and as DoS prevention; `apply` uses
`defineProperty` rather than assignment so inherited setters cannot run; `r`
adopts rather than copies.

### 3.3 The inbox is not a counter-example

Objection raised and withdrawn: the inbox (§9) is ID-keyed — element ID is the
input ID, `InputHandle.abort` removes by ID — while Chord's array ops are
positional.

It does not matter. Chronology is array position. Selection already scans the
whole list. Removal is a splice emitted directly, not something a diff infers.
The input ID lives as a field inside the element and `InputHandle.abort` scans
for it. Reads are total anyway, so scanning is free.

Identity is the inbox's business, not the state layer's. `List` was baking one
consumer's requirement into the primitive.

### 3.4 Spec consequences

- §2: `kind` leaves the address. Identity becomes
  `[scope.type, scope id, rewind, namespace, key ?? null]`.
- §2: `Value` and `List` merge into one `State<T>` for any JSON shape. Scalar
  config, the inbox array and a streaming assistant message are one mechanism.
- §14: the watch envelope carries state ops rather than `ListOp`. The view
  reducer applies them.
- §2.1 config bundles are unaffected in shape — documents whose writes are
  always `r`.

### 3.5 Scratch and shared merge, with one caveat

Same thing: task-owned state differing only in how many tasks pin it. One owner
→ retire on termination. Many → retire when the last dependent terminalizes.
This already half-exists — terminal `task.set` retires scratch *and unreferenced
outputs*, so "unreferenced" is already a refcount.

**Caveat needing resolution:** the reference edge is *not* `after`. `after` is
ordering; reading an output is a data edge. A task can read an output it never
listed in `after`, so a late reader would find its data retired. The pin must be
explicit and distinct from `after`.

Secondary, accepted as low-risk: shared scope's absent public constructor is a
compile-time guarantee that becomes a runtime check under a visibility flag.

**Retirement is scope-driven and unrelated to the fold marker.** Task terminates
→ scratch goes. Last reference drops → shared goes. The marker is purely a read
optimisation. Conversation and session state never retire because their scope
never ends — fine, since that is the rewindable state where history is
load-bearing.

---

## 4. `tx.value` returns a tracked handle

### 4.1 Shape

```ts
const msg = tx.value(address);   // the tracked proxy
msg.content[0].text += chunk;    // recorded
```

One object for reading and writing. No callback, no `mutate(addr, draft => ...)`,
no copies, no lifetime rules the caller must know. Task code never constructs or
names a tracker; the runtime owns them.

A read/write split was rejected: if `tx.value` returns a raw snapshot and the
task mutates it, nothing is tracked and the baseline silently diverges. Silent
wrong data, not a loud failure.

### 4.2 Runtime behaviour

- One tracker per address, cached. The tracker *contains* the head —
  `tracker.target` is the head. Not two cached things.
- `tx` exists only inside `runtime.commit`, so the handle's useful lifetime is
  the commit closure.
- **At commit end the runtime flushes every address handed out during that
  commit.** Empty op array → nothing staged, so a pure read costs zero writes and
  needs no declaration. Write-detection is a consequence of flushing rather than
  a mode you enter.
- The same address twice in one commit returns the same cached tracker, giving
  read-your-writes *within* a commit. Fine.
- **Read-before-write (§5.1) largely dissolves for state.** Every op is produced
  at flush, so there is no interleaving to police. It still applies to
  `TxReaders`.

### 4.3 Failure handling

On commit failure, **evict** the tracker. Not `discard()`, which would wrongly
accept the failed mutations locally. Next access refolds from storage and
rebuilds — the same path as cold start after reopen, so it is exercised often
rather than being a rare branch. The first flush after a rebuild should probably
`rebase()` to a base batch as cheap insurance.

### 4.4 The handle must not escape the commit closure

**Rule: the tracked handle is valid only inside the closure that received it.**

If it escapes, mutations happen outside the line, concurrently with other
commits, and the flush diffs against a baseline that may no longer match durable
state. Because ops are relative — truncate-then-append on a string is the clear
case — applying them to a state that moved yields something that is neither
version, silently rather than as an error. Holding a handle across a crash buys
nothing either, since the mutations were never durable.

Costs nothing in practice: streaming is a loop of small commits, each getting the
handle fresh from the cache.

### 4.5 Fold `TaskOutput` into `tx`

Today output is **not** in `tx` at all:

```ts
interface TaskOutput<O> {
  readonly ref: TaskOutputRef<O>;
  read(ctx: Context): Promise<O>;
  mutate(m: (state: O) => undefined, ctx: Context): Promise<void>;
  replace(value: O, ctx: Context): Promise<void>;
}
```

It hangs off `rt.output`, and `mutate` takes a ctx and does its own commit —
which means calling it inside `rt.commit` is `NestedLineOperation`.

Note that `mutate(m: (state: O) => undefined)` is already a draft-mutation
callback, and §5.2's assertions already say "one `knightcode.output` append per **tracker
flush**". The tracker design is in the spec already; it just only exists for
output, behind a separate surface with its own commit.

So this change deletes a type rather than adding one: `tx.output()` returns the
same tracked handle as `tx.value`, output joins the line with everything else,
and a task can flush output *and* checkpoint in one commit instead of two.

Two follow-ons:

- `FinalOutput<O> = { readonly output: O }` on the final tx is a whole-value
  assignment, inconsistent with handles everywhere else. It should be the handle
  too, with the final flush emitting whatever ops fall out.
- Output resets (generation's `output.replace({})` on retry) currently produce a
  base `r` naturally. As a handle mutation they produce `d`/`s` ops instead, so
  the op log grows across retries and never truncates. The reset needs an
  explicit `tx.rebase(address)`. `rebase` is already in Chord's tracker API.

### 4.6 Open: scalars — not deferrable

Chord's `track<T extends object>` requires an object root, so a bare number or
string has no proxy. Either wrap in a one-field envelope, or expose a direct
`set(address, v)` emitting `["r", v]`.

This was initially deferred. It is not deferrable: `thinkingLevel` is a
`ThinkingLevel` string and is read in the **first commit of both
`knightcode.generation` and `knightcode.collapse`**. Same for any scalar config value.

---

## 5. Gaps found while writing a real kind

`knightcode.collapse` was written out in full against the real surfaces. These are what
that turned up.

### 5.1 Tasks cannot read the transcript at all — SERIOUS

`scanEntries` appears **exactly once in the entire spec**, in the `Storage`
interface. It is not on `TxReaders`, `TaskRuntime`, `TaskConversation`, or
anything else a task can reach. Neither is `newestHead`. `TxReaders` has only
get-by-id.

But §10.4 requires collapse to read `newestHead` and the entries to summarize
*on the line*, and §10.1 requires generation to derive a request from a cutoff.
Neither is expressible.

This is not behind the §11.1 gate, so nothing signals it is known.

**Fix: put the reads on `TxReaders` (and mirror them on `TaskRuntimeBase`).**
That is the whole fix. See §5.2 for which reads.

**Rejected framing — "split reads by volatility."** An earlier version of this
section argued that large transcript reads must happen off the line, on the
grounds that §5.1 ("reads on the line block every other commit; keep them small
and few") contradicts §10.4 (read an arbitrarily large prefix on the line).

There is no contradiction. §5.1 is guidance, not an invariant. The read is from
immutable storage, costs a few milliseconds, and collapse runs once per
compaction. Blocking the line for that delays other commits imperceptibly —
provider events buffer in @knightcode/ai and flush after. A big payload inside a commit
is fine.

The only reason to mirror the reads on `rt` is ergonomic: a phase that has
nothing to write should not open a commit purely to read.

**Open:** `TxReaders.getEntry(id)` already takes a bare ID with no subtree check,
so reads are effectively unscoped today. Widening the surface widens that.
Probably fine, but if reads are meant to be subtree-bound, that constraint is
stated nowhere and adding scans is the moment to decide.

### 5.2 The read surface: two orthogonal views, three methods

Verified against §10.1, §10.2, §10.4 and §12.

There are **two views of the transcript**, and §12.4 states the distinction
outright: canonical section state "uses the indexed `knightcode.system` kind scan and
**never depends on model heads or edits**."

| view | anchored on | edits | used by |
|---|---|---|---|
| **model view** — what gets sent | newest head | applied | §10.1 request, §10.4 summarizer, overflow/threshold `estimate`, `through` selection |
| **record view** — what was written | nothing; fork visibility only | ignored | §12.4 managed-section fold |

So the surface is:

```ts
readContext(conversationId: Id, at?: Id): Promise<{
  head: Entry | undefined;
  entries: readonly Entry[];      // selected: head first, inner heads dropped
  messages: readonly Message[];   // edits applied, results reordered, gaps synthesized
}>;

newestHead(conversationId: Id, at?: Id): Promise<Entry | undefined>;

scanEntries(query: EntryScan): Promise<Page<Entry>>;   // kind-filtered, head-independent
```

plus the existing get-by-id. `knightcode.tool` needs no transcript read at all once
§5.6 lands: the offered set is input, and the assistant entry ID is carried
for linking only.

**`readContext` must return messages, not just entries.** §10.1 says a request
captures "the entry ID list **and** effective messages at a durable cutoff" —
one call. Collapse wants messages for the summarizer and entry IDs for the
retained-entry lookup. Overflow wants `estimate(messages)`.

More importantly, projection is not per-caller policy. §1.3's synthesized
`ToolResultMessage` for a fork-truncated call is **never stored**, so it exists
only in the projection: a caller that builds messages itself from entries either
re-implements synthesis or silently emits a request with a dangling tool call.
Result reordering has the same property — transcript order is completion order,
not call order, and the mismatch is invisible until a provider rejects the
request. Edit folding has the "newest edit in range wins" rule, three lines that
must be identical everywhere. One derivation, one right answer.

**`newestHead` stays separate.** §12.5's snapshot needs only the head to decide
baseline versus delta; projecting the whole context to answer that would be
absurd. Storage already special-cases it "so context derivation never tails a
scan."

**What `readContext` deleted from collapse:** an `entriesThrough` helper, a
`firstRetained` helper, both paginate-and-reverse loops, and a separate
`newestHead` call. About 35 lines of 160. The `firstRetained` case is the
clearest: `knightcode.summary.head` must point at the first retained entry after
`through`, but `scanEntries` only descends, so finding it means walking the tail
backwards. With `readContext` it is `entries.find(e => e.id > through)` on data
already in hand.

**Corrected claim.** An earlier version of this section asserted `readContext`
might be the *only* transcript read, making `scanEntries` non-task-facing. §12.4
disproves that: the managed-section fold is head-independent and
edit-independent by design, and needs the kind-filtered scan. Three methods, not
one.

### 5.3 §16 transitions cannot terminalize — REAL HOLE

The shape is universal: check a condition on the line, then either advance or
terminalize. §16 models only "advance" — `actions.transition(phase, commit)`'s
callback can return a payload and nothing else.

Collapse needs exactly this. The head re-check after `beforeCollapse` must be in
the same commit that writes the checkpoint (that is the whole point — the hook
decided against a context that may have moved). Moving the check into `run` as a
separate read-only commit reopens the race it exists to close.

**Fix:**

```ts
transition<P>(phase: P, commit: (tx: StateFinalTx<C,O>, current) =>
  PhasePayload<C,P> | Completion<R,F> | Promise<...>): ...
```

Payload → write the checkpoint. Completion → terminalize. Same commit either
way, so check and decision stay atomic. The builder's tx must be a final tx so
it can append entries.

### 5.4 `{ phase: "..." } & Base` does not survive contact

Both §10.1 (`Prep`) and §10.4 (`Base`) spread a carried record across every
phase. Getting it back out means destructuring the phase-specific fields away by
name, unchecked — add a field to `retrying` and it silently rides into the next
`summarizing`.

**Fix — make the carry first-class in §16:**

```ts
defineStateTask<I, Carry, C, R, F, A, O>()
// checkpoint = { phase: P; carry: Carry } & PhasePayload<C,P>
```

The adapter threads it; phases declare only their own delta and receive
`task.carry` typed. `retrying` cannot leak `untilMs` into `summarizing` because
it never constructs the carry. Deletes the bug class rather than making it
visible.

**Open:** whether `transition` should take the carry explicitly. Only two
transitions change it (`initial` may replace `instructions`, `retrying` bumps
`attempt`); the other three pass it through verbatim, which is noise. Implicit
with an optional override is shorter; explicit makes mutation visible. The
sketch went explicit.

### 5.5 §10.4 has no `retries_exhausted`

§10.1 gives generation `retries_exhausted` as a distinct failure reason; §10.4
gives collapse only `provider`, though the retry paths are otherwise identical.
Reads like drift between sections, not intent.

### 5.6 `knightcode.tool` reads another task's checkpoint — should be input

§10.2 has `knightcode.tool` determine the offered tool set by reading `input.assistant`,
following `byTaskId` to the generation task, and reading `tools` from that
task's *retained checkpoint*. §10.1 step 5 gives the reason: "so `ToolInput`
carries no duplicate offered list."

That is one array of strings saved, at the cost of:

- `knightcode.tool` depending on another kind's checkpoint shape — it must know that
  `requesting` and `deferred` carry `Prep.tools` and `prepared`/`retrying` do
  not.
- A retention property becoming load-bearing: "terminal records keep their last
  checkpoint" can never change without breaking tool dispatch.
- Five failure modes (no `byTaskId`, task absent, not completed, different
  assistant, wrong phase), all of which **fault the session** per the spec's own
  text.

**Fix:** `ToolInput = { assistant: Id; call: Stored<ToolCall>; offered: readonly
string[] }`. The generation closure has `tools` in hand when it creates the tool
tasks. The offered-set check becomes `input.offered.includes(input.call.name)`,
the cross-task read disappears, and the five fault cases vanish because there is
nothing left to be inconsistent with.

General principle this violates: a task's input is its contract. Reaching into
another task's durable state for something the creator already knew is coupling
with no upside.

### 5.7 The asymmetry is real, demonstrated

While writing collapse the hand-written way, `execute` carried `entries` in a
local from the first commit and `recover` had no such local. The two silently
disagreed about what was in scope, and the gap was papered over with a method
name that did not exist.

That is precisely §16's argument, reproduced accidentally in a 95-line kind
while arguing the asymmetry was manageable. It is the strongest evidence in this
document for making the core kinds state tasks.

Under `defineStateTask` it is unrepresentable: `summarizing` is `role:
"inflight"`, so the compiler demands a `recover`, and each handler receives only
its own narrowed checkpoint, so there are no earlier-phase locals to assume.
Every cross-phase dependency must go through the carry or be recomputed,
visibly.

`retrying` and `prepared` also collapse `run` and `recover` into one function —
in the hand-written version those are two paths that happen to be identical and
must be kept so by hand.

**Recommendation:** `knightcode.collapse` and `knightcode.generation` should be state tasks.
`knightcode.generation` has the same shape plus `deferred`. Less clear for `knightcode.tool`,
where the complexity is in the gated surface rather than the phase graph.

---

## 6. Line budget — objection withdrawn

Raised and retracted. Recorded so it is not re-raised on the same bad
arithmetic.

Current pico source is 2384 lines, but almost none of it is implementation:

| file | lines | what |
|---|---|---|
| `index.ts` | 154 | pure re-exports |
| `core.ts`, `hooks.ts`, `entries.ts`, `storage.ts`, `runtime.ts`, `tasks.ts`, `addresses.ts` | 1212 | type declarations; ~150–200 lines of actual runtime code (the `define*` constructors, error classes) |
| `session.ts` | 440 | the commit line and Session — the only real implementation |
| `memory-storage.ts` | 578 | backend, excluded by the doc's own terms |

So roughly **600 lines of implementation**, not 1806. Erasable TypeScript means
the type surface compiles to nothing.

The lane comparison was wrong in the same direction, then wrong the other way:
`structural.ts` (1222) is compaction and navigation — that is `knightcode.collapse`'s
work, which pico must also write, not kernel machinery pico deletes. What pico
actually deletes is `lane.ts`: 2012 lines of kernel replaced by `session.ts` at
440 plus a scheduler.

And §7 below shows the kinds themselves shrink 5–6x. 3–4k is comfortable.

**What remains instead: the type surface.** `tasks.ts` already carries
`Collides`, `AnyCollision`, `DisjointBundles`; the spec adds `NoExtra`,
`ExactJsonInput`, `ExactPhaseHandler`, `ExactPhaseMap`. That is ~1200 lines of
type machinery for a foundation with no core kinds in it yet, and it grows with
every exactness guarantee.

It is also exempt from the doc's own escape hatch. "Past 4k, simplify the design"
works for implementation, which is downstream of design. Type machinery *is* the
design being enforced — you cannot simplify it without giving up the guarantee it
provides. It is the one part with no stated pressure valve, and the part a reader
must hold in their head to understand any signature.

---

## 7. The framework does absorb the plumbing

Tested by writing `knightcode.collapse` against real surfaces. The lane's compaction path
is roughly 600 lines; pico's is ~160 hand-written, ~110 as a state task with the
§5 fixes. **5–6x.**

What specifically vanished, from `publishStructuralOutcome` alone:

- `lane.session.idGenerator.next()` reserved by hand and threaded through every
  operation state as `resultEntryId` → `tx.entry()` returns the Id.
- `const writes: Write[] = []` built manually with `insertEntry`, `setValue`,
  `insertUsage` → tx buffers.
- `const entryWriteIndex = writes.length` tracked so events can point at the
  right write → kernel derives the envelope.
- `baseEvents: ((commit: CommitResult) => HarnessEvent[])[]` — an array of
  deferred event constructors, because events need the seq and timestamp that do
  not exist until after commit → gone entirely.
- `terminalTipId` threaded manually; `setValue(branchTip(...))` written twice →
  head is a facet.
- `effectPendingFromReady` / `retryWaitFromEffect` / `readyFromRetryWait` —
  three functions whose whole job is copying `operationScopeOf(current)` into the
  next shape → `{ ...carry, attempt: carry.attempt + 1 }`.
- `current.at === "summary.ready" ? current.nextAttempt : ...` narrowing a wide
  union to recover a field → it is on the carry.
- Two `SessionInvariantError` throws checking the outcome matches the task kind,
  plus `"in"` checks on durable preparation → the checkpoint union makes both
  unrepresentable.

The reason it works: the lane's durable state is a hand-rolled union with
hand-rolled transitions and hand-managed correlation between writes and events.
Pico makes the checkpoint the state and the commit the event. Nearly all of the
above existed only because those two things were not unified.

With the §5 fixes applied, every remaining line of collapse is domain logic — the
hook protocol, the staleness rule, retry classification, head placement. Nothing
is state management.

---

## 8. Open items

| item | status |
|---|---|
| Tasks cannot read the transcript (§5.1) | **serious, unflagged in the spec**; fix is three methods on `TxReaders`, see §5.2 |
| Where `readContext`'s projection lives (Storage vs a kernel layer above it) | open; §4 says storage is mechanical and never runs kind code, but projection is derivation, not kind code |
| `transition` cannot terminalize (§5.3) | **blocks correct collapse** |
| Scalar state roots (§4.6) | **blocks the first commit of two core kinds** |
| Explicit data-edge pin for shared outputs, distinct from `after` (§3.5) | needs design |
| `Carry` as a §16 type parameter (§5.4) | decided, not written |
| Whether `transition` takes carry explicitly (§5.4) | open, minor |
| Whether reads are subtree-bound (§5.1) | decide when adding scans |
| `abort` liveness unbounded (§2.2) | write down as a known limit |
| §10.4 missing `retries_exhausted` (§5.5) | one-word fix |
| `knightcode.tool` reads generation's checkpoint for the offered set (§5.6) | move to `ToolInput.offered` |
| `FinalOutput` as value vs handle (§4.5) | decide with the output fold |
| Output reset needs `tx.rebase` (§4.5) | decided, not written |
| §11.1 tool surfaces | still gated; WP10a still blocked |
| Type surface has no pressure valve (§6) | noted, no action proposed |

---

## 9. Reading notes

- `packages/agent/docs/pico/pico-handoff-v2.md` (2938 lines) is the spec.
  §2 scoped state L256, §2.1 config L345, §3 tasks L432, §3.4 output L548,
  §4 storage L600, §5 commit line L657, §5.3 tx surfaces L744, §5.4 runtime
  L813, §6 scheduler L862, §7 cancellation L895, §9 admission L1120,
  §10 core kinds L1308, §10.1 generation L1314, §10.4 collapse L1539,
  §11 tools L1661, §14 watch L2175, §16 state tasks L2379, §18 WPs L2730,
  App. A type index L2780.
- `packages/agent/docs/pico/pico-usage-v2.md` (773 lines) — usage view.
- `packages/agent/docs/harness.md` (1469 lines) — older lane spec, useful as
  contrast.
- `packages/chord/src/delta/index.ts` (1268 lines) — the op vocabulary and
  `track`/`flush`/`rebase`/`discard`. Read before touching §2.
- Lane implementation, for comparison: `runtime/lane.ts` (2012, the kernel),
  `runtime/drive/structural.ts` (1222, compaction + navigation),
  `runtime/drive/generation.ts` (302), `runtime/drive/response.ts` (485),
  `runtime/progress.ts` (140, the frame channel).
- Existing pico source: `packages/agent/src/harness/pico/` (2384 lines,
  foundation only).
- Sketches from this session: `collapse.ts` (hand-written against real
  surfaces, with the gaps annotated) and `collapse2.ts` (state task, assuming
  the §5 fixes).

### One defect in the lane worth not reproducing

`openProgress.write()` is fire-and-forget:

```ts
latest = write;
void write.catch(() => {});
```

Errors swallowed, and `drain()` awaits only `latest` — the last write. If frame
N fails and N+1 succeeds, drain resolves clean. Frames are deltas, so a lost
middle frame corrupts the reduction rather than truncating it: silent wrong text
on recovery. Pico's awaited commits cannot do this, and per §2.4 the await costs
essentially nothing.
